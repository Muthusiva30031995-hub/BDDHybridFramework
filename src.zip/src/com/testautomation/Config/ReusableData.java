package com.testautomation.Config;

public class ReusableData {
	
	public static final String url_test="http://cc-test.myqbe.com/CC/ClaimCenter.do";	
	public static final String url_agile="http://cc-agile-test.myqbe.com/CC/ClaimCenter.do";
	public static final String url_modl="https://cc-modl.myqbe.com/CC/ClaimCenter.do";
	public static final String JIRA_URL = "https://qbe-upgrade.valiantys.net";
	public static final String JIRA_ADMIN_USERNAME = "ravi.manikandan@us.qbe.com";
	public static final String JIRA_ADMIN_PASSWORD = "Memory-001";
	public static final String currentDir = System.getProperty("user.dir");
	public static final String fileSeparator = System.getProperty("file.separator");
	public static final String runManagerSheetPath = currentDir+"\\RunManager.xlsx";
	public static String masteresultPath="//sunimnascp006/PublicShare//QBENA - Automation Team\\Automation Execution\\GWCC_ResultFolder";
	public static String masteresultPathalterate="//vdawwfs04/PublicShare//QBENA - Automation Team\\Automation Execution\\GWCC_ResultFolder";
	public static String masteresultPathshort=masteresultPath;
	public static String email_host = "qbe-smtp.qbeai.com";
	public static String email_port = "25";	
	public static String email_to = "Muthusamy.Palanikumar@us.qbe.com";
	public static String email_from = "Muthusamy.Palanikumar@us.qbe.com";	
	public static String email_username = "ravi.manikandan@us.qbe.com";
	public static String email_password = "";

}
