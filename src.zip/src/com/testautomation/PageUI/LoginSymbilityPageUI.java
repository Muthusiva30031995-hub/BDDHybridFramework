package com.testautomation.PageUI;

import org.openqa.selenium.By;

public class LoginSymbilityPageUI {
	
	
	public static final By userName = By.name("Username:");
	public static final By password = By.name("Password:");	
	public static final By synchronizeBtn = By.name("Synchronize");
	public static final By searchClaimsTxt = By.className("RICHEDIT50W");
			
			

}
