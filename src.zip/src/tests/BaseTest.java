package tests;
import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.naming.ldap.ExtendedRequest;

import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

import com.aventstack.extentreports.ExtentReporter;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
//import com.relevantcodes.extentreports.ExtentReports;
//import com.relevantcodes.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import Core_Lib.Email;
import config.defs;
 
public class BaseTest {
    public WebDriver driver;
    public WebDriverWait wait;
 
	 public ExtentHtmlReporter htmlReporter;
	 public ExtentReports extent;
	 public static ExtendedRequest testRequest;
	 public static ExtendedRequest test_case;
	 public static ExtentTest logger=null;
	 
	public String currDir = System.getProperty("user.dir");
	public String FilePath = currDir + "\\src\\config\\QBEEnv.ini";
	public String report_path = currDir + "\\resultFolder\\";
	public String log4jConfPath = System.getProperty("user.dir") + "\\log4j.properties";
	//, defs.email_cc
	Email mail = new Email(defs.email_to, defs.email_from, defs.email_username, defs.email_password);

	DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
	Date date = new Date();
	public String regression_date=dateFormat.format(date).replaceAll("/","-");
	
	public String masterFolder="";
	
	public String testCaseName="";
	public String stepStatus = "";
	
	
	public ExtentTest getLogger()
	{
		return logger;
	}
}