package tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
//import com.atlassian.jira.rest.client.api;
import javax.naming.AuthenticationException;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.IAssert;


import com.aventstack.extentreports.ExtentReporter;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.core.util.Base64;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import javax.naming.AuthenticationException;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.core.util.Base64;

import Core_Lib.Browser_Close;
import Core_Lib.Browser_Invoke_Url;
import Core_Lib.DataSheet_TCName;
import Core_Lib.Email;
import Core_Lib.GenericLibrary;
import Core_Lib.Harness;
import Core_Lib.ScreenDriver;
import Core_Lib.ScreenShot;
import Core_Lib.Store_ExecutionTime;
import Core_Lib.TestController;
import base.runtimeRepo;
import config.defs;

public class testRegressionJIRA extends Browser_Invoke_Url {

	Logger LOG = Logger.getLogger(testRegressionJIRA.class.getName()); 
	// excel reporting
	public static int status;
	String projectName = "Regression";
 
	Harness ls_obj_harness = new Harness();
	Browser_Close obj_close = new Browser_Close(); 
	runtimeRepo run = new runtimeRepo();
	
	GenericLibrary obj_Generic = new GenericLibrary();
	String ApplicationName = projectName; // Application Name
	String executionType="data";
	DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy/HH/mm/ss");
	Date date = new Date();
	String ls_date=dateFormat.format(date).replaceAll("/","-");
	String masterFolder= "GWCC_Automation_" + ApplicationName+ "_" + regression_date;
	
	//String report_path2 = defs.masteresultPathshort + "\\resultFolder\\" + "GWCC_Automation_"+  ls_date ;
	//String report_path2 = defs.masteresultPathshort + "\\resultFolder\\" + masterFolder ;

	String DATASOURCE = "EXCLSOURCE"; // EXCLSOURCE TESTCASEXL
	String gs_Executionsheet = "Yes";
	String gs_ScreenShot = "Yes";
	String masterEmailSubject = "GWCC_AutoReg_Notification";
	
	public static String gs_Driver = null;
	public static String tc_name = null;
	public static int count = 0;

	 private static XSSFSheet ExcelWSheet;
	 private static XSSFWorkbook ExcelWBook;
	 private static XSSFCell Cell;
	 private static XSSFRow Row;
	 	
	public static String envPOM="";
	public static String slavePOM="";
	 public static String execute="";
	 public static String slaveno="";
	 public static String tc_name_local="";
	 public static String ls_Status="";
	 //public static String envPOM="TEST";
	// public static String slavePOM="slave1";
	 public static String testExeID="";
	 defs def = new defs();
	

		String FilePath = "";
		String masteresultPathshort=defs.masteresultPathshort;
		String report_path = "";
		String TC_Name_Path = "";
		String DataSheetPath = "";
		String extentreportpath="";
		String DataExcelPath="";
		String extentreportpathFolder = "";
		
		String auth = "";
		String jira_Status="TODO";
		String jiratestCaseID="";
		String jiratestCaseKey="";
		String jiratestCaseStatus="";
		String ExetestCaseKey="";
		private static final String JIRA_URL = defs.JIRA_URL;
	    private static final String JIRA_ADMIN_USERNAME = defs.JIRA_ADMIN_USERNAME;
	    private static final String JIRA_ADMIN_PASSWORD = defs.JIRA_ADMIN_PASSWORD;
	    private static String BASE_URL = defs.JIRA_URL;
	    
	    public static Map<String,String> mapTestKeys=new HashMap<String,String>();
	    public static Map<String,String> mapTestStatus=new HashMap<String,String>();
	    public static Map<String,String> mapTestKeysReverse=new HashMap<String,String>();
	    
	    @BeforeTest
		public void JIRA() 
		{
	    	
	    	auth = new String(Base64.encode(JIRA_ADMIN_USERNAME + ":" + JIRA_ADMIN_PASSWORD));
	    	
	    	testExeID= System.getProperty("regressionExeID");
	    	//testExeID= System.getProperty("regressionExeID");
			try {
				//Get Projects
				String path=BASE_URL+"/rest/raven/1.0/api/testexec/" + testExeID+ "/test";
				String testListJson = invokeGetMethod(auth, path);
				System.out.println(testListJson);
				JSONArray projectArray = new JSONArray(testListJson);
				for (int i = 0; i < projectArray.length(); i++) 
				{
					try {
						JSONObject proj = projectArray.getJSONObject(i);
						//System.out.println("Key:"+proj.getString("key")+", Name:"+proj.getString("name"));
						mapTestKeys.put(proj.getString("key"), proj.getString("id"));
						mapTestStatus.put(proj.getString("key"), proj.getString("status"));
						mapTestKeysReverse.put(proj.getString("id"), proj.getString("key"));
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
			} catch (AuthenticationException e) {
				System.out.println("Username or Password wrong!");
				e.printStackTrace();
			} catch (ClientHandlerException e) {
				System.out.println("Error invoking REST method");
				e.printStackTrace();
			} catch (JSONException e) {
				System.out.println("Invalid JSON output");
				e.printStackTrace();
			}
			catch (Exception e) {
				System.out.println("General Exception" + e.toString());
				e.printStackTrace();
			}   
		}		
	    		
	
		

	@BeforeTest
	public void beforeSetup() 
	{

		envPOM=System.getProperty("regressionnenv");
		slavePOM=System.getProperty("regressionslave");
		//envPOM="TEST";
		//slavePOM="slave2";
		
		System.out.println(">>>>>>"+envPOM + ">>>>>>" + slavePOM);
		
	
//		if(slavePOM.equalsIgnoreCase("slave1") || slavePOM.equalsIgnoreCase("slave3")
//					|| slavePOM.equalsIgnoreCase("slave9") || slavePOM.equalsIgnoreCase("slave10"))
//		{
//			masteresultPathshort=defs.masteresultPathalterate;
//		}
			
			FilePath = currDir + "\\src\\config\\QBEEnv.ini";
			report_path = masteresultPathshort + "\\resultFolder\\" + masterFolder;
			TC_Name_Path = currDir + "\\testCases\\" + projectName + "\\TC_Name.xlsx";
			DataSheetPath = currDir + "\\testData\\" + projectName + "\\ExecutionSheet.xlsx";
			DataExcelPath = currDir + "\\testData\\" + projectName + "\\Datasheet.xlsx";

			extentreportpathFolder = report_path + "\\" + slavePOM;
		
		
		
		try {
			//env=envPOM;
			//slave=slavePOM;
			File f = new File(report_path);
			if (f.exists() && f.isDirectory())
			   System.out.println(report_path + "File folder is present");
			else
				new File(report_path).mkdirs();

			File f1 = new File(extentreportpathFolder);
			if (f1.exists() && f1.isDirectory())
			   System.out.println(extentreportpathFolder + "File folder is present");
			else
				new File(extentreportpathFolder).mkdirs();
	
			extentreportpath = extentreportpathFolder + "\\ExtentReports_" +  projectName + ".html";
			
			PropertyConfigurator.configure(log4jConfPath);
			defs.setApplicationName(projectName);
			htmlReporter = new ExtentHtmlReporter(extentreportpath);
	        // Create an object of Extent Reports
			extent = new ExtentReports();  
			extent.attachReporter(htmlReporter);
			extent.setSystemInfo("Host Name", "GWCC_BBC");
	        extent.setSystemInfo("Environment", "Test");
	        extent.setSystemInfo("User Name", "GWCC_Automation Testing");
	        htmlReporter.config().setDocumentTitle("GWCC_Automation Testing"); 
	               // Name of the report
	        htmlReporter.config().setReportName("Automation Team"); 
	               // Dark Theme
	        htmlReporter.config().setTheme(Theme.DARK); 
			//extent.loadConfig(new File(System.getProperty("user.dir") + "\\src\\config" + "\\extent-config.xml"));

			System.out.println("ExtentReports is initiated");
			System.out.println("Initilizing the project Suite - " + projectName);
			
			String subject = "GWCC_Automated Regression Started - " + projectName;
			// mail.sendSubjectMail(subject);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test(dataProvider = "testcasesList",enabled=true, alwaysRun=true, retryAnalyzer = tests.Retry.class)
	public void gwcc_regression_testcase_master(String testcaseName, String executeFlag,
			String browser, String slavenoExcl, String environement,String testKey) {
		String status = "";
		String excep = "";
		// String
		// tc_name="TC001_DwellingFireProperty-GAIN_TEST_AutomatedAssignment-EXCL";
		String tc_name = testcaseName.trim().replaceAll("\n","");
		tc_name_local=tc_name;
		String FilePath_test = FilePath;
		String report_path_test = report_path;
		String DATASOURCE_test = "TESTCASEXL";// "TESTCASEXL"; //"EXCLSOURCE"
		String Browser = browser;
		ExetestCaseKey=testKey;
		execute = executeFlag;
		executionType="other";
		//String slave=System.getProperty("regressionnenv");
		slaveno=slavenoExcl;
		
		if(mapTestKeys.containsKey(testKey)) {
			jiratestCaseID = mapTestKeys.get(testKey);
		}
		if(mapTestKeysReverse.containsValue(testKey)) {
			jiratestCaseKey = testKey;
		}
		if(mapTestStatus.containsKey(testKey)) {
			jiratestCaseStatus = mapTestStatus.get(testKey);
		}
		
		if(execute.trim().replaceAll("\n","").equalsIgnoreCase("Y") && slaveno.trim().replaceAll("\n","").equalsIgnoreCase(slavePOM) 
				&& ExetestCaseKey.trim().replaceAll("\n","").equalsIgnoreCase(jiratestCaseKey))
		{
			try {
				
				jira_Status="EXECUTING";
				//PUT the status
				try {//EXECUTING-https://qbe-upgrade.valiantys.net/rest/raven/1.0/api/testrun/123862/status?status=FAIL
					invokePutMethod(auth, BASE_URL+"/rest/raven/1.0/api/testrun/" + jiratestCaseID
											+ "/status?status=" + jira_Status, "");
				}catch(Exception e)
				{//ABORTED
					jira_Status="ABORTED";
					invokePutMethod(auth, BASE_URL+"/rest/raven/1.0/api/testrun/" + jiratestCaseID
							+ "/status?status=" + jira_Status, "");
				}
				logger = extent.createTest(tc_name);
//				test_case = extent.startTest(tc_name);
				System.out.println("Test case name - " + tc_name);
				
				logger.log(Status.PASS, MarkupHelper.createLabel("Test Case execution started", ExtentColor.GREEN));
				LOG.info("Count" + count);
				// Sending the test case details to Harness
				ls_obj_harness.read_INIFile_new(tc_name, FilePath_test, report_path, DATASOURCE_test, Browser,
						gs_Executionsheet, gs_ScreenShot, ApplicationName,executionType);
				
				LOG.info("Count" + count);
				//status = "Passed";
			} catch (Exception e) {
				e.printStackTrace();
				logger.log(Status.FAIL, MarkupHelper.createLabel("Test Case Failed - " + e.toString()
						, ExtentColor.RED));
				logger.log(Status.ERROR, "Exception" + "\n" + e.getStackTrace());
				status = "Failed";
				excep = e.toString();
				jira_Status="FAIL";
			}
			
			try {
				ls_Status = obj_Generic.ls_statusdata;
				//String subject = "GWCC_Automated Notification:" + status + test_case.getTest().getName();
				String subject = ls_Status + ">>>" + testcaseName;
				//Email.sendBasicMail(subject, "");
	
				//Thread.sleep(3000);
				// calling Harness file
				Harness.rowindex1 = 2;
				Harness.lb_file = false;
				Harness.lb_status = false;
				Harness.lb_insertrow = false;
				Harness.li_insertrow = 1;
				//Thread.sleep(3000);
	
				
				System.out.println("Test Case Name - " + tc_name + " >>>>>>> The Final status >>>>>>>>" + ls_Status);
				Assert.assertTrue(ls_Status.equalsIgnoreCase("Pass"));
				jira_Status="PASS";
			} catch (Exception e) {
				e.printStackTrace();
				LOG.error(e.getStackTrace());
				ls_Status="FAIL";
				jira_Status="FAIL";
			}
			
		}

	}

	@AfterMethod
	public void tearDown(ITestResult result) {
		//ScreenShot obj_screenshot = new ScreenShot();
		//LOG.info("Calling Screenshot Function in TestNG class");
		//String status = "";
		// Here will compare if test is failing then only it will enter into if
		// condition
		String status = "";
		if(execute.trim().replaceAll("\n","").equalsIgnoreCase("Y") && 
				slaveno.trim().replaceAll("\n","").equalsIgnoreCase(slavePOM) && 
					ExetestCaseKey.trim().replaceAll("\n","").equalsIgnoreCase(jiratestCaseKey))
		
		{
			
			try {
				invokePutMethod(auth, BASE_URL+"/rest/raven/1.0/api/testrun/" + jiratestCaseID
						+ "/status?status=" + jira_Status, "");
			} catch (AuthenticationException | ClientHandlerException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
			
			Store_ExecutionTime StoreTime = new Store_ExecutionTime();
			String SheetPath,SheetPathShared,SheetPathFolder ;
			SheetPath = Harness.gs_data_path+"\\ExecutionTime.xlsx";
			SheetPathFolder = extentreportpathFolder;
			SheetPathShared = extentreportpathFolder+"\\ExecutionTime.xlsx";
			String Testcaseid = Harness.ls_Testcaseid;
			String ls_sheetID = "Sheet1";

			long minutes;
			long seconds;
			try {

				//Copy pasting the file from test data folder to result folder to ease the report and verification
				File f1 = new File(SheetPathShared );
				File f2 = new File(SheetPath );
				if (f1.exists() && !f1.isDirectory()) 
				{
				   System.out.println(SheetPathShared + "File is present");
				   }
				else
					{
					try {
						copy(f2, f1);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
				//result.getTestName();
				long time = result.getEndMillis() - result.getStartMillis();
				//long minutes = TimeUnit. MILLISECONDS. toMinutes(time);
				//long milliseconds = 1000000;
		        minutes = (time / 1000) / 60;
		        seconds = (time / 1000) % 60;
		        System.out.format("%d Milliseconds = %d minutes and %d seconds.", time, minutes, seconds);

				System.out.println("Duration:in Minutes"+minutes+"Start Time"+result.getStartMillis()+"EndTime"+result.getEndMillis());
				//logger.log("Duration:"+time+"Start Time"+result.getStartMillis()+"EndTime"+result.getEndMillis());
				//StoreTime.Store_ExecutionTime(SheetPath, Testcaseid, ls_sheetID ,minutes,seconds);
				StoreTime.Store_ExecutionTime(SheetPathShared, Testcaseid, ls_sheetID ,minutes,seconds);
			}
			
			catch(Exception e)
			{
				
			}
			
			
		 try {
			 if(defs.killthebrowserAtEnd)
				{
				// getDriver().close();
				 //getDriver().quit();
				 //Runtime.getRuntime().exec("taskkill /F /IM IEDriverServer.exe");
				// Runtime.getRuntime().exec("taskkill /F /IM iexplore.exe");
				}
			 if(logger!=null)
			  {
					if (ITestResult.FAILURE == result.getStatus()) 
					{
						LOG.info("Calling Screenshot Function in TestNG class");
						//obj_screenshot.screenShot(result);
						status = "Failed";
						logger.log(Status.FAIL,"Test cases is Failed");
					} // end of IF
					else if (ITestResult.SUCCESS == result.getStatus()) 
					{
						status = "Passed";
						logger.log(Status.PASS,"Test cases is completed and passed");
					}
			}
			
			// Mail Notification
			String subject = masterEmailSubject + " in " + slavePOM + ">" + ls_Status + ">" + TestController.claimNo + 
					">" + tc_name_local;
			
			String snapshotPath="file:///" + Harness.reportExcelScreenShotFolder;
			String reportExcelPath = "file:///" + Harness.report_testcase;
			
			String htmlmessage = "<html>" +
					"<head><title>"+masterEmailSubject+"</title></head>" +
					"<body>" +
					"<h2>Hi Team,</h2>"+
					"</br>"+
					"<h2>Please find below snapshot folder path and excel report link,</h2>"+
					"</br>"+
					"<h2> Click <a href=\"" + snapshotPath + "\">here</a> to see the <u><b>snapshot</b></u> folder </h2>" +
					"</br>"+
					"<h2> Click <a href=\"" + reportExcelPath + "\">here</a> to see the <u><b>Excel Report</b></u> </h2>" +
					"</br>"+
					"<h2>Thanks & Regards,</h2>"+
					"<h2>QBENA Automation Team</h2>"+
					"</body>" +
					"</html>";
			
			Email.sendMailWithbody(subject,htmlmessage);

			String snapJira=Harness.reportExcelScreenShotFolder.replaceAll("\\", "//");
			snapJira=Harness.reportExcelScreenShotFolder.replaceAll("/", "//");
			String reportJira=Harness.report_testcase.replaceAll("\\", "//");
			reportJira=Harness.report_testcase.replaceAll("/", "//");
			String snapshotPathJira="file:" + snapJira.replaceAll(" ", "%20");
			String reportExcelPathJira="file:" + reportJira.replaceAll(" ", "%20");
			
			
			System.out.println("snapshotPathJira:"+ snapshotPathJira);
			System.out.println("reportExcelPathJira:"+ reportExcelPathJira);
			String htmlmessageJira ="Hi,\n" +  
						"Please find below snapshot and excel report link:\n\n" + 
						"\nSnapshot Link: \n " +  snapshotPathJira + " \n\n" +  	
						"\nExcel Report: \n " +  reportExcelPathJira  + " \n\n" + 
						"\nThanks & Regards,\n"+ 
						"QBENA Automation Team";
			
			String jira_comments = htmlmessageJira;
			
			
			invokePutMethod(auth, BASE_URL+"/rest/raven/1.0/api/testrun/" + jiratestCaseID
					+ "/comment", jira_comments);
			
			
			//Comments updates:
			
			//rest/raven/1.0/api/testrun/{id}/comment
			/* {
				   "raw":"this is the new test run comment.",
				   "rendered":"<p>this is the new test run comment.</p>"
				} 
			try {
				invokePutMethod(auth, BASE_URL+"/rest/raven/1.0/api/testrun/" + jiratestCaseID
						+ "/status?status=" + jira_Status, "");
			} catch (AuthenticationException | ClientHandlerException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
			*/
			
			TestController.claimNo="";
			snapshotPath="";
			reportExcelPath = "";
			htmlmessage="";
			
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		 execute="N";
		 extent.flush();
		}	

	}// End of after test
	
	@AfterTest
	public void sendDatasheetstoShareDrive() 
	{
		String status = "";
			String SheetPath,SheetPathShared,SheetPathFolder ;
			SheetPath = Harness.gs_data_path+"\\Datasheet.xlsx";
			SheetPathFolder = extentreportpathFolder;
			SheetPathShared = extentreportpathFolder+"\\Datasheet.xlsx";
			try {

				//Copy pasting the file from test data folder to result folder to ease the report and verification
				File f3 = new File(SheetPathShared );
				File f4 = new File(SheetPath );
//				if (f3.exists() && !f3.isDirectory()) 
//				{
//				   System.out.println(SheetPathShared + "File is present");
//				   }
//				else
					//{
					try {
						copy(f4, f3);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				//}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
	
	
	@AfterClass
	public void reportingFinalSettlement() 
	{
		try {
				// Thread.sleep(3000);
				// driver.close();
				// driver.quit();
				//Runtime.getRuntime().exec("taskkill /F /IM IEDriverServer.exe");
			   // Runtime.getRuntime().exec("taskkill /F /IM iexplore.exe");
				// obj_close.BROWSER_CLOSE("");
			    extent.flush();
			} catch (Exception e) {
				LOG.error("Exception in After method" + e.toString());
			}
	
		
		// Sending the Extentreport to Stakeholders
		//String filePath = extentreportpath;
		String filePath=DataExcelPath;
		String subject = "GWCC_Automation Execution Result in Slave "  + slavePOM ;
		/*
		 * Email.sendMailWithAtt(subject, "Hi All," + "\n" + "\n" +
		 * "GWCC_Automation Execution Result" + "\n" + "\n" + "Regards," + "\n" +
		 * "GWCC Automation Team"+ "\n" + "\n" + filePath , filePath);
		 */

		
	}

	public static Object[][] getTableArray(String FilePath, String SheetName) throws Exception {
		String[][] tabArray = null;
		
		try {
			FileInputStream ExcelFile = new FileInputStream(FilePath);
			// Access the required test data sheet
			ExcelWBook = new XSSFWorkbook(ExcelFile);
			ExcelWSheet = ExcelWBook.getSheet(SheetName);
			int startRow = 1;
			int startCol = 0;
			int ci, cj;
			int totalRows = ExcelWSheet.getLastRowNum();
			// you can write a function as well to get Column count
			int totalCols = 5;
			tabArray = new String[totalRows][totalCols+1];
			ci = 0;

			for (int i = startRow; i <= totalRows; i++, ci++) {
				cj = 0;
				for (int j = startCol; j <= totalCols; j++, cj++) {
					tabArray[ci][cj] = getCellData(i, j);
					//System.out.println(tabArray[ci][cj]);
				}
			}
		}

		catch (FileNotFoundException e) {
			System.out.println("Could not read the Excel sheet");
			e.printStackTrace();
		}
		catch (IOException e) {
			System.out.println("Could not read the Excel sheet");
			e.printStackTrace();
		}
		catch (Exception e) {
			System.out.println("Could not read the Excel sheet");
			e.printStackTrace();
		}
		return (tabArray);
	}

	public static String getCellData(int RowNum, int ColNum) throws Exception {
		 
		 try{
			 Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);	 
			 @SuppressWarnings("deprecation")
			 int dataType = Cell.getCellType();
			 if  (dataType == 3) 
			 {
				 return "";
			 }else
			 {
			 String CellData = Cell.getStringCellValue();
			 	return CellData;
			 }
		 }
		 catch (Exception e)
		 {
			 System.out.println(e.getMessage());
			 throw (e);
		 }
		 }
	
	@DataProvider
    public Object[][] testcasesList() throws Exception{
         Object[][] testObjArray = getTableArray(DataSheetPath, "Execution" );
         return (testObjArray);	
	}

	
	private static void copy(File src, File dest) throws IOException {
        InputStream is = null;
        OutputStream os = null;
        try {
            is = new FileInputStream(src);
            os = new FileOutputStream(dest);

            // buffer size 1K
            byte[] buf = new byte[2056];

            int bytesRead;
            while ((bytesRead = is.read(buf)) > 0) {
                os.write(buf, 0, bytesRead);
            }
        } finally {
            is.close();
            os.close();
        }
    }
	

	private static String invokeGetMethod(String auth, String url) throws AuthenticationException, ClientHandlerException {
		Client client = Client.create();
		WebResource webResource = client.resource(url);
		ClientResponse response = webResource.header("Authorization", "Basic " + auth).type("application/json")
				.accept("application/json").get(ClientResponse.class);
		int statusCode = response.getStatus();
		if (statusCode == 401) {
			throw new AuthenticationException("Invalid Username or Password");
		}
		return response.getEntity(String.class);
	}
	
	private static String invokePostMethod(String auth, String url, String data) throws AuthenticationException, ClientHandlerException {
		Client client = Client.create();
		WebResource webResource = client.resource(url);
		ClientResponse response = webResource.header("Authorization", "Basic " + auth).type("application/json")
				.accept("application/json").post(ClientResponse.class, data);
		int statusCode = response.getStatus();
		if (statusCode == 401) {
			throw new AuthenticationException("Invalid Username or Password");
		}
		return response.getEntity(String.class);
	}
	
	private static void invokePutMethod(String auth, String url, String data) throws AuthenticationException, ClientHandlerException {
		Client client = Client.create();
		WebResource webResource = client.resource(url);
		ClientResponse response = webResource.header("Authorization", "Basic " + auth).type("application/json")
				.accept("application/json").put(ClientResponse.class, data);
		int statusCode = response.getStatus();
		if (statusCode == 401) {
			throw new AuthenticationException("Invalid Username or Password");
		}
	}
	
	private static void invokeDeleteMethod(String auth, String url) throws AuthenticationException, ClientHandlerException {
		Client client = Client.create();
		WebResource webResource = client.resource(url);
		ClientResponse response = webResource.header("Authorization", "Basic " + auth).type("application/json")
				.accept("application/json").delete(ClientResponse.class);
		int statusCode = response.getStatus();
		if (statusCode == 401) {
			throw new AuthenticationException("Invalid Username or Password");
		}
	}

	
}
