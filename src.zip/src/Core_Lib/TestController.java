package Core_Lib;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import Core_Lib.GenericLibrary;

import base.runtimeRepo;

//This class will read excel data and does parsing based on the delimiter semicolon
public class TestController 
{
//	public static boolean lb_script_Continue = true; // added by shan
	public static String claimNo="";
	public static String raw_testcaseName = "";
	
	public void TEST_CONTROLLER(String  ls_CasePath, String ls_test_case, String ls_applicationName,String executionType) 
	{
			//LOGGER
			Logger LOG = Logger.getLogger(TestController.class.getName());
			
			//Reporting
			GenericLibrary obj_Generic = new GenericLibrary();
			String report_file = Harness.report_testcase;
			List<String> report_data = new ArrayList<String>();
			String report_type=Harness.ls_ReportingType;
			
			String ls_Msg = null,ls_FunctionName="TEST_CONTROLLER",ls_Status=null,ls_actual = null,ls_expected = null,ls_objectname;	
		
			File_Exists obj_file = new File_Exists();			//creating object for File Exists class
			//ls_test_case=ls_test_case.substring(ls_test_case.indexOf("_", 1)+1,ls_test_case.length());
			String filepath =  "";		//Assigning the testcase path to String variable filepath
			String sheetname = "Sheet1";						//Assigning the sheetname  String varriable sheetname
			raw_testcaseName=ls_test_case;
			runtimeRepo run=null;
			
			boolean RunTimeRepoStatus=false;
			if(executionType.equalsIgnoreCase("data"))
			{
				ls_test_case=ls_test_case.substring(ls_test_case.indexOf("_", 1)+1,ls_test_case.length());
				filepath =  ls_CasePath+ "\\" + ls_test_case;
			}
			else
			{
				filepath =  ls_CasePath+ "\\" + ls_test_case;
			}
			System.out.println("Test Case Fiel Path:" +filepath );
			
			boolean lb_CheckFile;
			boolean lb_Result = false ; 						// This hold the return value from screen driver
			
			//File operation
			File ls_case_file = new File(filepath);
			
			FileInputStream file_open = null;
			
			boolean lb_script_Continue = Harness.lb_script_Continue;
			try
			{	//reading data from data sheet excel
				if (Harness.gi_DATASOURCE.equalsIgnoreCase("EXCLSOURCE")) 
				{
					Harness.gs_EXCL_INPUTcurrentstart= 0; 		//initializing input current count to 0
					Harness.gs_EXCL_OUTPUTcurrentstart = 0;		//initializing output current count to 0
				    
				    Get_TestData_Details obj_testdata = new Get_TestData_Details();    // creating object for get_testdata_details class

				    obj_testdata.GET_TESTDATA_DETAILS(Harness.ls_TestdatasheetPath,Harness.ls_Testcaseid,"I");		// call to GET_TESTDATA_DETAILS() method for input values
				    
				    obj_testdata.GET_TESTDATA_DETAILS(Harness.ls_TestdatasheetPath,Harness.ls_Testcaseid,"O");		// call to GET_TESTDATA_DETAILS() method for output values
				     
				 }//data sheet
				
				//checking the file exist or not
				lb_CheckFile=obj_file.FILE_EXISTS(filepath);
//				Assert.assertTrue(lb_CheckFile, "The TesCase Excel file is not Exists in TestController Function" + filepath);//Assertion
				
				//  ****if file exists  import data from the excel sheet****
				if (lb_CheckFile==true)
					{
								file_open = new FileInputStream(ls_case_file);
								
								//Creating Object to get the workbook from excel
								Workbook ls_excel_book = WorkbookFactory.create(file_open);
								
								//In Excel Book getting particular Sheet
								Sheet ls_excel_sheet = ls_excel_book.getSheet(sheetname);
							
								
								//getting the no of rows in the sheet
								int rowcount = ls_excel_sheet.getLastRowNum();
								
								String inputparameter = null;
								String outputparameter = null;
								String[] input_parameter_array = null;									//This array holds input parameter values passed to Parser to spilit
								String[] output_parameter_array = null;									//This array holds output parameter values passed to Parser to spilit
								Map<String, String> inputmap =new LinkedHashMap<String, String>();		//This map holds  input parameter array values after spiliting 
								Map<String, String> outputmap = new LinkedHashMap<String, String>();	//This map holds output parameter array values after spiliting
								String ls_componentname = null;		
								//This variable holds the component name from parser
								
								//Preparing the runtime variables and class here
								String currDir = System.getProperty("user.dir");
								String RunTimeRepoPath=currDir + "\\testData\\" + ls_applicationName + "\\dataRepo.xlsx";
								run=new runtimeRepo(RunTimeRepoPath);
								RunTimeRepoStatus=run.initilizeMap("start","value");
								
								if(RunTimeRepoStatus && run.repoDataFileExists)
								{
									run.readExcelAndStore(raw_testcaseName);
								}
								
								/*if(RunTimeRepoStatus && run.repoDataFileExists)
								{
									run.storeTheRuntimeValueToExcel(raw_testcaseName);
								}*/
								
								
								for (int ls_loop = 1; ls_loop <= rowcount; ls_loop++) 
									{
									if(lb_script_Continue)
									{
										// get the componentname from excel
										String  ls_component =(GenericLibrary.getExcelData(filepath, ls_excel_sheet, ls_loop, 1));
						 
										// get the input parameter from the excel
										 inputparameter = GenericLibrary.getExcelData(filepath, ls_excel_sheet,ls_loop, 2);
										
										// 	get the output parameter from excel
										 outputparameter = GenericLibrary.getExcelData(filepath, ls_excel_sheet, ls_loop, 3);

									 //Added by Ambika on 15/10/2018 for Excl reporting
										if(ls_component.equals(""))
										{
											ls_Msg="The Component name  is Empty line the row number " + ls_loop;
											ls_Status="Fail";
											ls_expected="Component Name";
											ls_actual=ls_component;
											break;
										}
										else if(inputparameter.equals(""))
										{
											ls_Msg="The Input parameter  is Empty line the row number " + ls_loop;
											ls_Status="Fail";
											ls_expected="InputParameter";
											ls_actual=inputparameter;
											
											break;
										}
										else if (outputparameter.equals(""))
										{
											ls_Msg="The Output parameter  is Empty line the row number " + ls_loop;
											ls_Status="Fail";
											ls_expected="OutputParameter";
											ls_actual=outputparameter;
											break;
										}// end of if 
										else
										{
											ls_Status="pass";
										}
										ls_componentname =ls_component.replaceAll(";", "");
										
										//Removing the delimiter <> in excel file
										inputparameter=inputparameter.replaceAll("<", "");
										//Splitting the input parameter using the delimiter
										input_parameter_array = inputparameter.split(">;");	
										//creating object for Parser class to Call parser method to Split
										
										//Removing the delimiter <> in excel file
										outputparameter=outputparameter.replaceAll("<", "");
										//LOG.info("outputparameter"+outputparameter);
										output_parameter_array = outputparameter.split(">;");
										//LOG.info("output_parameter_array"+output_parameter_array);
										
										Parser parseobject= new Parser();
										//Calling the parser method for input parameter array to split 
										inputmap=parseobject.parser(input_parameter_array,"Input_Parameter");
										//Calling the parser method for output parameter array to spilit 
										outputmap=parseobject.parser(output_parameter_array,"Expected_Output");
										
										//Creating object for ScreenDriver to call screendriver method 
										ScreenDriver screenObject = new ScreenDriver();
										/*//calling ScreenDriver 
										WebDriver driver = Browser_Invoke_Url.driver;
										driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);*/

										lb_Result = screenObject.SCREEN_DRIVER(ls_componentname, inputmap,outputmap,ls_CasePath,ls_applicationName);
									
										
										if(lb_Result)
										{
											ls_Msg = "Screen driver call in Testcontroller has Passed";
								    		LOG.info(ls_Msg);
								    		ls_Status = "Pass";	
										}
										else
										{
											
											lb_script_Continue = false;
											ScreenDriver Scr= new ScreenDriver();
											Scr.Screenshot(ScreenDriver.scr_driver, "Failure");
										} 
										
									} // End if script continue	
									else
									{
										break;
									}// End if script continue	
									
									}// For close
							        
					}//if close
							 
							     
					//final verification
							  
			}
			catch(Exception e)
			{
					LOG.error("EXCEPTION IN TEST CONTROLLER FUNCTION");
			}//catch
			
			finally
			{
				if(file_open!=null)
				try 
				{
					file_open.close();
					if(RunTimeRepoStatus && run.repoDataFileExists)
					{
						run.storeTheRuntimeValueToExcel(raw_testcaseName);
						claimNo=run.getTheValue("run_claimno");
						//Cleaning the map
						run.variableValue.clear();
					}
				}
				catch (IOException e) 
				{
					LOG.error("EXCEPTION IN FILE CLOSING");
								
				}//CATCH OF FILE CLOSE
			}//finally
			
			if(report_type.equals("DETAIL")&&ls_Status.equals("Fail"))
			{
				//for Excel detail reporting
				report_data.add(ls_FunctionName);//Function Name
				report_data.add("");//object name
				report_data.add(ls_expected);//Expected
				report_data.add(ls_actual);//Actual
				report_data.add(ls_Msg);//Detail
				report_data.add(ls_Status);//Status
				obj_Generic.Report(report_file,report_data );
				
				lb_script_Continue = false;
				
//				Assert.assertTrue(false, "The Testcase excel file has empty cell");
			}
						
	}//method end 
		
}//class end	
			
			
		
		
		




