package Core_Lib;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.testng.Assert;


//This function retrieves a stored value from the file. 
public class Get_Stored_Variable

{
	public String GET_STORED_VARIABLE(String ls_Variable)
     {
		//LOGGER
		Logger LOG = Logger.getLogger(Get_Property_Value.class.getName());
		
		//Detail Reporting
		 GenericLibrary obj_Generic = new GenericLibrary();
		 String report_file = Harness.report_testcase;
		 List<String> report_data = new ArrayList<String>();
		 String report_type=Harness.ls_ReportingType;
		 String ls_Functionname="BROWSER_INVOKEURL";
		 String ls_Msg=null;
		 String ls_status=null;
		 
		 String  ls_textFromFile; 
		 String[] ls_textformfile;		// Holds the text file contents
		 String  lb_Return;              //  Holds the return value
		 String filepath;				//  Holds the message string
		 String gs_data_path;
		 boolean lb_file=false;
			
		 ls_Variable = ls_Variable.substring(0, ls_Variable.length());

		//Create object
		File_Exists obj_file = new File_Exists();
		gs_data_path=Harness.gs_data_path;
		filepath =gs_data_path + "/StoredNums.txt";
		FileInputStream ls_file = null;
		
		//Calling the File_Exist Function
		lb_file=obj_file.FILE_EXISTS(filepath);
		
		/* //validation
		 Assert.assertTrue(lb_file, "The stored num text file does not exists in GET STORED VARIABLE Function ");*/

		 try
		 {
			 ls_file = new FileInputStream(filepath);
		   
		   //Verifying the file exists
		   if (ls_file!=null)
		   {
	    	BufferedReader textstream = new  BufferedReader( new InputStreamReader(ls_file));
	    	// read each line till not null
			while(textstream.readLine()!= null)
			{
				ls_textFromFile = textstream.readLine();
				ls_textformfile = ls_textFromFile.split(",");
		        if ( ls_Variable.equals(ls_textformfile[0])) 
		        {
				    lb_Return =  ls_textformfile[1];
				    ls_Variable = lb_Return.trim();
		 		}// if close
		        
		   }//While
			
	    }// If ls_file
		   
		 } catch (IOException e) {
				LOG.error("Exception in Reading StoredNum File in GetStoredVariable Function");
		 }catch(Exception e)
		 {
	   		 LOG.error("Exception of FileInputStream in GET_STORED_VARIABLE Function");
	   	  }//catch block
		 if(ls_Variable!=null)
		 {
			 ls_Msg="The variable value successfully read from the Dictionary";
			 ls_status="Pass";
		 }else
		 {
			 ls_Msg="Unable the get the value from the dictionary";
			 ls_status="Fail";
		 }
		 if(report_type.equals("DETAIL"))
			{
				//for Excl DETAIL reporting
				report_data.add(ls_Functionname);
				report_data.add("");
				report_data.add("");
				report_data.add(ls_Variable);
				report_data.add(ls_Msg);
				report_data.add(ls_status);
				obj_Generic.Report(report_file,report_data );
			}//if of report
		//Validation
		 Assert.assertNotNull(ls_file, "The StoredNum file is not found in GetStoredVariable Function");
		//Validation
		 Assert.assertNotNull(ls_Variable, "The StoredNum file is not found in GetStoredVariable Function");
	return ls_Variable;
     }// method close

}// class close
