package Core_Lib;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;

import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.Assert;

import Core_Lib.GenericLibrary;

public class Return_Rownum {


	public int Return_rownum_Datasheet()
	{
		Logger LOG = Logger.getLogger(Store_Value_Variable.class.getName());
		
		String gs_data_path;  				// holds the data path
		String ls_Variable; 
		String dataFile;
		String row_value;
		int rownum = 0;
		boolean lb_file=false;

		File_Exists obj_file = new File_Exists();

		gs_data_path=Harness.gs_data_path;
		dataFile = Harness.ls_TestdatasheetPath;
		row_value = Harness.ls_Testcaseid;


		try
		{
			File file = new File(dataFile);
			FileInputStream fis = new FileInputStream(file);

			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sheet = wb.getSheet("RuntimeValues");

			int rowcount = sheet.getLastRowNum();

			for(int i=0;i<=rowcount;i++)
			{
				XSSFRow row = sheet.getRow(i);
				XSSFCell cell = row.getCell(0);

				String celld = cell.getStringCellValue();
				if(celld.equals(row_value))
				{
					rownum = i;
					break;
				}
			}
			wb.close();
		}
		catch(Exception e)
		{
			LOG.error("The testcase name was not found in the "+dataFile);
		}


		return rownum;


	}
}