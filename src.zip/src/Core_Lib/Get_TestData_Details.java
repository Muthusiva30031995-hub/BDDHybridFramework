package Core_Lib;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.apache.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.testng.Assert;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import Core_Lib.GenericLibrary;

// This function reads the excel file and imports the data to datatable to a dictionary object
public class Get_TestData_Details

{
	public static boolean case_status = false;
	
	public void GET_TESTDATA_DETAILS(String ls_TestdatasheetPath,String ls_Testcaseid,String ls_sheetID) 
	{
		//LOGGER
		Logger LOG = Logger.getLogger(Get_TestData_Details.class.getName());
		
		//Detail Reporting
		 GenericLibrary obj_Generic = new GenericLibrary();
		 String report_file = Harness.report_testcase;
		 List<String> report_data = new ArrayList<String>();
		 String report_type=Harness.ls_ReportingType;
		 String ls_Functionname="GET_TESTDATA_DETAILS";
		 String ls_Msg=null;
		 String ls_status=null;
		
		
		String ls_TestcaseName=ls_Testcaseid;
		String   ls_paremeterprefix;
		String ls_sheetname = null;
		int  ls_datasheetid;
		int li_columnnumbertofetch;
		int li_rownumbertofetch;
		String ls_FoundCellObj = null;
		int li_inputvalueindex;
		int  li_valueindex;
		int  li_index = 0;
		int li_columincrement;
		int li_column_value = 0;
		String ls_Inputvalue = null;
		String ls_Fieldname = null;
		String ls_Value = null;
		String ls_Textvalue = null;
		String case_name = null;
		Sheet ls_excel_sheet = null;
		
		boolean lb_testcasefound;
		boolean ls_CheckFile = false;
		
		FileInputStream file_open = null;
		Workbook ls_excel_book = null;
		
		File_Exists gfn_FILE_EXISTS=new File_Exists();
		
		
			ls_CheckFile=gfn_FILE_EXISTS.FILE_EXISTS(ls_TestdatasheetPath);
		
		
		try 
		{
			file_open = new FileInputStream(ls_TestdatasheetPath);
			ls_excel_book = WorkbookFactory.create(file_open);
			
			//'this is the name of  Sheet  in Excel file "Datasheet.xlsx"   where data needs to be entered 
         	if (ls_sheetID.trim().equalsIgnoreCase("I"))
			{
				//LOG.info("SHEET ID is I");
				ls_sheetname="Input";
				ls_datasheetid=1;
				ls_paremeterprefix="Input";
				li_column_value=3;
				
			} else if(ls_sheetID.equalsIgnoreCase("O"))          
			  {
				//LOG.info("SHEET ID is O");
				ls_sheetname="Expectedoutput";
				ls_datasheetid=2;
				ls_paremeterprefix="Output";
				li_column_value=3;
			   }//else
			
			 ls_excel_sheet = ls_excel_book.getSheet(ls_sheetname);
			li_rownumbertofetch= ls_excel_sheet.getLastRowNum();
				
			for(int li_loop=1;li_loop<=li_rownumbertofetch;li_loop++)
			{
					 case_name = GenericLibrary.getExcelData(ls_TestdatasheetPath, ls_excel_sheet, li_loop, 0);
				
				if(case_name.trim().equalsIgnoreCase(ls_TestcaseName.trim()))
				{
					case_status=true;
					//LOG.info(ls_TestcaseName+" FOUND IN DATA SHEET");
					
					li_columnnumbertofetch=ls_excel_sheet.getRow(li_loop).getLastCellNum();
					//LOG.info("NUMBER OF Columns IN DATASHEET"+li_columnnumbertofetch);
					
					//' minus 1 means to exclude the column 1 - it contains test case id 
					li_columnnumbertofetch=(li_columnnumbertofetch-1);
					
					for (int ls_loop = 1; ls_loop <= li_columnnumbertofetch; ls_loop++) 
					{
						ls_FoundCellObj =GenericLibrary.getExcelData(ls_TestdatasheetPath, ls_excel_sheet, 1, ls_loop);
						
						//'Checks specified test case is exists or not in the test data sheet in order to fetch data
						if(!(ls_FoundCellObj).equals(""))
						{
							li_rownumbertofetch=ls_excel_sheet.getLastRowNum();
							lb_testcasefound=true;
							
						} else 
						  {
							lb_testcasefound=false;
						  }//else of ls_FoundCellObj
	
						//Assert.assertTrue(lb_testcasefound, "The testcase not found in DataSheet ");
						
						if(case_status) 
						{
							li_inputvalueindex =0;
							li_valueindex = 1;
							
							for(li_columincrement=li_column_value;li_columincrement<=li_columnnumbertofetch;li_columincrement++)
							{
								li_inputvalueindex= li_columincrement + li_index-1;
								li_valueindex= li_columincrement + li_index;
								
								try
								{
									ls_Inputvalue   = (GenericLibrary.getExcelData(ls_TestdatasheetPath, ls_excel_sheet, li_loop, li_inputvalueindex));
									//LOG.info("THE INPUT PARAMETER IS  "+ls_Inputvalue);
								}catch(Exception e)
									{
											LOG.error("The Input is not found in Get_Testdata_Details Function");
									}//END OF  CATCH

								//VALIDATION
								//Assert.assertNotNull(ls_Inputvalue, "The Input value is null in GetTestdatadetails Function");
								
								try
								{
									ls_Value=GenericLibrary.getExcelData(ls_TestdatasheetPath,ls_excel_sheet,li_loop,li_valueindex); //Ashokan modified the code to take the formatted value from the cell instead the raw value
									//LOG.info("THE INPUT PARAMETER VALUE IS  "+ls_Value);
								}catch(Exception e)
									{
										LOG.error("The Input is not found in Get_Testdata_Details Function");
									}//END OF CATCH

								//VALIDATION
								//Assert.assertNotNull(ls_Value, "The  value is null in GetTestdatadetails Function");
								
								//if (ls_Value==null||ls_Inputvalue==null) 
									//break;
	                                             
								if ( li_columincrement==2) 
								{
	                               ls_Fieldname=ls_Inputvalue;
	                               ls_Textvalue=ls_Value;
	                               
								} else 
	                             {
	                                 ls_Fieldname=ls_Fieldname+"##"+ls_Inputvalue;
	                                 ls_Textvalue=ls_Textvalue+"##"+ls_Value;
	                                 
	                             }//else of li_columincrement
								
								li_index=li_index+1;
								
								 if (ls_Inputvalue==null) 
			                     {
									break;
									
							      }//if of ls_Inputvalue
							 }//for of Li_columnincrement
							
							 
							 if (ls_sheetID.equalsIgnoreCase("I"))
							 {
								 	 
							 	Harness.gs_EXCLInputFieldname=ls_Fieldname.split("##");	
							 	Harness.gs_EXCLInputvalue=ls_Textvalue.split("##");
								    
							 }else if (ls_sheetID.equalsIgnoreCase("O")) 
							  {
								 
							 	 Harness.gs_EXCLOutputFieldname=ls_Fieldname.split("##");
								 Harness.gs_EXCLOutputvalue=ls_Textvalue.split("##");
								 
							  } // else of ls sheet
							 
							
							
						}//if oflb_testcasefound
						 if (ls_Inputvalue==null) 
	                     {
							break;
							
					      }//if of ls_Inputvalue
					}//for of ls_loop			
	                           
				}// if of comparing test case name
				
				
			}//for loop of li_loop	
			
		
		} catch (EncryptedDocumentException e) {
			LOG.error("EncryptedDocumentException in WorkbookFactory of GetTestDataDeatil Function");
		} catch (InvalidFormatException e)
		  {
			LOG.error("InvalidFormatException in WorkbookFactory of GetTestDataDeatil Function");
		  } catch (IOException e)
		{
			LOG.error("IOException in WorkbookFactory of GetTestDataDeatil Function");
		
		}//end of catch
		finally
		{
			if(file_open!=null)
				try {
						
						file_open.close();
						
					} catch (IOException e) 
			
						{
							LOG.error("EXCEPTION IN FILE CLOSING");
							
						}//CATCH OF FILE CLOSE
		}//finally
		if(case_status)
		{
			ls_Msg="The Testcase found in the DataSheet";
			ls_status="Pass";
		}else
		{
			ls_Msg="The Testcase not found in the DataSheet";
			ls_status="Fail";
		}//else
		if(report_type.equals("DETAIL"))
		{
			//for Excl DETAIL reporting
			report_data.add(ls_Functionname);
			report_data.add("");
			report_data.add(ls_TestcaseName);
			report_data.add("");
			report_data.add(ls_Msg);
			report_data.add(ls_status);
			obj_Generic.Report(report_file,report_data );
		}//if of report
		Assert.assertTrue(case_status, ls_TestcaseName+" is Not found in Data Sheet");
	}//End Function

}// end of class 

