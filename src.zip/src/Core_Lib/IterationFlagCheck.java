package Core_Lib;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.Assert;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class IterationFlagCheck
{
    public List<String> gfn_GetIteartionCount(String DataSheetPath , String TestCaseName)
    {
    	Workbook workbook;
    	Sheet InputSheet, ExpectedOutputSheet;
    	int i, li_RC;
        String ls_TestId_Input, ls_Flag_Input, ls_TestId_Expected, ls_Flag_Expected, ls_FlagExp;
        Row currentRowIP, currentRowOP;
        List<String> TestId = new ArrayList<String>();
        boolean bln_TestidCheck = false;
        try
        {
        	
        	 //Added by Ambika on 12/1/2018 to validate file exist or not
            File_Exists obj_file = new File_Exists();
            obj_file.FILE_EXISTS(DataSheetPath);
        	
            FileInputStream excelFile = new FileInputStream(new File(DataSheetPath));

           
            
            if (DataSheetPath.endsWith("xlsx"))
            {
                workbook = new XSSFWorkbook(excelFile);
            } 
            else if (DataSheetPath.endsWith("xls")) 
            {
                workbook = new HSSFWorkbook(excelFile);
            } 
            else
            {
                throw new IllegalArgumentException("The specified file is not Excel file");
            }

            InputSheet = workbook.getSheetAt(0);
            ExpectedOutputSheet = workbook.getSheetAt(1);
            
            li_RC = InputSheet.getLastRowNum();
            
            TestCaseName = TestCaseName + "_TD";
            
            for(i = 1 ; i <= li_RC ; i++)
            {            	
            	currentRowIP = InputSheet.getRow(i);
            	currentRowOP = ExpectedOutputSheet.getRow(i);

            	ls_TestId_Input = currentRowIP.getCell(0).getStringCellValue();
            	ls_Flag_Input = currentRowIP.getCell(1).getStringCellValue();
            	ls_TestId_Expected = currentRowOP.getCell(0).getStringCellValue();
            	ls_Flag_Expected = currentRowOP.getCell(1).getStringCellValue();
            	
            	ls_FlagExp = "Y";
            	 
            	if((ls_TestId_Input.equals(ls_TestId_Expected)) && (ls_Flag_Input.equalsIgnoreCase(ls_Flag_Expected)))
            	{
            		if((ls_TestId_Input.contains(TestCaseName)) && (ls_Flag_Input.equalsIgnoreCase(ls_FlagExp)))
            		{
            			TestId.add(ls_TestId_Input);
            			bln_TestidCheck = true;
            		}
//            		ls_value = String.valueOf(j);
            	}
            	else
            	{
            		TestId.add("Test flag doesn't set correctly for both Input and Expected in DataSheet"+" in the Row Number: "+(i+1));
            		bln_TestidCheck = true;
            		break;
            	}
            }
            if(!bln_TestidCheck)
            {
            	TestId.add("Test case was not avaialable in the datasheet");
            }
            excelFile.close();   
        } 
        catch (FileNotFoundException e) 
        {
            e.printStackTrace();
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        }
        return TestId;
    }
}