package Core_Lib;

import java.io.File;
import java.util.ArrayList;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.*;
import java.io.IOException;
import Core_Lib.ReadFromXLSX;

public class AddingForm 
{
	public ArrayList<String> arr_list = new ArrayList<String>();
	public ArrayList<String> Form_Prem = new ArrayList<String>();
	int arr_size;
	public String iniFilePathData = System.getProperty("user.dir")+"/QBE_NA_XM Regression Test Automation/Data_Lib/" ;
	CompareFormValue compare_form = new CompareFormValue();
	public void AddingForm() throws Exception
	{
		String a = GenericLibrary.pdf_filename;
		//PDDocument document = PDDocument.load(new File("C:/Users/E00724E/SeleniumWorkspace/XM_AUTOMATION/QBE_NA_XM Regression Test Automation/Data_Lib/"+a+".pdf"
		
		
	try (PDDocument document = PDDocument.load(new File(iniFilePathData+a+".pdf"))) {

        document.getClass();

        if (!document.isEncrypted()) {
		
            PDFTextStripperByArea stripper = new PDFTextStripperByArea();
            stripper.setSortByPosition(true);

            PDFTextStripper tStripper = new PDFTextStripper();

            String pdfFileInText = tStripper.getText(document);
            //System.out.println("Text:" + st);

			// split by whitespace
            int i=0;
            String lines[] = pdfFileInText.split("\\r?\\n");
            
            int form_count=0;
            int prem_count=0;
            
			/*ArrayList<String> arr_list = new ArrayList<String>();
			ArrayList<String> Form_Prem = new ArrayList<String>();*/
			String[] Form_Premium = null;
			int line_count=0;
			int arr_count = 0;
            for (String line : lines) {
            	
                //System.out.println(line);
                line_count++;
            	
            	if(i==0)
                {
                    if(line.contains("Policy Endorsements"))
                    {
                    	//Muthu-thread.sleep(2000);
                    	i=i+2;
                    	
                    }
                }
                if(i>1)
                {
                	
                		
                	
                	String Form_Num = null;
                	
                	//System.out.println(line);
                	int asteric_No = line.indexOf("*");
                	int bracket_No = line.indexOf("(");
                	int Colon_No = line.indexOf(":");
                	
                	if(line.contains("Total")&& line.contains("Endorsement")&& line.contains("Premium"))
                	{
                		break;
                	}
                	if(bracket_No !=-1)
                	{
                		
                		
                		String Form_Number = line.substring(0,bracket_No);
                		//System.out.println(Form_Number);
                		int num_count=0;
                		if(Form_Number.contains("*"))
            			{
                		
                			if(line.contains("$"))
                			{
                
								num_count++;
                			
                    			Form_Premium = line.split(" ");
                        		for(String single_char: Form_Premium)
                            	{
                            		if(single_char.contains("$"))
                            		{
                            			//System.out.println(single_char);
                            			
                            			Form_Prem.add(single_char);
                            			prem_count++;
                            		}
                            	}
                			}
                			else
                			{
                				Form_Premium = line.split(" ");
                				if(Form_Premium.length<8)
                				{
                					System.out.println("Expecting line breakage in title");
                					System.out.println(lines[line_count-1]);
                					int count_of_nextLine_bracket = lines[line_count].indexOf("*");
                					int count_of_nextLine2_bracket = lines[line_count+1].indexOf("*");
                					int count_of_nextLine3_bracket = lines[line_count+2].indexOf("*");
                					int count_of_nextLine4_bracket = lines[line_count+3].indexOf("*");
                					if(!(lines[line_count+1].contains("$")))
                					{
                						if((count_of_nextLine3_bracket==-1))
                						{	
                    						if((lines[line_count+2].contains("$")))
                    						{
                    							Form_Premium = lines[line_count+2].split(" ");
                	                    		for(String single_char: Form_Premium)
                	                        	{
                	                        		if(single_char.contains("$"))
                	                        		{
                	                        			//System.out.println(single_char);
                	                        			Form_Prem.add(single_char);
                	                        			prem_count++;
                	                        		}
                	                        	}
                    						}
                    						else 
                    						{
                    							if((count_of_nextLine4_bracket==-1))
                        						{	
    	                    						if((lines[line_count+3].contains("$")))
    	                    						{
    	                    							Form_Premium = lines[line_count+3].split(" ");
    	                	                    		for(String single_char: Form_Premium)
    	                	                        	{
    	                	                        		if(single_char.contains("$"))
    	                	                        		{
    	                	                        			//System.out.println(single_char);
    	                	                        			Form_Prem.add(single_char);
    	                	                        			prem_count++;
    	                	                        		}
    	                	                        	}
    	                    						}
    	                    						else
    	                    						{
    	                    							Form_Prem.add("");
	                        							prem_count++;
    	                    						}
                        						}
                    							else
                        						{
                        							Form_Prem.add("");
                        							prem_count++;
                        						}
                    						}
                						}
                						else
                						{
                							Form_Prem.add("");
                							prem_count++;
                						}
                					}
                					else
                					{
                						if(lines[line_count+1].contains("$"))
                						{
                							Form_Premium = lines[line_count+1].split(" ");
            	                    		for(String single_char: Form_Premium)
            	                        	{
            	                        		if(single_char.contains("$"))
            	                        		{
            	                        			//System.out.println(single_char);
            	                        			Form_Prem.add(single_char);
            	                        			prem_count++;
            	                        		}
            	                        	}
                						}
                					}
                					
                				}
                				else
                				{
                					Form_Prem.add("");
                					prem_count++;
                				}
                			}
                    		//System.out.println(Form_Premium);
                			Form_Num = line.substring(0,asteric_No);
                			
                			Form_Num = Form_Num.replaceAll("\\s", "");
                			arr_list.add(Form_Num);
                			form_count++;
                			//System.out.println(Form_Num);
                			
                		}
                		
                		
                	}
            		/*{
                		
                		int partAfterDot = line.indexOf(':');
                		
                		if(partAfterDot==-1)
                		{
                			Form_Premium = line.split(" ");
                    		for(String single_char: Form_Premium)
                        	{
                        		if(single_char.contains("$"))
                        		{
                        			//System.out.println(single_char);
                        			Form_Prem.add(single_char);
                        			prem_count++;
                        		}
                        	}
                		}
                		else
                		{
                			
                		}
            			
            		}*/
                	
                }  // before for loop of lines
                
            }
            for(String abb: arr_list)
            {
            	System.out.println(abb);
            }
            for(String abb: Form_Prem)
            {
            	System.out.println(abb);
            }
            arr_size = arr_list.size();
            System.out.println(Form_Prem.size());
            System.out.println(arr_size);
            ReadFromXLSX read_excel = new ReadFromXLSX();
			read_excel.readFromExcel(arr_list, arr_size,Form_Prem);
			
            for (int arr=0; arr<arr_list.size(); arr++) 
    		{
                System.out.print(arr_list.get(i)+" "); 
        }
            
            //compare_form.CompareFormValue(arr_list, arr_size,Form_Prem);
            
        }
        

    }
}
}