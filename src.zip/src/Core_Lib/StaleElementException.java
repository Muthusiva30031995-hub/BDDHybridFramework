package Core_Lib;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class StaleElementException {
	
	WebDriver driver;
	public void handleStaleElement(String elementName) {
		  int count = 0;
		  //It will try 4 times to find same element using name.
		  while (count < 4) {
		   try {
		    //If exception generated that means It Is not able to find element then catch block will handle It.
		    WebElement staledElement = driver.findElement(By.name(elementName));
		    //If exception not generated that means element found and element text get cleared.
		    staledElement.clear();    
		   } catch (StaleElementReferenceException e) {
		    e.toString();
		    System.out.println("Trying to recover from a stale element :" + e.getMessage());
		    count = count + 1;
		   }
		   count = count + 4;
		  }
		 }
}
