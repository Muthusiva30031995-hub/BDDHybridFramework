package Core_Lib;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class Search_Table {

	public boolean SEARCH_TABLE(WebDriver scr_driver, String ls_window, String object_name, String ls_Value,
			String col1, String col2, String optional_ERR_FLAG) throws Exception {
		// LOGGER
		Logger LOG = Logger.getLogger(Search_Table.class.getName());

		// String TableValue = null;
		WebElement WebTable = null;
		WebDriver driver = ScreenDriver.scr_driver;
		Get_Object_Identifier ls_obj = new Get_Object_Identifier();
		// Get_Table_Cell_Data obj_table = new Get_Table_Cell_Data();
		int tableSize=0;
		String datePattern = "MM/dd/yyyy";
		boolean returnStatus = false;
		try {
			// get the table object
			WebTable = ls_obj.GET_OBJECT_IDENTIFIER(driver, object_name, null, optional_ERR_FLAG);
			String[] ls_values = ls_Value.split("\\|");
			/*String Policy = ls_values[0];
			String Lossdate = ls_values[1];
			String firstName = ls_values[2];
			String lastName = ls_values[3];
			String businessName = ls_values[4];
			String streetAddress = ls_values[5];
			String state = ls_values[6];
			String zipCode = ls_values[7];
			String lossDateSearchques = ls_values[8];
			String reportedDate = ls_values[9];*/
			//String Lossdate = ls_values[10];
			
			//THB000578506|15/11/2004
			
			String Policy = "THB000578506";
			String firstName = "Alvin";
			String lastName = "COTTON";
			String businessName = "alvin";
			String streetAddress = "";
			String state = "Georgia";
			String zipCode = "30002";
			String lossDateSearchques = "N";
			String reportedDate = "11/15/2004";			
			String Lossdate = "11/15/2004";
			
			
			// If the table value does not exist report error
			// TableValue= obj_table.GET_TABLE_CELL_DATA(myContext,
			// ls_ObjectName, Rowno, Colno, optional_ERR_FLAG);

			// Validation
			// Assert.assertNotNull(TableValue, "TableValue Not Found in
			// CheckTable");

			// TableValue = TableValue.trim().toUpperCase();
			// Value =Value.trim().toLowerCase();
			List<WebElement> rows;
			try {
				rows = WebTable.findElements(By.tagName("tr"));
				tableSize = rows.size();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("**********************Exception occured while polic search**********************");
				System.out.println("Policy search not retrive any record");
				LOG.error("EXCEPTION IN CHECK TABLE FUNCTION ");
				return false;
			}

			//Check table has row more than 0
			if(tableSize > 0)
			{
				int rowNo=1;
			for (WebElement r : rows) {

				List<WebElement> values = r.findElements(By.tagName("td"));
				// int no1 =values.size();
				String PolnumberTableValue = values.get(Integer.parseInt(col1)).getText();
				String firstNameTableValue = values.get((Integer.parseInt(col1)) + 2).getText();
				String lastNameTableValue = values.get((Integer.parseInt(col1)) + 2).getText();
				String businessNameTableValue = values.get((Integer.parseInt(col1)) + 2).getText();
				String AddressTableValue = values.get((Integer.parseInt(col1)) + 3).getText();
				String streetTableValue = values.get((Integer.parseInt(col1)) + 4).getText();
				String stateTableValue = values.get((Integer.parseInt(col1)) + 5).getText();
				String zipCodeTableValue = values.get((Integer.parseInt(col1)) + 6).getText();
				String EffectiveDateTableValue = values.get(Integer.parseInt(col1) + 7).getText();
				//String lossDateSearchquesTableValue = values.get((Integer.parseInt(col1) + 8) + 1).getText();
				String expiryDateTableValue = values.get((Integer.parseInt(col1)) + 8).getText();

				System.out.println("Row Number: " + rowNo + "PolnumberTableValue : "+ PolnumberTableValue + "||" +
						"firstNameTableValue : "+ firstNameTableValue + "||" +
						"lastNameTableValue : "+ lastNameTableValue +  "||" +
						"businessNameTableValue : "+ businessNameTableValue +  "||" +
						"AddressTableValue : "+ AddressTableValue +  "||" +
						"stateTableValue : "+ stateTableValue +  "||" +
						"zipCodeTableValue : "+ zipCodeTableValue +  "||" +
						"EffectiveDateTableValue : "+ EffectiveDateTableValue +  "||" +
						"expiryDateTableValue : "+ expiryDateTableValue);
				
				//Validate the policy number
				if(Policy.equalsIgnoreCase("") || Policy.equalsIgnoreCase("") )
				{
					if ( Policy.equalsIgnoreCase(PolnumberTableValue)) 
					{
						System.out.println("Policy number("+Policy+") is macted with search table: " + PolnumberTableValue);
						//values.get(0).click();
						//return true;
						returnStatus=true;
					}else
					{
						System.out.println("Policy number("+Policy+") is not macted with search table: " + PolnumberTableValue);
						return false;
					}
				}else{
					System.out.println("Policy number("+Policy+") is not macted with search table: " + PolnumberTableValue);
					//return false;
				}
				
				//Validate the mandatory field values with table value first
				if(!firstName.equalsIgnoreCase("") )
				{
					if(!lastName.equalsIgnoreCase("") )
					{
						if ( firstNameTableValue.contains(firstName.trim()) && lastNameTableValue.contains(lastName.trim())) 
						{
							System.out.println("First Name("+firstName+") is contains with search table: " + firstNameTableValue);
							System.out.println("Last Name("+lastName+") is contains with search table: " + lastNameTableValue);
							returnStatus=true;
						}else
						{
							System.out.println("First Name("+firstName+")) is not macted with search table: " + firstNameTableValue);
							return false;
						}
					}else
					{
						if ( firstNameTableValue.contains(firstName.trim())) 
						{
							System.out.println("First Name("+firstName+") is contains with search table: " + firstNameTableValue);
							System.out.println("LastName is empty in search field");
							returnStatus=true;
						}else
						{
							System.out.println("First Name("+firstName+")) is not macted with search table: " + firstNameTableValue);
							return false;
						}
					}
				}
				//Validate the First and Last name is contains in the table value of first and last Name
				
				
				//Validate the Address 
				
				//Validate the state 
				
				//Validate the loss date
				
				//String reportedDate = "15/11/2004";			
				//String Lossdate = "15/11/2004";
		
				
				if(lossDateSearchques.equalsIgnoreCase("N") )
				{
								
					Date LossdateFormatted = dateFormatter(Lossdate,"MM/dd/yyyy");
					Date EffectiveDateTableValueFormated = dateFormatter(EffectiveDateTableValue,"MM/dd/yyyy");
					Date expiryDateTableValueFormated = dateFormatter(expiryDateTableValue,"MM/dd/yyyy");
					
					if(!Lossdate.equalsIgnoreCase(""))
					{
						if (isLessThanRange(LossdateFormatted, expiryDateTableValueFormated)) 
						{
							System.out.println("Loss Date("+LossdateFormatted+") is less than expiry date("+expiryDateTableValueFormated +
															") and Expiry Date("+ expiryDateTableValueFormated + ")" );
							returnStatus=true;
						}else
						{
							System.out.println("Loss Date("+LossdateFormatted+")  is not less than expiry date("+expiryDateTableValueFormated +
									") and Expiry Date("+ expiryDateTableValueFormated + ")" );
							return false;
						}
						//Checking the Loss Date with Expire Date 
						if (isWithinRange(LossdateFormatted, EffectiveDateTableValueFormated, expiryDateTableValueFormated)) 
						{
							System.out.println("Loss Date("+LossdateFormatted+") is between effective date("+EffectiveDateTableValueFormated +
															") and Expiry Date("+ expiryDateTableValueFormated + ")" );
							returnStatus=true;

						}else
						{
							System.out.println("Loss Date("+LossdateFormatted+") is NOT between effective date("+EffectiveDateTableValueFormated +
									") and Expiry Date("+ expiryDateTableValueFormated + ")" );
							return false;
						}
					}else
					{
						
					}
				}else if(lossDateSearchques.equalsIgnoreCase("Y") )
				{
					Date reportedDateFormatted = dateFormatter(reportedDate,"MM/dd/yyyy");			
					Date LossdateFormatted = dateFormatter(Lossdate,"MM/dd/yyyy");
					Date EffectiveDateTableValueFormated = dateFormatter(EffectiveDateTableValue,"MM/dd/yyyy");
					Date expiryDateTableValueFormated = dateFormatter(expiryDateTableValue,"MM/dd/yyyy");
					
					//Checking the Loss date
					if (isWithinRange(LossdateFormatted, EffectiveDateTableValueFormated, expiryDateTableValueFormated)) 
					{
						System.out.println("Loss Date("+LossdateFormatted+") is between effective date("+EffectiveDateTableValueFormated +
														") and Expiry Date("+ expiryDateTableValueFormated + ")" );
						returnStatus=true;
					}else
					{
						System.out.println("Loss Date("+LossdateFormatted+") is NOT between effective date("+EffectiveDateTableValueFormated +
								") and Expiry Date("+ expiryDateTableValueFormated + ")" );
						return false;
					}
					
					
					//Checking the reported date
					if (isGreaterThan(reportedDateFormatted, EffectiveDateTableValueFormated)) 
					{
						System.out.println("Reported Date("+reportedDateFormatted+") is greater than effective date("+EffectiveDateTableValueFormated
														+ ")");
						returnStatus=true;
					}else
					{
						System.out.println("Reported Date("+reportedDateFormatted+") is not greater than effective date("+EffectiveDateTableValueFormated
								+ ")");
						return false;
					}
					
					
				}
			
				rowNo++;
				}//For ends here
			}//if end here - Row couint validation
			
			
		} catch (Exception e) {
			LOG.error("EXCEPTION IN CHECK TABLE FUNCTION ");
			return false;
		} // catch
		return returnStatus;

	}// method end

	public Date dateFormatter(String dateNeedsChange, String format)
	{	
		SimpleDateFormat simpleDateFormat;
		Date dateFinal;
		try {
			simpleDateFormat = new SimpleDateFormat(format);

			dateFinal = simpleDateFormat.parse(dateNeedsChange);
			String date = simpleDateFormat.format(dateNeedsChange);
			System.out.println("Date Formatted :"+ date);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		return dateFinal;
	}
	
	
	boolean isWithinRange(Date testDate, Date startDate, Date endDate) {
			return testDate.after(startDate) && testDate.before(endDate);
		}
	
	boolean isGreaterThan(Date testDate, Date startDate) {
		return testDate.after(startDate);
	}
	
	boolean isLessThanRange(Date testDate,Date endDate) {
		return testDate.before(endDate);
		
		
	}
	
}// class end
