package Core_Lib;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;


//This function basically checks for the correctness of the data and for the not null values in the webtable
public class Check_Table
{
	public void  CHECK_TABLE(String myContext,String ls_ObjectName, String Rowno,String Colno, String Value, String optional_ERR_FLAG)
	{
		//LOGGER
		Logger LOG = Logger.getLogger(Check_Table.class.getName());
		
		 String TableValue = null;
		 WebElement WebTable = null;
		 WebDriver driver = ScreenDriver.scr_driver;  
    
		 Get_Object_Identifier ls_obj = new Get_Object_Identifier();
		 Get_Table_Cell_Data obj_table = new Get_Table_Cell_Data();
	    
		 try
		 {
	        //get the table object
			 WebTable = ls_obj.GET_OBJECT_IDENTIFIER(driver, ls_ObjectName,null, optional_ERR_FLAG);
		   		   
	        //If the table value does not exist report error
        	TableValue=  obj_table.GET_TABLE_CELL_DATA(myContext, ls_ObjectName, Rowno, Colno, optional_ERR_FLAG);

        	//Validation
	        //Assert.assertNotNull(TableValue, "TableValue Not Found in CheckTable");
	        
	        TableValue = TableValue.trim().toUpperCase();
	        Value =Value.trim().toLowerCase();

	   }catch(Exception e)
	    {
		  LOG.error("EXCEPTION IN CHECK TABLE FUNCTION "); 
	     }// catch

     }//method end 

}//class end
