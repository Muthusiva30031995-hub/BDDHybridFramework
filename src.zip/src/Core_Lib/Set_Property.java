package Core_Lib;
import java.io.File;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.Function;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
//import org.eclipse.jetty.util.log.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.internal.Coordinates;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.google.common.base.Predicate;
import com.sun.jna.platform.win32.WinNT.LOGICAL_PROCESSOR_RELATIONSHIP;


import Core_Lib.Browser_Invoke_Url;
import Core_Lib.Get_Object_Identifier;
import base.runtimeRepo;
import config.defs;
import Core_Lib.GenericLibrary;
//import net.sourceforge.htmlunit.corejs.javascript.tools.debugger.GuiCallback;

public class Set_Property
   {
	
	static //LOGGER
	Logger LOG = Logger.getLogger(Set_Property.class.getName());
	Random ran = new Random();
				
	//Detail Reporting
	static List<String> methodreport_data= new ArrayList<String>();
	static GenericLibrary obj_Generic = new GenericLibrary();
	static String report_file = Harness.report_testcase;  
	List<String> report_data = new ArrayList<String>();
	static String report_type=Harness.ls_ReportingType;  
	String ls_Functionname="SET_PROPERTY";  
	String ls_Msg=null;
	String ls_status=null;
	boolean lb_set_property = false;
	static WebDriverWait explicitWait=null;
	WebDriverWait wait;
	runtimeRepo run=new runtimeRepo();
	//public void SET_PROPERTY( WebDriver scr_driver,String ls_window, String object_name,String ls_Value,String ls_input_action,String optional_ERR_FLAG) throws Exception
	public boolean SET_PROPERTY( WebDriver scr_driver,String ls_window, String object_name,String ls_Value,String ls_input_action,String optional_ERR_FLAG) throws Exception
	{

		List<WebElement> options = null;
		//Creating object
		Get_Object_Identifier gui_object= new Get_Object_Identifier();
		Get_Value_From_Var_Dic obj_vardic = new Get_Value_From_Var_Dic();
		wait=new WebDriverWait(scr_driver,defs.explicitWait);
		
		SimpleDateFormat obj_format = new SimpleDateFormat("dd/MM/yyyy");
		Calendar obj_calender = Calendar.getInstance();
		Actions action = new Actions(scr_driver);
		//Mani
		explicitWait=new WebDriverWait(scr_driver, defs.explicitWait);
		
		String ls_round = "N"; //updated on 16 Jan 18
		String ls_Check = "Yes";
		
		//To get round value of expected and actual values
		if(optional_ERR_FLAG.equalsIgnoreCase("Y&R"))
		{
			optional_ERR_FLAG="Y";
			ls_round="R";
		}else if(optional_ERR_FLAG.equalsIgnoreCase("Y&None")) // added by shan 13-04-18 to Avoid validations 
		{
			optional_ERR_FLAG="Y";
			ls_Check="None";
		}
		
//		if(object_name.equalsIgnoreCase("GWCCNewPerson_Addressess_Link"))
//		{
//			System.out.println("Debugging");
//		}
		
		WebElement element_object = null;
		
		if(object_name.trim().replaceAll("\n", "").equals("GWCCPartiesInvolved_textingContact_0_table_name_label") || object_name.trim().replaceAll("\n", "").equals("GWCCPartiesInvolved_textingContact_0_table_name_label1"))
		{
			//span[contains(@value,'#Test')]
			////td[contains(@class,'lv-cell')]//span[contains(@value,'Optinreq')]
			String textingcontacts_select_xpath ="//td[contains(@id,'ClaimContacts-ClaimContactsScreen-PeopleInvolvedDetailedListDetail-PeopleInvolvedDetailedLV')]//div[@class='gw-cell-inner']//div[contains(@id,'ClaimContacts-ClaimContactsScreen-PeopleInvolvedDetailedListDetail-PeopleInvolvedDetailedLV')]//div//div[contains(text(),'" + ls_Value + "')]";
			//scr_driver.findElement(By.xpath(textingcontacts_select_xpath)).click();
			ls_Value=textingcontacts_select_xpath;
			//sleep remove
			////Muthu-Thread.sleep(defs.beforeObjectLoadTime);
			//scr_driver.navigate().refresh();
		}
		
		
		try
		{
			
			if(object_name.equals("GWCCQuickClaimAuto_Finish_Link1")) 

			  { 
				wait=new WebDriverWait(scr_driver,defs.explicitWait - 170);
				
					  try {
						System.out.println("Finish - Started to Wait for Page load"); // 
						  String  ActionMenu_Xpath="//div[@id='FNOLWizard-FNOLMenuActions']"; // //
						  scr_driver.manage().timeouts().implicitlyWait(defs.implicitwait - 170, TimeUnit.SECONDS);
						  objectPresenceByXpath(ActionMenu_Xpath); //
						  objectEnabledByXpath(ActionMenu_Xpath); //
						  System.out.println("Finish - Wait for Page load is completed"); // 
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						System.out.println("Finish - Exception"); // 
					}
			  
			  }
			
			try {
				element_object = gui_object.GET_OBJECT_IDENTIFIER(scr_driver,object_name,ls_Value,optional_ERR_FLAG);
			} 
			catch(StaleElementReferenceException ee)
			{
				element_object = gui_object.GET_OBJECT_IDENTIFIER(scr_driver,object_name,ls_Value,optional_ERR_FLAG);
			}catch (Exception e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
		String webelement_type="";
		//Assert.assertNotNull(element_object,"The "+object_name+" is null in SET PROPERTY");
		webelement_type=gui_object.webelement_type;
		//Emergency Fix, need to review by running the existing scripts 
		if(element_object!=null || ls_Value.equalsIgnoreCase("clickhandleoptional") ) // added by shan to stop script when object not identified
		{
			if(webelement_type.toLowerCase().contains("opt"))
			{
				webelement_type=webelement_type.replace("opt","");
			}
			
			lb_set_property = true;
			webelement_type=gui_object.webelement_type;
			String ls_substring;
			if(ls_input_action.equalsIgnoreCase("Scroll_Down"))
			{
			 JavascriptExecutor js = (JavascriptExecutor) scr_driver;
			 js.executeScript("arguments[0].scrollIntoView();", element_object);
			}//if of inputaction
			// added on 13 Feb 18 - Shanmugakumar N
			if(ls_Value.substring(0,2).equals("!!")) // To get Store value from Storenum.txt file
			{
				ls_substring =ls_Value.substring(2, ls_Value.length());  
				ls_Value = ls_substring;	
				//Call function GET_VALUE_FROM_VAR_DIC to fetch the value from the variable values dictionary
				ls_Value =obj_vardic.GET_VALUE_FROM_VAR_DIC(ls_Value);
			}//if of !!
			else if(ls_Value.substring(0,1).equals("*"))
			{
				ls_substring =ls_Value.substring(1, ls_Value.length());  // added on 07 Feb 18 - Shanmugakumar N
				ls_Value = ls_substring;
		 		for (String key : Store_Value.variable_value.keySet()) 
		 		{
		 			if(key.equals(ls_Value))
		 			{
		 				LOG.info("The Item "+ ls_Value + " Exists in VariableValues Dictionary");
		 				ls_Value = Store_Value.variable_value.get(key);
		 				break;
		 			}//if of ls_Values
		 		}// for of key
			}//else if of *
			//to get the value fron variable dictionary
			if(webelement_type.equalsIgnoreCase("WebEdit"))	
			{		
				//Application specific
				if(ls_Value.equals("Title")||ls_Value.equals("Description"))
				{
					ls_Value=ls_Value+Harness.li_rowno;
				}
				//To Handle date value
				if(ls_Value.substring(0, 1).equals("^")) // added  by - shanmugakumar N 
				{
					if (ls_Value.substring(0, 2).equals("^^"))//^^+2
					{
						ls_Value=ls_Value.substring(3,ls_Value.length()).trim();
						int li_value = Integer.parseInt(ls_Value);
						obj_calender.setTime(new Date()); // Now use today date.
						obj_calender.add(Calendar.DATE, li_value); // Adding days
						ls_Value = obj_format.format(obj_calender.getTime());
						int li_len = ls_Value.length();
						//below condition modified by shan - 29/05/18
						if (li_len<10)// to handle date with d format to dd in case for 1 to 9 
						{
						 ls_Value="0"+ls_Value;
						}//if of li_len
					}	//if of ^^
				}//if of ^
			}//if of Webelement type
			//to avoid null value from the input
			if(!ls_Value.equalsIgnoreCase(null))
			{
				//check for the type of webelement type as WebEdit/webbutton/ to perform action
				switch(webelement_type)
				{
					case "MouseOver":
						try
						{
							Actions ls_action = new Actions(scr_driver);
							ls_action.moveToElement(element_object).perform();
							//mouseOver(scr_driver, element_object);
							ls_Msg="MouseOver is successfully done";
							ls_status="Pass";
							LOG.info("The Mouse over on the "+object_name + " is Successfully done" );
						}catch(Exception e)
						{
							LOG.error("UNABLE TO DO MOUSE OVER THE ELEMENT" +element_object);
							ls_Msg="Unable to do the MouseOver operation";
							ls_status="Fail";
						}//end of catch
						break;
		
					case "WebEdit":
						//below condition added to enter ':' within text input value - 9/08/2018 - Moorthy
						if(ls_Value.contains("$"))
						{
							ls_Value= ls_Value.replace("$", ":");
						}//end of if
						// below condition added for to enter random number with Text(inputvalue) - 01 Feb 18 Shanmugakumar
						if(ls_Value.contains("&RAN")) 
						{
							String ls_RandomNumber = ran.generate_RandomNo(5);
							String[] parts = ls_Value.split("&");
							String part1 = parts[0];
							ls_Value = part1+ls_RandomNumber;
						}//end of if
						if(object_name.equalsIgnoreCase("GWCCStep1of3EnterPayeeInfoManual_CheckNo_Text"))
						{
							if(ls_Value.equalsIgnoreCase("ManualCheckNo"))
							{
								String random = ran.generate_RandomNo(6);
								DateFormat dateformat = new SimpleDateFormat("MM/dd/yyyy-HH-mm-ss");
								Date date = new Date();
								String date1 = dateformat.format(date);
								String date2 = date1.replaceAll("/", "");
								 date1 = date2.replaceAll("-", "");
									ls_Value = date1;	
								
							}
						}
						
						else if(object_name.equals("BARAddInvoice_VendorInvoiceNumber_Text"))
						{
							if(ls_Value.equalsIgnoreCase("VendorInvoiceNumber") || ls_Value.equalsIgnoreCase("*VendorInvoiceNumber")){
								String random = ran.generate_RandomNo(6);							
									ls_Value = random;	
							}
						}
						
						else if(object_name.equalsIgnoreCase("GWCCSearchContact_LastName_Text"))
						{
							if(ls_Value.equalsIgnoreCase("ASI – Worley***") || ls_Value.equalsIgnoreCase("ASI"))
							{
								ls_Value = "ASI";
							}
						}
							
						else if(object_name.equals("GWCCStep1of3EnterPayeeInfo_AccNum_Text")){
								
//								ls_Value ="64464667788";
								element_object.sendKeys(Keys.CONTROL,"a");
								//Muthu-Thread.sleep(defs.beforeObjectLoadTime + 500);
								element_object.sendKeys(ls_Value);
								//Muthu-Thread.sleep(defs.beforeObjectLoadTime);
								WebElement element_accNum = scr_driver.findElement(By.xpath("//input[contains(@name,'NewCheckPayeeBooleanDV-EFTDataInputSet-BankRoutingNumber')]"));
								element_accNum.click();
							}
							
							
						else if(object_name.equals("GWCCExposureDetailsMedical_NoFaultInsuranceLimit_Text"))
							{
								element_object.sendKeys(ls_Value);
								//Muthu-Thread.sleep(1000);
								WebElement element_nofault = scr_driver.findElement(By.xpath("//input[@name=\"ExposureDetail-ExposureDetailScreen-ExposureDetailDV-MSPDetailsDV-hicn\"]"));
								element_nofault.click();
							}
							
							if(object_name.equals("GWCCNewVehicleIncident_Details_LossEstimate_Text"))
							{
								element_object.sendKeys(ls_Value);
								//Muthu-Thread.sleep(1000);
								WebElement element_estimateVehicle = scr_driver.findElement(By.xpath("//input[contains(@name,'VehicleIncidentDV-Speed')]"));
								element_estimateVehicle.click();
							}
						
						else if(object_name.equals("GWCCStatisticalData_CSPSubLine_Text"))
						{							
								WebElement cspSubline2 = scr_driver.findElement(By.xpath("(//div[text()='CSP Subline'])[2]"));
								if(cspSubline2.isDisplayed())								{
									element_object = scr_driver.findElement(By.xpath("//input[contains(@name,'StatCodeDetailCV-StateCodeValueInput')]"));
									element_object.clear();	
									element_object.sendKeys(ls_Value);									
									scr_driver.findElement(By.xpath("//input[contains(@name,'StatCodeDetailDV-ClassCodeDescription')]")).click();
									Thread.sleep(1000);
								}
							}		
						else if(object_name.equals("GWCCStatisticalData_Classification_Text"))
						{							
								WebElement classification2 = scr_driver.findElement(By.xpath("(//div[text()='Classification'])[2]"));
								if(classification2.isDisplayed())
								{
									element_object = scr_driver.findElement(By.xpath("//input[contains(@name,'StatCodeDetailCV-StateCodeValueInput')]"));
									element_object.clear();	
									element_object.sendKeys(ls_Value);
									scr_driver.findElement(By.xpath("//input[contains(@name,'StatCodeDetailDV-ClassCodeDescription')]")).click();
									Thread.sleep(1000);
								}
							}		
						else if(object_name.equals("GWCCStatisticalData_RiskState_Text"))
						{
							WebElement riskState = scr_driver.findElement(By.xpath("(//div[text()='Risk State'])[2]"));
							if(riskState.isDisplayed())
							{
								element_object = scr_driver.findElement(By.xpath("//input[contains(@name,'StatCodeDetailCV-StateCodeValueInput')]"));
								element_object.clear();	
								element_object.sendKeys(ls_Value);
								scr_driver.findElement(By.xpath("//input[contains(@name,'StatCodeDetailDV-ClassCodeDescription')]")).click();
								Thread.sleep(1000);
							}
						}
						else if(object_name.equals("GWCCStatisticalData_ASLOB_Text"))
						{							
								WebElement ASLOB2 = scr_driver.findElement(By.xpath("(//div[text()='Annual Statement Line of Business'])[2]"));
								if(ASLOB2.isDisplayed())								{
									element_object = scr_driver.findElement(By.xpath("//input[contains(@name,'StatCodeDetailCV-StateCodeValueInput')]"));									
									element_object.click();
									element_object.sendKeys(ls_Value);
									scr_driver.findElement(By.xpath("//input[contains(@name,'StatCodeDetailDV-ClassCodeDescription')]")).click();
									Thread.sleep(1000);
								}
							}
						else if(object_name.equals("GWCCStatisticalData_ASLOB_Text2"))
						{							
								WebElement ASLOB2 = scr_driver.findElement(By.xpath("(//div[text()='ASLOB'])[2]"));
								if(ASLOB2.isDisplayed())								{
									element_object = scr_driver.findElement(By.xpath("//input[contains(@name,'StatCodeDetailCV-StateCodeValueInput')]"));									
									element_object.click();
									element_object.sendKeys(ls_Value);
									scr_driver.findElement(By.xpath("//input[contains(@name,'StatCodeDetailDV-ClassCodeDescription')]")).click();
									Thread.sleep(1000);
								}
							}
							
						else if(object_name.equals("GWCCStatisticalData_SubLine_Text"))
						{							
								WebElement ASLOB2 = scr_driver.findElement(By.xpath("(//div[text()='Subline'])[2]"));
								if(ASLOB2.isDisplayed())								{
									element_object = scr_driver.findElement(By.xpath("//input[contains(@name,'StatCodeDetailCV-StateCodeValueInput')]"));									
									element_object.click();
									element_object.sendKeys(ls_Value);
									scr_driver.findElement(By.xpath("//input[contains(@name,'StatCodeDetailDV-ClassCodeDescription')]")).click();
									Thread.sleep(1000);
								}
							}
						
						else if(object_name.equals("GWCCStatisticalData_LocationCode_Text"))
						{							
								WebElement locationCode = scr_driver.findElement(By.xpath("(//div[text()='Location Code'])[2]"));
								if(locationCode.isDisplayed())								{
									element_object = scr_driver.findElement(By.xpath("//input[contains(@name,'StatCodeDetailCV-StateCodeValueInput')]"));									
									element_object.click();
									element_object.sendKeys(ls_Value);
									scr_driver.findElement(By.xpath("//input[contains(@name,'StatCodeDetailDV-ClassCodeDescription')]")).click();
									Thread.sleep(1000);
								}
							}
							
						else if(object_name.equals("GWCCStatisticalData_ItemNumber_Text"))
						{							
								WebElement locationCode = scr_driver.findElement(By.xpath("(//div[text()='Item Number'])[2]"));
								if(locationCode.isDisplayed())								{
									element_object = scr_driver.findElement(By.xpath("//input[contains(@name,'StatCodeDetailCV-StateCodeValueInput')]"));									
									element_object.click();
									element_object.sendKeys(ls_Value);
									scr_driver.findElement(By.xpath("//input[contains(@name,'StatCodeDetailDV-ClassCodeDescription')]")).click();
									Thread.sleep(1000);
								}
							}
							
						else if(object_name.equals("GWCCStatisticalData_UserLine_Text"))
						{							
								WebElement locationCode = scr_driver.findElement(By.xpath("(//div[text()='User Line'])[2]"));
								if(locationCode.isDisplayed())								{
									element_object = scr_driver.findElement(By.xpath("//input[contains(@name,'StatCodeDetailCV-StateCodeValueInput')]"));									
									element_object.click();
									element_object.sendKeys(ls_Value);
									scr_driver.findElement(By.xpath("//input[contains(@name,'StatCodeDetailDV-ClassCodeDescription')]")).click();
									Thread.sleep(1000);
								}
							}
						else if(object_name.equals("GWCCStatisticalData_Form_Text"))
						{							
								WebElement locationCode = scr_driver.findElement(By.xpath("(//div[text()='Form'])[2]"));
								if(locationCode.isDisplayed())								{
									element_object = scr_driver.findElement(By.xpath("//input[contains(@name,'StatCodeDetailCV-StateCodeValueInput')]"));									
									element_object.click();
									element_object.sendKeys(ls_Value);
									scr_driver.findElement(By.xpath("//input[contains(@name,'StatCodeDetailDV-ClassCodeDescription')]")).click();
									Thread.sleep(1000);
								}
							}
							
						else if(object_name.equals("GWCCStatisticalData_LossSettlement_Text"))
						{							
								WebElement locationCode = scr_driver.findElement(By.xpath("(//div[text()='Loss Settlement'])[2]"));
								if(locationCode.isDisplayed())								{
									element_object = scr_driver.findElement(By.xpath("//input[contains(@name,'StatCodeDetailCV-StateCodeValueInput')]"));									
									element_object.click();
									element_object.sendKeys(ls_Value);
									scr_driver.findElement(By.xpath("//input[contains(@name,'StatCodeDetailDV-ClassCodeDescription')]")).click();
									Thread.sleep(1000);
								}
							}
							
						else if(object_name.equals("GWCCStep1of3EnterPayeeInfo_RoutingNum_Text")){
																				
								if(ls_Value.equalsIgnoreCase("RoutingNumber") || ls_Value.equalsIgnoreCase("*RoutingNumber")){
									String random = ran.generate_RandomNo(9);									
										ls_Value = random; 	
																	
								}
							}
							
							if(object_name.equals("GWCCNewVehicleIncident_Details_VIN_Text")){
								if(ls_Value.equalsIgnoreCase("*VIN") || ls_Value.equalsIgnoreCase("VIN")){
									//String random = ran.generate_RandomNo(6);
									DateFormat dateformat = new SimpleDateFormat("MM/dd/yyyy-HH-mm-ss");
									Date date = new Date();
									String date3 = dateformat.format(date);
									String date4 = date3.replaceAll("/", "");
									 date3 = date4.replaceAll("-", "");
										ls_Value = "V"+date3+"TE";	
									
								}}
							if(object_name.equals("GWCCLogin_UsernName_Text")){
								
								ls_Value = "C10920C";
									
								}
							if(object_name.equals("GWCCLogin_Password_Text")){
								
								ls_Value = "Password%9";
									
								}
							
							
							
							if(object_name.equals("GWCCSearchTimeSet"))
							{
								if(Harness.gs_Browser.equals("Chrome"))								
								ls_Value = "";
							}
							
							if(object_name.equals("BARLogin_userid_Text")){
								
								ls_Value = "QBEQA.USER";
									
								}
							if(object_name.equals("BARLogin_password_Text")){
								
								ls_Value = "qatesting126";
									
								}
							
							
							if(object_name.equals("GWCCStep2of3EnterPaymentInfo_LineItemsAmount_Text"))
							{
								element_object.sendKeys(Keys.CONTROL,"a");								
								element_object.sendKeys(ls_Value);
								WebElement element_check_amount = scr_driver.findElement(By.xpath("//div[contains(@id,'NormalCreateCheckWizard-CheckWizard_CheckPaymentsScreen-ttlBar')]"));
								element_check_amount.click();
							}
							
							
							
							if(object_name.equals("GWCCStep2of3EnterPaymentInfoManual_Amount_Text")){
								
								if(ls_Value.equals("51") || ls_Value.equals("50") || ls_Value.equals("15"))
								ls_Value = "10";
								element_object.sendKeys(Keys.CONTROL,"a");								
								element_object.sendKeys(ls_Value);
								WebElement element_manualcheck_amount = scr_driver.findElement(By.xpath("//div[contains(@id,'ManualCreateCheckWizard-ManualCheckWizard_CheckPaymentsScreen-ttlBar')]"));
								element_manualcheck_amount.click();									
								}
							
							if(object_name.equals("GWCCSearchClaims_ClaimNo_Text")){
								
								
								if(ls_Value.equalsIgnoreCase("132282P") || ls_Value.equalsIgnoreCase("127987P") || ls_Value.equalsIgnoreCase("133467P"))
									ls_Value = "207215P";
//								197208P
//								ls_Value = "220671P";
								else if(ls_Value.equalsIgnoreCase("109048S") || ls_Value.equalsIgnoreCase("162627S"))
									ls_Value = "749896H";
								}
														
//							if(object_name.equals("GWCCPartiesInvolved_Business_Text"))
//							{
							
//								if(Harness.gs_Browser.equals("Chrome")) {
//									String value1 = ls_Value;
//									String digits1 =value1.substring(0, 3);
//									String digits2 =value1.substring(3, 6);
//									String digits3 =value1.substring(6, 10);
//									String digits4 = value1.substring(10, 17);
//									ls_Value = digits1+"-"+digits2+"-"+digits3+" x"+digits4;
//									}
//							}
							
							if(object_name.equals("GWCCNewPerson_PhoneHome_Text"))
							{
								if(Harness.gs_Browser.equals("Chrome")) {
									String value2 = ls_Value;
									String digits1 =value2.substring(0, 3);
									String digits2 =value2.substring(3, 6);
									String digits3 =value2.substring(6, 10);								
									ls_Value = digits1+"-"+digits2+"-"+digits3;
									}
							}				
//							
							
							
						if(object_name.equals("GWCCNewPerson_AddressLine1_Text") || object_name.equals("GWCCNewPerson_AddressZip_Text"))
							{
								
									element_object.click();
									//Muthu-Thread.sleep(defs.beforeObjectLoadTime + 500);
									element_object.sendKeys(Keys.CONTROL,"a");
									//Muthu-Thread.sleep(defs.beforeObjectLoadTime + 500);
									element_object.sendKeys(ls_Value);
									//Muthu-Thread.sleep(defs.beforeObjectLoadTime);
									element_object.sendKeys(Keys.TAB);
									System.out.println("Entering the Value in Person as " + ls_Value);
								
							}
						else {
						try
						{
							// below case statement added for to enter value with input action - 06 Feb 18 - Shanmugakumar
							switch(ls_input_action)
							{
								case "Tab":
									element_object.sendKeys(ls_Value,Keys.TAB);
									break;
								case "Enter":
									element_object.sendKeys(Keys.CONTROL,"a");
									element_object.sendKeys(ls_Value,Keys.ENTER);
									break;
								case "Clear":
									element_object.sendKeys(Keys.CONTROL,"a");
									//scr_driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
									//Muthu-Thread.sleep(defs.beforeObjectLoadTime);
									element_object.sendKeys(ls_Value);
									break;
								case "ClearTab":
									element_object.clear();
									////Muthu-Thread.sleep(defs.beforeObjectLoadTime);
									//scr_driver.manage().timeouts().implicitlyWait(defs.im, TimeUnit.SECONDS);
									element_object.sendKeys(ls_Value,Keys.TAB);
									break;
								case "ClearEsc":
									element_object.click();
									//Muthu-Thread.sleep(defs.beforeObjectLoadTime);
									element_object.sendKeys(Keys.CONTROL,"a");
									//scr_driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
									//Muthu-Thread.sleep(defs.beforeObjectLoadTime);
									element_object.sendKeys(ls_Value);
									break;
								default :
									element_object.click();
									element_object.sendKeys(ls_Value);
									//Muthu-Thread.sleep(200);
									break;
							}//end of switch
						}catch(Exception e)
						{
							System.out.println("Exception in send keys");
							System.out.println(e);
						}//end of catch
						}
						//scr_driver.manage().timeouts().implicitlyWait(defs.implicitwaitAlternate, TimeUnit.SECONDS);  // added by shan 12-02-18
						try
						{
							if(!optional_ERR_FLAG.equalsIgnoreCase("Y"))
							{
								int li_Sec = Integer.parseInt(optional_ERR_FLAG);
								//sleep remove
								////Muthu-Thread.sleep(li_Sec*700);
							}//end of if
						}catch(Exception e)
						{
							System.out.println(e);
						}//end of catch
						String ls_ExpVal = element_object.getAttribute("value");
						if(ls_round.equalsIgnoreCase("R"))
						{
							ls_Value=DecimalConversion.lfn_Conversion(ls_Value);
							ls_ExpVal=DecimalConversion.lfn_Conversion(ls_ExpVal);	
						}//end of if
						// below condition added by shanmugakumar - 30 oct 17
						if(ls_ExpVal.equals(ls_Value) || ls_Check.equals("None"))
						{		 	
							LOG.info("The "+ls_Value+" is enterded in "+object_name);
							ls_Msg="Value is entered Successfully";
							ls_status="Pass";
						}else
						{
							LOG.info("The "+ls_Value+" is not enterded in "+object_name);
							ls_Msg="Expected value mismatched";
							ls_status="Fail";
						}//end of else
						break;
			case "WebRadio": //Mani
				WebElement element_radioButton = gui_object.GET_OBJECT_IDENTIFIER(scr_driver,object_name,ls_Value,optional_ERR_FLAG);
						if (ls_Value.equalsIgnoreCase("Click") && element_radioButton.isDisplayed() && element_radioButton.isEnabled()) 
						{
							if(element_object.isSelected())
							{
								ls_status="Pass";
								  LOG.info("The "+object_name+" is default selected, so skipping the objec");
								  System.out.println("The "+object_name+" is default selected, so skipping the object");								 
							}
							else
							{
								element_object.click();
								ls_Msg="Expected Radio button Field is selected";
								ls_status="Pass";
								LOG.info(ls_Msg);
								System.out.println(ls_Msg);
							}
						}
						else if(ls_Value.equalsIgnoreCase(defs.noActionvalue) && element_radioButton.isDisplayed() && element_radioButton.isEnabled())
						{
							ls_Msg="Expected Radio button Field is skipped to select by suer value NA";
							ls_status="Pass";
							LOG.info(ls_Msg);
							System.out.println(ls_Msg);
						}
						else{
							//element_object.click();
							ls_Msg="Expected Radio button Field is selected";
							ls_status="Failed";
							LOG.info(ls_Msg);
							System.out.println(ls_Msg);
						}
					
							
							
						break;
			case "WebButton" : 
			  try
			  {
					element_object.click();
					ls_Msg="Expected Field Clicked";
					ls_status="Pass";
					LOG.info("The "+object_name+" is clicked successfully - Mani");
					////Muthu-Thread.sleep(1000);
				}catch(Exception e)
				 {
					try
					{
					  System.out.println("Element is displayed" + element_object.isDisplayed());
					  element_object.click();
					  ls_Msg="Expected Field Clicked";
					  ls_status="Pass";
					  LOG.info("The "+object_name+" is clicked successfully ");
					}catch(Exception e1)
					{
						System.out.println(e1);
						LOG.error("UNABLE TO THE CLICK THE BUTTON");
						ls_Msg="Unable to Click the Button";
						 ls_status="Fail";
					}//end of inner catch
				}//end of outer catch
				break;
			
			case "WebbuttonDblClick" : // added by shan - 15 Feb 18
				try
				{
					//Double click
					action.moveToElement(element_object).doubleClick().perform();
					ls_Msg="The button has Clicked Successfully";
					ls_status="Pass";
					LOG.info("The"+element_object+"is clicked successfully ");
				}catch(Exception e)
				  {
					LOG.error("UNABLE TO THE CLICK THE BUTTON");
					ls_Msg="Unable to Click the Button ";
					ls_status="Fail";
				  }
				break;

			case "WebElement" :
				try
				{
					element_object.click();
					ls_Msg="The WebElement has Clicked Successfully";
					ls_status="Pass";
					LOG.info("The"+element_object+"is clicked successfully ");
				}catch(Exception e)
				  {
					LOG.error("UNABLE TO CLICK THE ELEMENT");
					ls_Msg="Unable to Click the WebElement";
					ls_status="Fail";
				  }//end of catch
				break;
			case "WebElementJS" :
				if (ls_Value.equalsIgnoreCase("clickhandle") || ls_Value.equalsIgnoreCase("click")) {
				try
				{
					//if(element_object.isDisplayed()){
					((JavascriptExecutor)scr_driver).executeScript("arguments[0].click();", element_object);
					//((JavascriptExecutor)scr_driver).executeScript("arguments[0].checked = true;", element_object);
					ls_Msg="The WebElement javascript has Clicked Successfully";
					ls_status="Pass";
					LOG.info("The"+element_object+"is clicked successfully by javascript ");
					//}
				}catch(Exception e)
				  {
					ls_Msg=object_name + " - Unable to Click the WebElement using Javascript";
					LOG.error(ls_Msg);
					ls_status="Fail";
				  }//end of catc
				}
				if (ls_Value.equalsIgnoreCase("clickhandleOption")) {
				try
				{
					if(element_object.isDisplayed()){
					((JavascriptExecutor)scr_driver).executeScript("arguments[0].click();", element_object);
					//((JavascriptExecutor)scr_driver).executeScript("arguments[0].checked = true;", element_object);
					ls_Msg="The WebElement javascript has Clicked Successfully";
					ls_status="Pass";
					LOG.info("The"+element_object+"is clicked successfully by javascript ");
					}
					else
					{
						ls_status="Pass";
						LOG.info("The"+element_object+"is not available and not clicked successfully by javascript ");
					}
				}catch(Exception e)
				  {
					ls_Msg=object_name + " - Unable to Click the WebElement using Javascript";
					LOG.error(ls_Msg);
					ls_status="Fail";
				  }//end of catc
				}
				else {
					try
					{
						String trest=" ";
						element_object.click();
						ls_Msg="The Link has Clicked Successfully";
						ls_status="Pass";
						LOG.info("The"+object_name+"is clicked successfully ");
					}catch(Exception e)
					 {
							System.out.println(e);
							LOG.error("UNABLE Click the Link");
							ls_Msg="Unable to Click the Link";
							ls_status="Fail";
					 }//end of catch
					}
					
				break;
			case "Linkopt":
			case "Link":
				//Muthu-Thread.sleep(1500);
				String ls_string = element_object.getAttribute("text");
				if(ls_string==null)
				{
						ls_string="none";
				}else	
				{
					LOG.info("inside Link" + ls_string);
				}//end of if
				if(ls_Value.equalsIgnoreCase("Mousehover")){
					try {
						Actions actions = new Actions(scr_driver);
						actions.moveToElement(element_object).build().perform();
						ls_Msg="The Link has Clicked Successfully";
						ls_status="Pass";
						LOG.info("The"+object_name+"is clicked successfully ");
					} catch (Exception e) {
						System.out.println(e);
						LOG.error("UNABLE Click the Link");
						ls_Msg="Unable to Click the Link";
						ls_status="Fail";
					}
				}
					else {	
				try
				{	
					
					
					if(object_name.equals("GWCCQuickClaimAuto_Finish_Link")) 

					  { 
							  try {
								System.out.println("Finish - Started to Wait for Page load"); 								 
								String finishBtn = "//div[contains(@id, 'Finish')]/div"; 
									Thread.sleep(4000);							
								  objectPresenceByXpath(finishBtn); 
								  objectEnabledByXpath(finishBtn); 
								  System.out.println("Finish - Wait for Page load is completed"); // 
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
								System.out.println("Finish - Exception");  
							}
					  
					  }
										
				if(object_name.equals("GWCCStatisticalData_CSPSubLine_SelectBtn"))
					{
						WebElement cspSubline = scr_driver.findElement(By.xpath("(//div[text()='CSP Subline'])[1]"));
						if(cspSubline.isDisplayed()) {	
							try {
							WebElement cspSublineSelectBtn = scr_driver.findElement(By.xpath("//div[text()='CSP Subline']//ancestor::td//ancestor::tr//td[1]/div/div/div/div[2][text()='Select']"));
							for(int i=0;i<2;i++) {	
								if(cspSublineSelectBtn.isDisplayed()) {
									cspSublineSelectBtn.click();
									//Muthu-Thread.sleep(2000);					
								}
								else 
									break;
							}
							} catch(Exception e) {
								e.printStackTrace();
							}
						}
					}
				
				
				
								
					
					else if(object_name.equals("GWCCStatisticalData_SubLine_SelectBtn"))
					{
						WebElement Subline = scr_driver.findElement(By.xpath("(//div[text()='Subline'])[1]"));
						if(Subline.isDisplayed()) {	
							try {
							WebElement SublineSelectBtn = scr_driver.findElement(By.xpath("//div[text()='Subline']//ancestor::td//ancestor::tr//td[1]/div/div/div/div[2][text()='Select']"));							
								for(int i=0;i<2;i++) {	
									if(SublineSelectBtn.isDisplayed()) {
									SublineSelectBtn.click();
									//Muthu-Thread.sleep(2000);					
									}
									else 
										break;
								}
							}catch(Exception e) {
								e.printStackTrace();
							}
						}
					}
					
					
					else if(object_name.equals("GWCCStatisticalData_Classification_SelectBtn"))
					{
						WebElement classification = scr_driver.findElement(By.xpath("(//div[text()='Classification'])[1]"));
						if(classification.isDisplayed()) {
							try {
								WebElement classificationSelectBtn = scr_driver.findElement(By.xpath("(//div[text()='Classification'])[1]//ancestor::td//ancestor::tr//td[1]/div/div/div/div[2][text()='Select']"));
								for(int i=0;i<2;i++) {	
									if(classificationSelectBtn.isDisplayed()) {
										classificationSelectBtn.click();
										//Muthu-Thread.sleep(2000);					
									}
									else 
										break;
								}
								} catch(Exception e)
								{
									e.printStackTrace();
								}
						}
					}
					
					else if(object_name.equals("GWCCStatisticalData_RiskState_SelectBtn"))
					{
						WebElement riskState = scr_driver.findElement(By.xpath("(//div[text()='Risk State'])[1]"));
						if(riskState.isDisplayed()) {
							try {
							WebElement riskStateSelectBtn = scr_driver.findElement(By.xpath("(//div[text()='Risk State'])[1]//ancestor::td//ancestor::tr//td[1]/div/div/div/div[2][text()='Select']"));
							for(int i=0;i<2;i++) {	
								if(riskStateSelectBtn.isDisplayed()) {
									riskStateSelectBtn.click();
									Thread.sleep(1000);					
								}
								else 
									break;
							}
							} catch(Exception e)
							{
								e.printStackTrace();
							}
						}
					}
					
					else if(object_name.equals("GWCCStatisticalData_ASLOB_SelectBtn"))
					{
						JavascriptExecutor executor = (JavascriptExecutor)scr_driver;
						WebElement ASLOB = scr_driver.findElement(By.xpath("(//div[text()='Annual Statement Line of Business'])[1]"));
						if(ASLOB.isDisplayed()) {
							try {
								WebElement ASLOBSelectBtn = scr_driver.findElement(By.xpath("(//div[text()='Annual Statement Line of Business'])[1]//ancestor::td//ancestor::tr//td[1]/div/div/div/div[2][text()='Select']"));							
								executor.executeScript("arguments[0].scrollIntoView(true);", ASLOBSelectBtn);
								//Muthu-Thread.sleep(500);
								for(int i=0;i<2;i++) {	
									if(ASLOBSelectBtn.isDisplayed()) {
										ASLOBSelectBtn.click();
										//Muthu-Thread.sleep(2000);					
									}
									else 
										break;
								}
								} catch(Exception e)
								{
									e.printStackTrace();
								}
							
						}
					}
					
					else if(object_name.equals("GWCCStatisticalData_ASLOB_SelectBtn2"))
					{
						WebElement ASLOB_2 = scr_driver.findElement(By.xpath("(//div[text()='ASLOB'])[1]"));
						if(ASLOB_2.isDisplayed()) {							
														
							try {
								WebElement ASLOBSelectBtn2 = scr_driver.findElement(By.xpath("(//div[text()='ASLOB'])[1]//ancestor::td//ancestor::tr//td[1]/div/div/div"));						
								
								for(int i=0;i<2;i++) {	
									if(ASLOBSelectBtn2.isDisplayed()) {
										ASLOBSelectBtn2.click();
										//Muthu-Thread.sleep(2000);					
									}
									else 
										break;
								}
								} catch(Exception e)
								{
									e.printStackTrace();
								}
							
						}
					}
					else if(object_name.equals("GWCCStatisticalData_LocationCode_SelectBtn"))
					{
						WebElement locationCode = scr_driver.findElement(By.xpath("(//div[text()='Location Code'])[1]"));
						if(locationCode.isDisplayed()) {							
														
							try {
								WebElement locationCodeSelectBtn = scr_driver.findElement(By.xpath("(//div[text()='Location Code'])[1]//ancestor::td//ancestor::tr//td[1]/div/div"));						
								
								for(int i=0;i<2;i++) {	
									if(locationCodeSelectBtn.isDisplayed()) {
										locationCodeSelectBtn.click();
										Thread.sleep(2000);					
									}
									else 
										break;
								}
								} catch(Exception e)
								{
									e.printStackTrace();
								}
							
						}
					}
					else if(object_name.equals("GWCCStatisticalData_ItemNumber_SelectBtn"))
					{
						JavascriptExecutor executor = (JavascriptExecutor)scr_driver;
						WebElement itemNumber = scr_driver.findElement(By.xpath("(//div[text()='Item Number'])[1]"));
						if(itemNumber.isDisplayed()) {							
														
							try {
								WebElement itemNumberSelectBtn = scr_driver.findElement(By.xpath("(//div[text()='Item Number'])[1]//ancestor::td//ancestor::tr//td[1]/div/div"));						
								executor.executeScript("arguments[0].scrollIntoView(true);", itemNumberSelectBtn);
								for(int i=0;i<2;i++) {	
									if(itemNumberSelectBtn.isDisplayed()) {
										itemNumberSelectBtn.click();
										Thread.sleep(2000);					
									}
									else 
										break;
								}
								} catch(Exception e)
								{
									e.printStackTrace();
								}
							
						}
					}
					else if(object_name.equals("GWCCStatisticalData_UserLine_SelectBtn"))
					{
						JavascriptExecutor executor = (JavascriptExecutor)scr_driver;
						WebElement userLine = scr_driver.findElement(By.xpath("(//div[text()='User Line'])[1]"));
						if(userLine.isDisplayed()) {							
														
							try {
								WebElement userLineSelectBtn = scr_driver.findElement(By.xpath("(//div[text()='User Line'])[1]//ancestor::td//ancestor::tr//td[1]/div/div"));						
								executor.executeScript("arguments[0].scrollIntoView(true);", userLineSelectBtn);
								for(int i=0;i<2;i++) {	
									if(userLineSelectBtn.isDisplayed()) {
										userLineSelectBtn.click();
										Thread.sleep(2000);					
									}
									else 
										break;
								}
								} catch(Exception e)
								{
									e.printStackTrace();
								}
							
						}
					}
					else if(object_name.equals("GWCCStatisticalData_Form_SelectBtn"))
					{
						JavascriptExecutor executor = (JavascriptExecutor)scr_driver;
						WebElement form = scr_driver.findElement(By.xpath("(//div[text()='Form'])[1]"));
						if(form.isDisplayed()) {							
														
							try {
								WebElement formSelectBtn = scr_driver.findElement(By.xpath("(//div[text()='Form'])[1]//ancestor::td//ancestor::tr//td[1]/div/div"));						
								executor.executeScript("arguments[0].scrollIntoView(true);", formSelectBtn);
								for(int i=0;i<2;i++) {	
									if(formSelectBtn.isDisplayed()) {
										formSelectBtn.click();
										Thread.sleep(2000);					
									}
									else 
										break;
								}
								} catch(Exception e)
								{
									e.printStackTrace();
								}
							
						}
					}
					else if(object_name.equals("GWCCStatisticalData_LossSettlement_SelectBtn"))
					{
						JavascriptExecutor executor = (JavascriptExecutor)scr_driver;
						WebElement lossSettlement = scr_driver.findElement(By.xpath("(//div[text()='Loss Settlement'])[1]"));
						if(lossSettlement.isDisplayed()) {							
														
							try {
								WebElement lossSettlementSelectBtn = scr_driver.findElement(By.xpath("(//div[text()='Loss Settlement'])[1]//ancestor::td//ancestor::tr//td[1]/div/div"));						
								executor.executeScript("arguments[0].scrollIntoView(true);", lossSettlementSelectBtn);
								for(int i=0;i<2;i++) {	
									if(lossSettlementSelectBtn.isDisplayed()) {
										lossSettlementSelectBtn.click();
										Thread.sleep(2000);					
									}
									else 
										break;
								}
								} catch(Exception e)
								{
									e.printStackTrace();
								}
							
						}
					}
					
					else if(object_name.equals("GWCCStatisticalData_Update_Link"))
					{
						JavascriptExecutor executor = (JavascriptExecutor)scr_driver;
						try {
							WebElement statUpdateBtn = scr_driver.findElement(By.xpath("//div[@id='ClaimPolicyStatCodes-ClaimPolicyStatCodesScreen-StatCodeDetailCV_tb-Update']"));
							for(int i=0;i<2;i++) {	
								executor.executeScript("arguments[0].scrollIntoView(true);", statUpdateBtn);
								if(statUpdateBtn.isDisplayed())
								{
									statUpdateBtn.click();
									Thread.sleep(2000);
								}
								else 
									break;
							}
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
					else if(object_name.equalsIgnoreCase("GWCCPartiesInvolved_Update_Link"))
					{
						try {
							WebElement updateBtn = scr_driver.findElement(By.xpath("//div[contains(@id,'ContactBasicsDV_tb-ContactDetailToolbarButtonSet-Update')]/div"));
							for(int i=0;i<2;i++) {	
								
								if(updateBtn.isDisplayed())
								{
									updateBtn.click();
									Thread.sleep(1000);
								}
								else 
									break;
							}
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}								
					
					
					else if(object_name.equals("GWCCLossDetails_ContributingFac_Add_Link"))
					{
						try {
							WebElement contriBtn = scr_driver.findElement(By.xpath("//div[contains(@id,'EditableContributingFactorsLV_tb-Add')]/div/div[2]"));
							for(int i=0;i<2;i++) {									
								if(contriBtn.isDisplayed())
								{
									contriBtn.click();
									Thread.sleep(2000);
//									String contriPrimary = "//select[contains(@name,'ContributingFactors_contribprimary')]";
//									objectEnabledByXpath(contriPrimary);
								}
								else 
									break;
							}
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				
					else if(object_name.equals("GWCCSolvageDetails_update_Link")) {
						try {
							WebElement solvageUpdate = scr_driver.findElement(By.xpath("//div[contains(@id,'ExposureDetail-ExposureDetailScreen-Update')]/div"));
							for(int i=0;i<2;i++) {									
								if(solvageUpdate.isDisplayed())
								{
									solvageUpdate.click();
									Thread.sleep(2000);
//									String contriPrimary = "//select[contains(@name,'ContributingFactors_contribprimary')]";
//									objectEnabledByXpath(contriPrimary);
								}
								else 
									break;
							}
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
					}
				
				
					else if(object_name.equals("GWCCNewGLEvaluation_Update_Link"))
					{
						try {
							WebElement negotiationUpdate = scr_driver.findElement(By.xpath("//div[@id=\"Ext_NewEvaluationNonCD-NewEvaluationScreen-Ext_NewEvaluationNonCDDV_tb-Update\"]/div"));
							for(int i=0;i<2;i++) {									
								if(negotiationUpdate.isDisplayed())
								{
									negotiationUpdate.click();
									Thread.sleep(2000);
//									String contriPrimary = "//select[contains(@name,'ContributingFactors_contribprimary')]";
//									objectEnabledByXpath(contriPrimary);
								}
								else 
									break;
							}
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
										
					else if(object_name.equals("GWCCSetReserves_Save_Link"))
					{
						
							WebElement setReserve = scr_driver.findElement(By.xpath("//div[@id='NewReserveSet-NewReserveSetScreen-ttlBar']//div[text()='Set Reserves']"));
							setReserve.click();
							Thread.sleep(2000);			
							WebElement saveBtn = scr_driver.findElement(By.xpath("//div[contains(@id,'NewReserveSet-NewReserveSetScreen-Update')]/div[1]"));
							saveBtn.click();
							Thread.sleep(2000);		
							String reservePage = "(//div[contains(@id,'ClaimFinancialsTransactions-ClaimFinancialsTransactionsScreen-TransactionsLVRangeInput')])[1]";
							objectPresenceByXpath(reservePage);
						
					
					}
				
					else if(object_name.equals("GWCCSetReserves_Save1_Link"))
					{
						try {
							WebElement setReserve = scr_driver.findElement(By.xpath("//div[@id='NewReserveSet-NewReserveSetScreen-ttlBar']//div[text()='Set Reserves']"));
							setReserve.click();
							Thread.sleep(2000);							
							WebElement saveBtn = scr_driver.findElement(By.xpath("//div[contains(@id,'NewReserveSet-NewReserveSetScreen-Update')]/div[1]"));
							saveBtn.click();
							Thread.sleep(1000);							
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					
					}
					else if(object_name.equals("GWCCEstimates_SendToSymbility_Link"))
					{
						element_object.click();						
						String estimatesTitle = "//div[contains(@id,'Ext_ClaimEstimates-ClaimEstimatesScreen-ttlBar')]/div/div[text()='Estimates']";
						objectPresenceByXpath(estimatesTitle);
					}
					else if(object_name.equals("GWCCExposureDetailsMedical_MSBDetailsUpdate_Link"))
					{
						try {
							WebElement MSPUpdateBtn = scr_driver.findElement(By.xpath("//div[contains(@id,'ExposureDetail-ExposureDetailScreen-Update')]"));
							for(int i=0;i<2;i++) {
								
								if(MSPUpdateBtn.isDisplayed())
								{
									MSPUpdateBtn.click();
									//Muthu-Thread.sleep(5000);
								}
								else 
									break;
							}
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						//Muthu-Thread.sleep(4000);
					}
				
					else if (object_name.equals("GWCCNewGLEvaluation_Update_Link"))
					{
						try {
							WebElement evaluationUpdateBtn = scr_driver.findElement(By.xpath("//div[@id=\"Ext_NewEvaluationNonCD-NewEvaluationScreen-Ext_NewEvaluationNonCDDV_tb-Update\"]/div"));
							for(int i=0;i<2;i++) {
								
								if(evaluationUpdateBtn.isDisplayed())
								{
									evaluationUpdateBtn.click();
									//Muthu-Thread.sleep(3000);
								}
								else 
									break;
							}
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				
					else if(object_name.equals("GWCCNegotiation_Negotiation_Tracking_+_Link"))
					{
						WebElement textPlus = scr_driver.findElement(By.xpath("//div[text()='WEAKNESS FOR DEFENSE:']"));
						textPlus.click();
						//Muthu-Thread.sleep(2000);
						try {
						WebElement symbolPlus = scr_driver.findElement(By.xpath("//div[contains(@id,'EditableNegotionTrackingLV_tb-Add')]/div"));
						for(int i=0;i<2;i++) {
							
							if(symbolPlus.isDisplayed())
							{
								symbolPlus.click();
								//Muthu-Thread.sleep(3000);
							}
							else 
								break;
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

					 
					
					else if(object_name.equals("GWCCStep1of3EnterPayeeInfo_Next_Link"))
					{
						try {
							WebElement paymentNextBtn = scr_driver.findElement(By.xpath("//div[contains(@id,'NormalCreateCheckWizard-Next')]"));
							for(int i=0;i<3;i++) {
								
								if(paymentNextBtn.isDisplayed())
								{
									paymentNextBtn.click();
									Thread.sleep(1000);
								}
								else 
									break;
							}
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				
					else if(object_name.equals("GWCCStep1of3EnterPayeeInfo_Next_Link1")) {
						WebElement paymentNextBtn1 = scr_driver.findElement(By.xpath("//div[contains(@id,'NormalCreateCheckWizard-Next')]"));
						paymentNextBtn1.click();
						Thread.sleep(2000);
					}
					else if(object_name.equals("GWCCStep2of3EnterPaymentInfo_Next_Link"))
					{
						try {
							WebElement paymentNextBtn = scr_driver.findElement(By.xpath("(//div[text()='Step 2 of 3: Enter payment information'])[2]/../../../div[2]/div[4]/div"));
							for(int i=0;i<3;i++) {
								
								if(paymentNextBtn.isDisplayed())
								{
									paymentNextBtn.click();
									Thread.sleep(1000);
								}
								else 
									break;
							}
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
					else if(object_name.equals("GWCCStep3of3SetCheckInstructions_Finish_Link"))
					{											
						try {
							WebElement checkFinishBtn = scr_driver.findElement(By.xpath("//div[contains(@id,'NormalCreateCheckWizard-Finish')]"));
							for(int i=0;i<3;i++) {
								
								if(checkFinishBtn.isDisplayed())
								{
									checkFinishBtn.click();
									Thread.sleep(2000);
									
								}
								else 
									break;
							}
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				
					else if(object_name.equals("GWCCStep3of3SetCheckInstructions_Finish_Link1")) {
						WebElement checkFinishBtn1 = scr_driver.findElement(By.xpath("//div[contains(@id,'NormalCreateCheckWizard-Finish')]"));
						checkFinishBtn1.click();
						Thread.sleep(2000);
					}
					else if(object_name.equals("GWCCStep3of3SetCheckInstructionsManual_Finish_Link"))
					{											
						try {
							WebElement manualCheckFinishBtn = scr_driver.findElement(By.xpath("//div[contains(@id,'ManualCreateCheckWizard-Finish')]"));
							for(int i=0;i<3;i++) {
								if(manualCheckFinishBtn.isDisplayed())
								{
									manualCheckFinishBtn.click();
									Thread.sleep(3000);
								}
								else 
									break;
							}
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					else if(object_name.equals("GWCCNewPerson_Addressess_Link"))
					{
						WebElement address = scr_driver.findElement(By.xpath("//div[@id='NewContactPopup-ContactDetailScreen-ttlBar']//div[text()='New Person']"));
						address.click();						
						element_object.click();
						//Muthu-	Thread.sleep(1000);
						
					}
					else if(object_name.equals("GWCCRecodePayment_Recode_Link"))
					{						
						try {
							WebElement RecodeBtn = scr_driver.findElement(By.xpath("//div[contains(@id,'RecodePayment-RecodePaymentScreen-RecodePayment_RecodeButton')]"));
							for(int i=0;i<3;i++) {
								if(RecodeBtn.isDisplayed())
								{
									RecodeBtn.click();
									Thread.sleep(2000);
								}
								else 
									break;
							}
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				
					
					
					else if(object_name.equals("GWCCCloseExposure_CloseExposure_Link"))
					{
						Check_App_Message cappMessage = new Check_App_Message();
						try
						{
							
						WebElement closeExpBtn = scr_driver.findElement(By.xpath("//div[@id=\"CloseExposurePopup-CloseExposureScreen-Update\"]"));
						for(int i=0;i<2;i++) {						
								
							if(closeExpBtn.isDisplayed())
							{								
							closeExpBtn.click();
							//Muthu-Thread.sleep(2000);
							cappMessage.CHECK_APP_MESSAGE("e4", "errorOK", "Y");
							//Muthu-Thread.sleep(2000);
							}
							else 
								break;
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					}
				
					else if(object_name.equals("GWCCSolvageDetails_SendAssignmentSolvage_Link"))
					{
						element_object.click();
						Thread.sleep(2000);
						String solvageDetails = "//div[contains(@id,'ExposureDetailDV-Exposure_SalvageCardTab')]";
						objectPresenceByXpath(solvageDetails);
					}
				
					
					else if(object_name.equals("GWCCRepairDetails_SendAssignmentRepair_Link"))
					{
						element_object.click();
						String repairDetails = "//div[contains(@id,'ExposureDetailDV-Exposure_RepairCardTab')]";
						objectPresenceByXpath(repairDetails);
					}
					else if(object_name.equals("GWCCRepairDetails_ProQuote_Link"))
					{
						element_object.click();
						String solvageDetails2 = "//div[contains(@id,'ExposureDetailDV-Exposure_RepairCardTab')]";
						objectPresenceByXpath(solvageDetails2);
					}
					else if(object_name.equals("BARAssignedInvoices_AwaitingReview_Link"))
					{
						element_object.click();
						Thread.sleep(3000);
						String deduction = "//div[contains(@class,'nav-holder')]//a[contains(text(),'Deduction')]";
						objectPresenceByXpath(deduction);
					}
					
					else {
					element_object.click();
					ls_Msg="The Link has Clicked Successfully";
					ls_status="Pass";
					LOG.info("The"+object_name+"is clicked successfully ");
					}
				}catch(Exception e)
				 {
						System.out.println(e);
						LOG.error("UNABLE Click the Link");
						ls_Msg="Unable to Click the Link";
						ls_status="Fail";
				 }//end of catch
					}
				if(ls_string.equals("Close") && ScreenDriver.popup_driver!=null )
				{				
					GenericLibrary.shiftContrlToParentWindow(scr_driver);
				}//end of if
				
				if(object_name.equals("GWCCSearch_Search_WebElement"))
				 {
					 System.out.println("Started to Wait for Page load");
					 String PolicySearchTimeSet_Xpath="//input[contains(@id,'FNOLWizardFindPolicyPanelSet-Claim_lossTime_time')]";			 
					 String PolicyNextButton_Xpath="//div[contains(@id,'FNOLWizard_FindPolicyScreen-0')]//div[contains(@id, \"Next\")]/div";
					 objectPresenceByXpath(PolicySearchTimeSet_Xpath);
					 objectEnabledByXpath(PolicySearchTimeSet_Xpath);
					 objectEnabledByXpath(PolicyNextButton_Xpath);
					 System.out.println("Wait for Page load is completed");
				 }
				if(object_name.equals("GWCCSearch_Search1_WebElement"))
				 {
					 System.out.println("Started to Wait for Page load");
					 String PolicySearchCancel_Xpath="//div[contains(@id, \"FNOLWizard-Cancel\")]/div";			 
					 //String PolicyNextButton_Xpath="//div[contains(@id,'FNOLWizard_FindPolicyScreen-0')]//div[contains(@id, \"Next\")]/div";
					 objectPresenceByXpath(PolicySearchCancel_Xpath);
					 objectEnabledByXpath(PolicySearchCancel_Xpath);
					 System.out.println("Wait for Page load is completed");
				 }				
						  
						 				
				else if(object_name.equals("GWCCMatters_CreateBillingMatter_Link"))
				{
					System.out.println("Finish - Started to Wait for Page load");
					 String ActionMenu_Xpath="//div[@id='FNOLWizard-FNOLMenuActions']"; 					 
					 objectPresenceByXpath(ActionMenu_Xpath);					  					 
					 System.out.println("Finish - Wait for Page load is completed");
				}
				
			break;
			case "WebRadioGroup" :
				try
				{
					boolean is_checked =element_object.isSelected();
					//Added by Ambika to handle ON and OFF condition on 30/08/2018
					if((ls_Value.equalsIgnoreCase("ON")||ls_Value.equalsIgnoreCase("Click"))&& (!is_checked))
					{
						element_object.click();
					}else if(ls_Value.equalsIgnoreCase("OFF")&& (is_checked))
					{
						element_object.click();
					}//end of if(Ls_Value)
					ls_Msg="The Radio Button  has selected Successfully";
					ls_status="Pass";
					LOG.info("The "+object_name+" is Selected successfully ");
				}catch(Exception e)
				  {
					try
					{
						boolean lb_select=element_object.isSelected();
						if(lb_select)
						{
							ls_Msg="The Radio Button by default selected ";
							ls_status="Pass";
						}else
						{
							
						}
					}catch(Exception e1)
					{
						LOG.error("UNABLE TO CLICK THE WEBRADIO GROUP");
						ls_Msg="Unable to select the Radio Button";
						ls_status="Fail";
					}//end of inner catch
					
				  }//end of outer catch
				break;
			
			case "WebCheckBox" : 
			  try
			  {
					element_object.click();
					boolean is_checked =element_object.isSelected();
					//Added by Ambika to handle ON and OFF condition on 30/08/2018
					if((ls_Value.equalsIgnoreCase("ON")||ls_Value.equalsIgnoreCase("Click"))&& (!is_checked))
					{
						element_object.click();
					}else if(ls_Value.equalsIgnoreCase("OFF")&& (is_checked))
					{
						element_object.click();
						
					}//end of if(Ls_Value)
					
					ls_Msg="The CheckBox has selected Successfully";
					ls_status="Pass";
					LOG.info("The"+element_object+"is clicked successfully ");
				}catch(Exception e)
				  {
					System.out.println(e);
					LOG.error("UNABLE TO CLICK THE WEBCHECK BOX");
					ls_Msg="Unable to select the CheckBox ";
					ls_status="Fail";
				  }
			break;
			
			 case "WebList":
				 if(object_name.equalsIgnoreCase("GWCCDwellingQuickClaimAuto_AssignClaimAndAllExpTo_List")){
					 System.out.println("Debugging");
				 }
				 
				 
				 if(!ls_Value.equalsIgnoreCase(defs.noActionvalue))
						 {
						 boolean multi_select =checkDDLisMultiple(element_object);
					     if(!multi_select)
					     {	
					     list:{
					    	 
					    	 switch(ls_input_action){
					    	 case "Selectedcheck":
					    		String nonesel = element_object.getText();
					    		 if(!nonesel.contains("<none selected>")){
					    			 ls_Msg="The Weblist has selected Successfully";
			    						ls_status="Pass";
			    						LOG.info("The"+element_object+"is Selected the value "+ ls_Value+" successfully ");
					    			 break list;
					    		 }
					    	 }
					     
					    	 if (ls_Value.substring(0, 1).equals("[")) {
								ls_Value = ls_Value.replace('[', '<');
								ls_Value = ls_Value.replace(']', '>');
							}
					    	 
					    	 if(ls_Value.substring(0,1).equals("#")) //to select by index start from 0
					    	 {
			    				int int_object_value = Integer.parseInt(ls_Value.substring(1,ls_Value.length()));
			    				//System.out.println(int_object_value);
			    				try
			    				{
			    						selectDDlByIndex(element_object, int_object_value,object_name,ls_Value);
			    						ls_Msg="The Weblist has selected Successfully";
			    						ls_status="Pass";
			    						LOG.info("The"+element_object+"is Selected the value "+ int_object_value +" successfully ");
			    					}catch(Exception e)
			    					  {
			    						LOG.error("EXCEPTION IN CALLING THE SELECTDDLBYINDEX METHOD");
			    						ls_Msg="Unable to select The Weblist ";
			    							ls_status="Fail";
			    					  }//catch
			    				}
					    	 
					    	 else if(object_name.equalsIgnoreCase("GWCCExposureDetailsMedical_CMSAction_List")){
					    		 
								selectDDlByVisibleText(element_object,ls_Value,object_name,ls_Value);
								Thread.sleep(1000);  
								WebElement updateBtn = scr_driver.findElement(By.xpath("//div[contains(@id,'ExposureDetail-ExposureDetailScreen-Update')]/div"));
								updateBtn.click();
								Thread.sleep(2000);
							 }
					    	  else
					    	  {
			    				try{
		                            if(getCountofDropdownValues(element_object) > 1)
		                            {
			    					selectDDlByVisibleText(element_object,ls_Value,object_name,ls_Value);
			    					
			    					ls_Msg="The"+element_object+"is Selected the value "+ ls_Value +" successfully";
		    						ls_status="Pass";
			    					LOG.info("The"+element_object+"is Selected the value "+ ls_Value +" successfully ");
			    					System.out.println(ls_Msg);
			    					}
			    					else
			    					{
				    					ls_Msg="The"+element_object+" has only one value so skipped with default values";
			    						ls_status="Pass";
				    					LOG.info("The"+element_object+" has only one value so skipped with default values");
				    					System.out.println(ls_Msg);
			    					}
			    					
			    				}catch(Exception e)
					    	  	 {
			    					LOG.error("EXCEPTION IN CALLING THE SELECTDDLBYINDEX METHOD");
			    					ls_Msg="Unable to select The Weblist ";
		    						ls_status="Fail";
								
					    	  	 }
					    	  }
					    	// below case statement added for to enter value with input action - 15 Feb 18 - Shanmugakumar
								switch(ls_input_action)
								{
									case "Tab":
										element_object.sendKeys(ls_Value,Keys.TAB);
										break;
								}
					      	} // if To check weblist Type
					    	break;
					     }//web element type
			     
						 }//if of null condition
				 
				 
				 
				}
				 
		if(report_type.equals("DETAIL"))
		{
			//for Excl DETAIL reporting
			report_data.add(ls_Functionname);
			report_data.add(object_name);
			report_data.add(ls_Value);
			report_data.add("");
			report_data.add(ls_Msg);
			report_data.add(ls_status);
			obj_Generic.Report(report_file,report_data );
		}//if of report
		
			if(ls_status.equalsIgnoreCase("Pass"))
			{
				lb_set_property = true;
			}
			else
			{
				lb_set_property = false;
			}
			
		} // End If - To stop script while obj identification fail
	
		}
		else if(webelement_type.toLowerCase().contains("opt"))
		{
			ls_status="Pass";
			lb_set_property = true;
		}
		}
		catch(Exception e)
		{
			System.out.println("Exception in Set-property class - " + e.toString());
		}
		
		return lb_set_property;
	}	//method end
	
			
	/*
	 * public static void checktheDropDownvalueSelect(WebElement dropdown, String
	 * value) { int index=0; // Select sel = new
	 * Select(driver.findElement(By.xpath("//select[@name='Students']"))); Select
	 * sel = new Select(dropdown);
	 * 
	 * //sel.selectByVisibleText("student4");
	 * 
	 * List<WebElement> list = sel.getOptions();
	 * 
	 * for(int i=0;i<list.size();i++){
	 * if(list.get(i).getText().contains(value.trim())){
	 * System.out.println("Dropdoen selection using index is - " + i +
	 * "Drowp Doen option ="+ list.get(i).getText() + " >>> which contains = "+
	 * value.trim()); index=i; break; } } sel.selectByIndex(index); }
	 * 
	 * public static int getCountofDropdownValues(WebElement dropdown) { int
	 * index=0; // Select sel = new
	 * Select(driver.findElement(By.xpath("//select[@name='Students']"))); Select
	 * sel = new Select(dropdown);
	 * 
	 * //sel.selectByVisibleText("student4");
	 * 
	 * List<WebElement> list = sel.getOptions(); index=list.size(); return index; }
	 */
	 //This method select the DroDownList by using index
	 public static List<WebElement> getDDLOptions(WebElement element) 
	 {
		 List<WebElement> options=null;
		 try
		 {
			 Select select_object = new Select(element);
			 options= select_object.getOptions();
		 }catch(Exception e)
		  {
			LOG.error("EXCEPTION IN THE GET OPTIONS METHOD");
			
		  }//catch
		return options;
	 }
			
	 //This method select the DroDownList by using index
	 public static void selectDDlByIndex(WebElement element, int index,String object_name,String ls_Value)
	 {
		 try
		 {
			 Select select_object = new Select(element);
			 select_object.selectByIndex(index);
			 methodreport_data=null;
		 }catch(Exception e)
		  {
			LOG.error("EXCEPTION IN SELECT DDL BY INDEX METHOD");
			if(report_type.equals("DETAIL"))
			{
				//for Excl DETAIL reporting
				methodreport_data.add("SETPROPERTY");
				methodreport_data.add(object_name);
				methodreport_data.add(ls_Value);
				methodreport_data.add("");
				methodreport_data.add("Unable to select The Weblist By Index");
				methodreport_data.add("Fail");
				obj_Generic.Report(report_file,methodreport_data );
			}//if of report
			
		  }//catch 
	 }
			
	 //This method select the DroDownList by using value
	 public static void selectDDlByValue(WebElement element, String value,String object_name,String ls_Value)
	 {
		 try
		 {
			 Select select_object = new Select(element);
			 select_object.selectByValue(value);
			 //Muthu-Thread.sleep(defs.dropdownlistLoadingTime);
			 methodreport_data=null;
		 }catch(Exception e)
		  {
			LOG.error("EXCEPTION IN SELECT DDL BY VALUE METHOD");
			if(report_type.equals("DETAIL"))
			{
				//for Excl DETAIL reporting
				methodreport_data.add("SETPROPERTY");
				methodreport_data.add(object_name);
				methodreport_data.add(ls_Value);
				methodreport_data.add("");
				methodreport_data.add("Unable to select The Weblist By Value");
				methodreport_data.add("Fail");
				obj_Generic.Report(report_file,methodreport_data );
			}//if of report
			
		  }//catch 
			 
	 }
			
	 //This method select the DroDownList by using VisibleText
	 public static void selectDDlByVisibleText(WebElement element, String visibletext,String object_name,String ls_Value) 
	 {
		 methodreport_data=null;
		 try
		 {
			 ////Muthu-Thread.sleep(1000);
			 //Select select_object = new Select(element);
			 //select_object.selectByVisibleText(visibletext);
			 checktheDropDownvalueSelect(element, visibletext);
			 
			 
			 //Muthu-Thread.sleep(defs.dropdownlistLoadingTime);
		 }catch(Exception e)
		  {
			 
			LOG.error("EXCEPTION IN SELECT DDL BY VISIBLE TEXT METHOD");
			if(report_type.equals("DETAIL"))
			{
				
				//for Excl DETAIL reporting
				methodreport_data.add("SETPROPERTY");
				methodreport_data.add(object_name);
				methodreport_data.add(ls_Value);
				methodreport_data.add("");
				methodreport_data.add("Unable to select The Weblist By Visible Text");
				methodreport_data.add("Fail");
				obj_Generic.Report(report_file,methodreport_data );
			}//if of report
			
			
		  }//catch 
	 }
	 
	 
	 public static void checktheDropDownvalueSelect(WebElement dropdown, String value)
	 {
		 int index=0;
		// Select sel = new Select(driver.findElement(By.xpath("//select[@name='Students']")));
		 Select sel = new Select(dropdown);

		    //sel.selectByVisibleText("student4");

		    List<WebElement> list = sel.getOptions();

		    for(int i=0;i<list.size();i++){
		        if(list.get(i).getText().contains(value.trim())){
		            System.out.println("Dropdoen selection using index is - " + i +  "Drowp Doen option ="+ list.get(i).getText()
		            		+ " >>> which contains = "+ value.trim());
		            index=i;
		            break;
		            }
		    }
		  sel.selectByIndex(index);
	 }
	 
	 public static int getCountofDropdownValues(WebElement dropdown)
	 {
		 int index=0;
		// Select sel = new Select(driver.findElement(By.xpath("//select[@name='Students']")));
		 Select sel = new Select(dropdown);

		    //sel.selectByVisibleText("student4");

		    List<WebElement> list = sel.getOptions();
		    index=list.size();
		    return index;
	 }
	 
			
	 //This method is used to check the Drop Down list is muliple or not
	 public static boolean checkDDLisMultiple(WebElement element)
	 {
		 boolean status=false;
		 try
		 {
			 Select select_object = new Select(element);
			 status = select_object.isMultiple();
		 }catch(Exception e)
		  {
			LOG.error("EXCEPTION IN CHECK DDL IS MULTIPLE METHOD");
			
		  }//catch 
		return status;
	  }

	  //This method deselect the DroDownList by using index
	  public static void deselectDDlByIndex(WebElement element, int index,String object_name,String ls_Value)
	  {
		  methodreport_data=null;
		  try
		  {
			  Select select_object = new Select(element);
			  select_object.deselectByIndex(index);
		  }catch(Exception e)
		  {
			LOG.error("EXCEPTION IN DESELECT DDL BY INDEX METHOD");
			if(report_type.equals("DETAIL"))
			{
				//for Excl DETAIL reporting
				methodreport_data.add("SETPROPERTY");
				methodreport_data.add(object_name);
				methodreport_data.add(ls_Value);
				methodreport_data.add("");
				methodreport_data.add("Unable to deselect The Weblist By Index");
				methodreport_data.add("Fail");
				obj_Generic.Report(report_file,methodreport_data );
			}//if of report
			
		  }//catch 
	  }
			
	  //This method deselect the DroDownList by using value
      public static void deselectDDlByValue(WebElement element, String value,String object_name,String ls_Value)
      {
    	  methodreport_data=null;
    	  try
    	  {
    		  Select select_object = new Select(element);
    		  select_object.deselectByValue(value);
    	  }catch(Exception e)
		  {
			LOG.error("EXCEPTION IN DESELECT DDL BY VALUE METHOD");
			if(report_type.equals("DETAIL"))
			{
				//for Excl DETAIL reporting
				methodreport_data.add("SETPROPERTY");
				methodreport_data.add(object_name);
				methodreport_data.add(ls_Value);
				methodreport_data.add("");
				methodreport_data.add("Unable to deselect The Weblist By Value");
				methodreport_data.add("Fail");
				obj_Generic.Report(report_file,methodreport_data );
			}//if of report
			
			
		  }//catch 
	  }
			
	  //This method deselect the DroDownList by using VisibleText
	  public static void deselectDDlByVisibleText(WebElement element, String visibletext,String object_name,String ls_Value)
	  {
		  methodreport_data=null;
		  try
		  {
			  Select select_object = new Select(element);
			  select_object.deselectByVisibleText(visibletext);
		  }catch(Exception e)
		  {
			LOG.error("EXCEPTION IN DESELECT DDL BY VISIBLE TEXT METHOD");
			if(report_type.equals("DETAIL"))
			{
				//for Excl DETAIL reporting
				methodreport_data.add("SETPROPERTY");
				methodreport_data.add(object_name);
				methodreport_data.add(ls_Value);
				methodreport_data.add("");
				methodreport_data.add("Unable to deselect The Weblist By VisibleText");
				methodreport_data.add("Fail");
				obj_Generic.Report(report_file,methodreport_data );
			}//if of report
			
			
		  }//catch 
	  }
			
	  //This method deselect all  option in the DroDownList
      public static void deselectAllOption(WebElement element,String object_name,String ls_Value)
      {
    	  methodreport_data=null;
    	  try
    	  {
    		  Select select_object = new Select(element);
    		  select_object.deselectAll();
    	  }catch(Exception e)
		  {
			LOG.error("EXCEPTION IN DESELECT ALL OPTIONS METHOD");
			if(report_type.equals("DETAIL"))
			{
				//for Excl DETAIL reporting
				methodreport_data.add("SETPROPERTY");
				methodreport_data.add(object_name);
				methodreport_data.add(ls_Value);
				methodreport_data.add("");
				methodreport_data.add("Unable to deselect all the option");
				methodreport_data.add("Fail");
				obj_Generic.Report(report_file,methodreport_data );
			}//if of report
			
			
		  }//catch 
	   }
			
	  //--------------------General Methods to take care of DropDown ends------------------------------
			
	  // Mouse related functions
			
	  // This method is used to move the mouse on the element
	  public static void mouseOver(WebDriver driver, WebElement element)
	  {
		 
	  }

	  // This method is used to right click using  mouse on the element
	  public static void rightClick(WebDriver driver, WebElement element) 
	  {
			Actions ls_action = new Actions(driver);
			ls_action.contextClick(element).perform();
	  }
			
	  // This method is used to double  click using  mouse on the element
	  public static void doubleClick(WebDriver driver, WebElement element)
	  {
		  Actions ls_action = new Actions(driver);
		  ls_action.doubleClick(element).perform();
	   }

	  public static void objectPresence(By element)
	  {
		  explicitWait.until(ExpectedConditions.presenceOfElementLocated(element));
	  }
	  
	  public static void objectPresenceByXpath(String objectXpath)
	  
	  {
		  //objectXpath="//input[contains(@id,'FindPolicyScreen:FNOLWizardFindPolicyPanelSet:Claim_lossTime')]";
		  //WebElement eleName=driverName.findElement(By.xpath("//input[contains(@id,'FindPolicyScreen:FNOLWizardFindPolicyPanelSet:Claim_lossTime')]"));
		  explicitWait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(objectXpath)));
	  }
	  
	  public static void objectEnabledByXpath(String objectXpath)
	  
	  {
		  //objectXpath="//input[contains(@id,'FindPolicyScreen:FNOLWizardFindPolicyPanelSet:Claim_lossTime')]";
		  //WebElement eleName=driverName.findElement(By.xpath("//input[contains(@id,'FindPolicyScreen:FNOLWizardFindPolicyPanelSet:Claim_lossTime')]"));
		  explicitWait.until(ExpectedConditions.elementToBeClickable(By.xpath(objectXpath)));
	  }
	  
	  public boolean pageStatus(WebDriver scr_driver) {
	        return ((JavascriptExecutor)scr_driver).executeScript("return document.readyState").equals("complete");
		}
	  
	  public void checkPageStatusWait(WebDriver val_driver){
	  if(!pageStatus(val_driver))
		{
			System.out.println("Waiting for the Page Load in Drop Down Selection");
			wait.until( new Predicate<WebDriver>() 
			{
           public boolean apply(WebDriver val_driver) {
               return ((JavascriptExecutor)val_driver).executeScript("return document.readyState").equals("complete");
           }});
		}
	  }
	  public  void waitForElementToAppear(By locator, WebDriver scr_driver) throws TimeoutException {
			boolean webElementPresence = false;
			try {
				Wait<WebDriver> fluentWait = new FluentWait<WebDriver>(scr_driver).pollingEvery(80, TimeUnit.MILLISECONDS)
						.withTimeout(60, TimeUnit.SECONDS).ignoring(NoSuchElementException.class);
				fluentWait.until(ExpectedConditions.visibilityOfElementLocated(locator));
			} catch (Exception e) {
				e.printStackTrace();
				//logger.log(LogStatus.ERROR, "Exception occured<br></br>" + e.getStackTrace());
			}
		}
	  
	  
}//closing class
