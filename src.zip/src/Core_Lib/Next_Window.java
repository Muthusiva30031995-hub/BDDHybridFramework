package Core_Lib;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

//The function was written to verify the existence of the correct window.
// Function returns PASS if window exist and FAIL if window does not exist.

public class Next_Window 
{
	public boolean NEXT_WINDOW(String  ls_window, String ls_timeout, String applicationName) 
	{
		//LOGGER
		Logger LOG = Logger.getLogger(Next_Window.class.getName());
		
		 GenericLibrary obj_Generic = new GenericLibrary();
		 String report_type=Harness.ls_ReportingType;
		 String report_file = Harness.report_testcase;
		 List<String> report_data = new ArrayList<String>();
		 
		 String ls_Functionname="NEXT_WINDOW";
		 String ls_Msg=null;
		 String ls_statusMsg=null;
		 String ls_status=null;
		 String ls_status1=null;
		
		Map<String, String> objectPattern = new LinkedHashMap<String, String>();//This map is used to store values from text file
		
		String ls_sReturn = null; 	 		// This holds the PatteN value
		String line;
		String data_path;					//This variable holds the data path from Harness 
		String filename;					//This variable holds the exact path of window pattern file
		String[] arr_line;					// To store the Line from window pattern
		
		boolean window_exist = false;
		boolean file_exists=false;
		WebDriver driver = null;
		Validate obj_validate = new Validate();
		File_Exists obj_file =new File_Exists();
		
		String currDir = System.getProperty("user.dir");
		String FilePath = currDir+"\\src\\windowPatterns\\Window_Pattern.txt";
		////Automation_Project/src/windowPatterns/Window_Pattern.txt
		
		
		data_path=  Harness.gs_data_path;//This vaiable halds the path of Data_Lib
		filename =FilePath;

		if(ls_window.contains("GWCCDwellingQuickClaimAuto"))
		{
			System.out.println("Debugging");
		}
		
		Browser_Invoke_Url driverCache=new Browser_Invoke_Url();
		driver=driverCache.getDriver();
		
		
		//VALIDATION
		Assert.assertNotNull(driver, "The Driver is null in NEXT WINDOW Function");
		
		try
		{
			file_exists = obj_file.FILE_EXISTS(filename);
		}catch(Exception e)
			{
				LOG.error("The Window Pattern file is not exists in NEXT WINDOW Function");
			}//end of catch stmt

		//VALIDATION
		Assert.assertTrue(file_exists, "The Window Pattern File is not found in Next_WinDow Function");
		
		BufferedReader reader = null;
		try 
		{
			reader = new BufferedReader(
					new InputStreamReader(new FileInputStream(filename)));
		} catch (FileNotFoundException e1) 
			{
				ls_Msg="Exception in BufferedReader of Next_Window Function";
				ls_status="Fail";
				LOG.error("Exception in BufferedReader of Next_Window Function");
			}//end of catch stmt
		
		//check if the object exists in the object dictionary
		try
		{
			//Read Window pattern file to create Key , Value pair
			boolean lb_firstline = false;
			try 
			{
				while ((line = reader.readLine()) != null)
				{
					 arr_line = line.split("#");//After readin from text file spiliting using , and storing in an array
					 
					 if (lb_firstline)	
					 {
					   
					    if ((arr_line[1]!=null)&&(arr_line[0]!=null))
					    {
					    	arr_line[0]= arr_line[0].trim();
					        arr_line[1] = arr_line[1].trim();
					    }
					    
					    objectPattern.put(arr_line[0], arr_line[1]);//the array values are convert into key & values and stored in ma
					    //LOG.info("objectPattern"+objectPattern);
					    
					 }
					 else
						 lb_firstline= true;
					 
									 
				}
			} catch (IOException e) 
			{
				ls_Msg="Exception in Reading Window Pattern text file in Next_Window Function";
				ls_status="Fail";
				LOG.error(ls_Msg);
			}// while of reading 
		
			
			for (String ls_key : objectPattern.keySet()) 
			{
				//LOG.info("ls_window"+ls_window);
				//LOG.info("ls_key"+ls_key);
				if(ls_key.equals(ls_window))
				{
					try
					{
						ls_sReturn = objectPattern.get(ls_key);//Get the item.
						//LOG.info("ls_sReturn"+ls_sReturn);
						
					}
					catch(Exception e)
					{
						ls_Msg="UNABLE TO GET THE VALUE FROM THE OBJECT PATTERN  MAP IN NEXT WINDOW";
						ls_status="Fail";
						LOG.error(ls_Msg);
					}//CATCH
					break;
				}//if for value
				
			}//for of value

			System.out.println(ls_sReturn);
			if (!(ls_sReturn==null )&&(!(ls_sReturn.equalsIgnoreCase("") ))) // added by shan - 27-07-18
			{
				window_exist=obj_validate.gfn_validate(ls_sReturn);
				//This code to wait for 30 seconds for nex window verification
				if (window_exist)
				{
					ls_Msg="The expected  window pattern is dispalyed ";
					ls_status="Pass";
					LOG.error(ls_Msg);
					System.out.println(ls_Msg);
				}//IF OF WINDOW EXISTS
				else 
				{
					ls_Msg="The expected  window pattern is not dispalyed ";
					ls_status="Fail";
					LOG.error(ls_Msg);	
					System.out.println(ls_Msg);
				}
					
			}//if of ls_return
			else 
			{
				ls_Msg="Function will not work unless window name is defined";
				ls_status="Fail";
				LOG.error(ls_Msg);
			}
				
				
		}
		catch(Exception e)
		{
			try 
			{
				reader.close();
			}
			catch (IOException e1)
			{
				LOG.error("Exception in closing the file in Next_Window  Function");
			}
		}//catch
		if(report_type.equals("DETAIL"))
		{
			//for Excl detail reporting
			report_data.add(ls_Functionname);
			report_data.add(ls_window);
			report_data.add(ls_sReturn);
			report_data.add("");
			report_data.add(ls_Msg);
			report_data.add(ls_status);
			obj_Generic.Report(report_file,report_data );
		}//if of report
		
		//below lines commented by shan
		//Assert.assertTrue(window_exist, ls_window+" is not exists in Next window Function");
		//VALIDATION
//		Assert.assertNotNull(ls_sReturn, "The window value is null in Next_Window Function"); 
		
		return window_exist;
 		
	}//method end
	
}//class end
	

