package Core_Lib;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import Core_Lib.GenericLibrary;

/*This function checks the error code against the error code dictionary and gets the associated text
and compares this to the text in the dialog box*/

public class Check_App_Message
{
		static //LOGGER
		Logger LOG = Logger.getLogger(Check_App_Message.class.getName());
		
		//Detail Reporting
		 GenericLibrary obj_Generic = new GenericLibrary();
		 String report_file = Harness.report_testcase;
		 List<String> report_data = new ArrayList<String>();
		 String report_type=Harness.ls_ReportingType;
		 String ls_Functionname="CHECK_APP_MESSAGE";
		 String ls_Msg=null;
		 String ls_status=null;
		
		public void CHECK_APP_MESSAGE(String ls_ErrorCode,  String ls_buttonValue, String lb_optional_ERR_FLAG)
		{
			//Getting WebDriver Control to perform action
			 WebDriver app_message_driver = ScreenDriver.scr_driver;	
			switch(ls_buttonValue)
			{
				case "errorYes" :
					
					try
					{
						//Muthu-thread.sleep(1000);
						Alert ls_alert = app_message_driver.switchTo().alert();
						ls_alert.accept();
						ls_Msg="The Alert has Accepted";
						ls_status="Pass";
						LOG.info("The Alert has Accepted with "+ls_buttonValue);
						
					}catch(Exception e)
					{
						LOG.info("EXCEPTION IN CALLING ACCEPT ALERT METHOD IN CHECK APP MESSAGE FUNCTION");
						ls_Msg="Exception in accepting Alert";
						ls_status="Pass";
					}//END OF CATCH
					break;
	 	
				case "errorOK" :
					try
					{
						
						Alert ls_alert = app_message_driver.switchTo().alert();
						ls_alert.accept();
						ls_Msg="The Alert has Accepted";
						ls_status="Pass";
						LOG.info("The Alert has Accepted with "+ls_buttonValue);
						
					}catch(Exception e)
					{
						LOG.info("EXCEPTION IN CALLING ACCEPT ALERT METHOD IN CHECK APP MESSAGE FUNCTION");
						ls_Msg="Exception in accepting Alert";
						ls_status="Warning";
					}//END OF CATCH
					break;
	 
				case "errorNo":
					try
					{
						//dismisstAlert(app_message_driver);
						////Muthu-thread.sleep(10000);
						Alert ls_alert = app_message_driver.switchTo().alert();
						ls_alert.dismiss();
						ls_Msg="The Alert has Dismissed";
						ls_status="Pass";
						LOG.info("The Alert has Dismissed  with "+ls_buttonValue);
						
					}catch(Exception e)
					{
						LOG.info("EXCEPTION IN CALLING DISMISS ALERT METHOD IN CHECK APP MESSAGE FUNCTION");
						ls_Msg="Exception in accepting Alert";
						ls_status="Warning";
					}//END OF CATCH
					break;	
								
			}//Switch
			 if(report_type.equals("DETAIL"))
				{
					//for Excl DETAIL reporting
					report_data.add(ls_Functionname);
					report_data.add("");
					report_data.add("");
					report_data.add("");
					report_data.add(ls_Msg);
					report_data.add(ls_status);
					obj_Generic.Report(report_file,report_data );
				}//if of report
			 
		}//method end
		
	}//class end

//To VAlidate the Alert Message
			
			/*boolean lb_fileExist=false;
			String ls_expected_message = null;
			String ls_actual_message = null;
			String excel_error_code = null;
			FileInputStream open_excel_file=null;
					
			// get the data path from Harness
			String gs_data_path = Harness.gs_data_path; 
			
			//File operation
			String filepath = gs_data_path+"/ErrorCodes.xlsx";
			
			//checking file exist or not
			File_Exists obj_fileExist = new File_Exists();	
			lb_fileExist=obj_fileExist.FILE_EXISTS(filepath);
			
			//Validation for file
			Assert.assertTrue(lb_fileExist,filepath	+" File not exist in Check_App_Message Function");

			//reading ErrorCodes excel file 
			try
			{
				//READING ERROR CODE EXCEL FILE
				File excel_file = new File(filepath);	
				open_excel_file = new FileInputStream(excel_file);
				Workbook ls_excel_book = WorkbookFactory.create(open_excel_file);
				String sheetname = "Sheet1";
				Sheet ls_excel_sheet = ls_excel_book.getSheet(sheetname);	
				int rowcount = ls_excel_sheet.getLastRowNum();				
		 
				
					for(int li_loop =0;li_loop<=rowcount;li_loop++)
					{
						
						try
						{
							 excel_error_code =GenericLibrary.getExcelData(filepath, ls_excel_sheet, li_loop, 1);//checking for error code
						}catch(Exception e)
						{
							LOG.info("EXCEPTION IN READING ERROR CODE EXCEL FILE IN CHECK APP MESSAGE FUNCTION");
						}//END OF CATCH
						
						//validation
						Assert.assertNotNull("Error code is not found in Check_app_Mwssage", excel_error_code);
						
						
						if(ls_ErrorCode.equals(excel_error_code))
						{
							try
							{
								ls_expected_message = GenericLibrary.getExcelData(filepath, ls_excel_sheet, li_loop+1, 2);//get the error value for the checked error code
							}catch(Exception e)
							{
								LOG.info("EXCEPTION IN READING ERROR CODE EXCEL FILE  FOR EXPECTED MESSAGE IN CHECK APP MESSAGE FUNCTION");
							}
					 
						}//if of comparision
						
					}//for of excel loop
					//Validation
					//Assert.assertEquals(ls_ErrorCode, excel_error_code, "Error codes are not matching in Check_App_Message");
					
				//}//if close
				
				
				//if( (ls_ErrorCode.equals("cc01"))||(ls_ErrorCode.equals("e4")) || (ls_ErrorCode.equals("e26")) || (ls_ErrorCode.equals("TVC01")) || (ls_ErrorCode.equals("Wcse1")))
				//{
					try
					{
					 	ls_alert = driver.switchTo().alert();
						//ls_actual_message = ls_alert.getText();
					}catch(Exception e )
					{
						LOG.info("EXCEPTION IN CALLING GETALERTTEXT METHOD IN CHECK APP MESSAGE FUNCTION");

					}//END OF CATCH
					
					LOG.info("The Actual Error Message(" + ls_actual_message +") is not matching with the Expected Message( "+ls_expected_message+" )");
					
					//Validation
					Assert.assertEquals(ls_actual_message, ls_expected_message, "The Actual Error Message(" + ls_actual_message +") is not matching with the Expected Message( "+ls_expected_message+" )");
					
				//}//end if
		 */
					
				
			/*}catch(Exception e)
			 {	
				LOG.info("EXCEPTION IN CHECK APP MESSAGE");
				
			 }finally 
			  {
				 if(open_excel_file!=null)
				 {
					 System.out.println("Not Null");
					 try {
						open_excel_file.close();
					} catch (IOException e) {
						LOG.info("EXCEPTION IN CLOSING ERROR CODE EXCEL FILE IN CHECK APP MESSAGE ");
					}
				 }
			  }//finally*/
	
		
