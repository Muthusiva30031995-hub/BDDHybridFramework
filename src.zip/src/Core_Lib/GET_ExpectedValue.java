package Core_Lib;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

public class GET_ExpectedValue 
{
	public  String ExpectedValue(String ls_ExpectedVal)
	{
		//LOGGER
		Logger LOG = Logger.getLogger(Check_Value.class.getName());
		
		 // to store the sub value
		 String ls_substring; 
		 int    li_ExpectedVallen;
		 String lc_firstchar,lc_firstTwochar;
		 String ls_doubleCarot;
		
		 Get_Value_From_Var_Dic ls_obj = new Get_Value_From_Var_Dic();
		 Calendar obj_calender = Calendar.getInstance();
		 SimpleDateFormat obj_format = new SimpleDateFormat("dd/MM/yyyy");
        
		 ls_ExpectedVal = ls_ExpectedVal.trim();
        
		 //If the Expected Value is appended with a ~, this signifies that the value to be compared is a partial string
        lc_firstchar = ls_ExpectedVal.substring(0,1);
        lc_firstTwochar = ls_ExpectedVal.substring(0,2);
        
        try
        {
        	// added on 07 Feb 18 - Shanmugakumar N
        	if(lc_firstTwochar.equals("!!")) // To get Store value from Storenum.txt file
        	{
        		ls_substring =ls_ExpectedVal.substring(2, ls_ExpectedVal.length());  
        		ls_ExpectedVal = ls_substring;	
        		//Call function GET_VALUE_FROM_VAR_DIC to fetch the value from the variable values dictionary
				ls_ExpectedVal =ls_obj.GET_VALUE_FROM_VAR_DIC(ls_ExpectedVal);
        	}
        	else if(lc_firstchar.equals("*"))
    		{
        		ls_substring =ls_ExpectedVal.substring(1, ls_ExpectedVal.length());  // added on 07 Feb 18 - Shanmugakumar N
        		ls_ExpectedVal = ls_substring;
    			
  		 		for (String key : Store_Value.variable_value.keySet()) 
  		 		{
  		 			if(key.equals(ls_ExpectedVal))
  		 			{
  		 				LOG.info("The Item "+ ls_ExpectedVal + " Exists in VariableValues Dictionary");
  		 				ls_ExpectedVal = Store_Value.variable_value.get(key);
  		 				break;
  		 			}
  		 			
  		 		}// for of key
   				
    		}//if of lc_firstchar    
        	else if (lc_firstchar.equals("~"))
        	{
        		ls_substring =ls_ExpectedVal.substring(1, ls_ExpectedVal.length());
        		ls_ExpectedVal = ls_substring;
        		//If Expected Value also contains a "*" after the "~" (~*data) which means that the value must be fetched from the variableValues dictionary
        		lc_firstchar =ls_substring.substring(0,1);
        		
        		if(lc_firstchar.equals("*"))
        		{
        			ls_substring =ls_ExpectedVal.substring(1, ls_ExpectedVal.length());// added on 07 Feb 18 - Shanmugakumar N
            		ls_ExpectedVal = ls_substring;
            		
            		for (String key : Store_Value.variable_value.keySet()) 
      		 		{
      		 			if(key.equals(ls_ExpectedVal))
      		 			{
      		 				LOG.info("The Item "+ ls_ExpectedVal + " Exists in VariableValues Dictionary");
      		 				ls_ExpectedVal = Store_Value.variable_value.get(key);	
      		 				break;
      		 			}	
      		 		}// for of key
        		
        		}//if of lc_firstchar
        		//To Handle date value 
            	else if (ls_ExpectedVal.substring(0, 2).equals("^^"))
        			 {
        				 	ls_ExpectedVal=ls_ExpectedVal.substring(3,ls_ExpectedVal.length()).trim();
        				 	int li_value = Integer.parseInt(ls_ExpectedVal);
        					obj_calender.setTime(new Date()); // Now use today date.
        					obj_calender.add(Calendar.DATE, li_value); // Adding days
        					ls_ExpectedVal = obj_format.format(obj_calender.getTime());
        				 	
//        					System.out.println(ls_Value);
        					int li_len = ls_ExpectedVal.length();
        					
//        					below condition modified by shan - 29/05/18
        					if (li_len<10)// to handle date with d format to dd in case for 1 to 9 
        				 	{
        						ls_ExpectedVal="0"+ls_ExpectedVal;
        				 	}//if of li_len
        			 
        			 }	//if of ^^
        	}
        	
        	//To Handle date value
        	else if(lc_firstchar.equals("^")) // added for to handle index out of bound exception Ex : ls_Value = 1  - shanmugakumar N 
    		{
    			 if (ls_ExpectedVal.substring(0, 2).equals("^^"))
    			 {
    				 	ls_ExpectedVal=ls_ExpectedVal.substring(3,ls_ExpectedVal.length()).trim();
    				 	int li_value = Integer.parseInt(ls_ExpectedVal);
    					obj_calender.setTime(new Date()); // Now use today date.
    					obj_calender.add(Calendar.DATE, li_value); // Adding days
    					ls_ExpectedVal = obj_format.format(obj_calender.getTime());
    				 	
//    					System.out.println(ls_Value);
    					int li_len = ls_ExpectedVal.length();
    					
//    					below condition modified by shan - 29/05/18
    					if (li_len<10)// to handle date with d format to dd in case for 1 to 9 
    				 	{
    						ls_ExpectedVal="0"+ls_ExpectedVal;
    				 	}//if of li_len
    			 
    			 }	//if of ^^
    		}
        	
        	//below lines commented by Shan
        	
//        	else if (lc_firstchar.equals("^"))
//        	 {
//        		//Call the COMPARE_VALUE function to compare two strings and returns a boolean value
//        		ls_doubleCarot ="^^";
//        		ls_substring =ls_ExpectedVal.substring(0, ls_doubleCarot.length());
//        	
//        		if(ls_substring.equals("^^"))
//        		{
//        			ls_substring =ls_ExpectedVal.substring(2, ls_ExpectedVal.length());
//        		
//        			ls_ExpectedVal=ls_substring;
//        			li_ExpectedVallen = ls_ExpectedVal.length();
//        		
//        			if (li_ExpectedVallen==1) // to handle date with d format to dd in case for 1 to 9 
//        			{
//        				ls_ExpectedVal="0"+ls_ExpectedVal;
//        			}// if date  characters
//        		
//        		        		
//        		}// if "^^"
//        	}
      }
        catch(Exception e)
      {
  		LOG.error("Exception in Check Value Function");
  	  }//END OF CATCH                           
     return ls_ExpectedVal;                               
    }// Method Check-value

}
