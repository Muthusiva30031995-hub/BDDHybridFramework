package Core_Lib;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

public class Random 
{
	public static String generate_RandomNo(int li_digit)   // updated by shanmugakumar - 01 Feb 18
	{
		//LOGGER
		Logger LOG = Logger.getLogger(Get_Property_Value.class.getName());
		long	random = 0;
		String ls_random;
		try
		{
			random=Math.round(Math.round(Math.random()*(Math.pow(10, li_digit)))); // updated by shanmugakumar - 01 Feb 18
		}catch(Exception e)
		{
			/*ls_Msg = "Exception in generating the Random number in Random function";
    		LOG.error(ls_Msg);
    		ls_Status = "Fail";*/
		}//END OF CATCH
		
		//need to be Removed
		/*if(report_type.equals("DETAIL"))
		{
			//for Excel detail reporting
			report_data.add(ls_FunctionName);//Function Name
			report_data.add("");//object name
			report_data.add("");//Expected
			report_data.add("");//Actual
			report_data.add(ls_Msg);//Detail
			report_data.add(ls_Status);//Status
			obj_Generic.Report(report_file,report_data );
		}*/
	    	ls_random = String.valueOf(random);
	    	return ls_random;
	}//END OF METHOD

}//END OF CLASS
