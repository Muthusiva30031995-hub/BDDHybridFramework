package Core_Lib;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class RoundValue
{
	public  String ROUND_VALUE(String Table_Value)
	{
		double li_ActualVal;
			
			String ls_val_Input;
			
			ls_val_Input = Table_Value.substring(Table_Value.length()-1);		
			
			if(ls_val_Input.equals("%"))
			{
				Table_Value = Table_Value.replace("%","");
	
				li_ActualVal=Double.parseDouble(Table_Value);
				
				BigDecimal bigDecimal_Act = new BigDecimal(li_ActualVal);
				bigDecimal_Act = bigDecimal_Act.setScale(0, RoundingMode.HALF_UP);
				
				Table_Value = bigDecimal_Act.toString();
	//			System.out.println(ls_Value);
			}
			else
			{
				li_ActualVal=Double.parseDouble(Table_Value);
				
				BigDecimal bigDecimal_Act = new BigDecimal(li_ActualVal);
				bigDecimal_Act = bigDecimal_Act.setScale(2, RoundingMode.HALF_UP);	
				
				Table_Value=bigDecimal_Act.toString();	
			}
			return Table_Value;	
	}
}
