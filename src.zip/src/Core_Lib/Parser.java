package Core_Lib;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.testng.Assert;



//This class will parse the excel data into key & value by reading a row 
public class Parser
{
	public Map<String, String>  parser(String []ls_parserarray, String Columnname) 
	{
		//LOGGER
		Logger LOG = Logger.getLogger(Parser.class.getName());
		
		//Reporting
		GenericLibrary obj_Generic = new GenericLibrary();
		String report_file = Harness.report_testcase;
		List<String> report_data = new ArrayList<String>();
		String report_type=Harness.ls_ReportingType;
		
		String ls_Msg = null,ls_FunctionName="Parser",ls_Status=null,ls_actual = null,ls_expected = null,ls_objectname;	
		
		List<String> arraylst = new ArrayList<String>();
		List<String> arraylst1 = new ArrayList<String>();
		
		 List<String> key_lst = new ArrayList<String>();
		 List<String> value_lst = new ArrayList<String>();
		 String[] equals_array=null;
		 String[] first_spilit_array;
		
		
		Map<String, String> map = new LinkedHashMap<String, String>();
		Get_Value_From_Var_Dic obj_dict = new Get_Value_From_Var_Dic();
		Harness obj_harness = new Harness();
		
		String ls_Parameter = null;              //  This hold's  parameter  after parsing
		String ls_Paramvalue = null ;           	//  This hold's  entire parameter  after parsing ls_text1
		String ls_Param = null;                      //  '   This hold's  Object Name  after parsing  ls_text2  
		String ls_strRow ;         			           // '   This hold's  Array value
		String ls_Parameter_Value = null; 		//' This holds the parameter name 
		String ls_DictionaryValue = null ;          // ' This hold dictonary value 
		String ls_Remark = null ;                     // ' This holds the Remark value
		String ls_VariableValue = null ;          		// ' This hold Variable value 
		String ls_ExpectedParamValue; 			//' This holds the Expected value
		String ls_Dictionary;
		String ls_Variable;
		String ls_excl_parameter=null;
		
		int ls_total_lenght1;           /// This hold's  the lengh of the entire string
		int ls_total_lenght2 ;          //' This hold's the lengh till the colon from the supplied string
		int ls_total_lenght3 ;         //  'This hold's the lengh till the < from the supplied string
		int li_loop = 0 ;                        //   '    This hold's the loop count
		int li_EXCLindex=0;
				
		boolean bln_match=false;
		 
		int li_arrayubound =ls_parserarray.length; // finding the length of parse string
		int  li_arrayubound1 = li_arrayubound-1;
		
		try
		{
			if (Harness.gi_DATASOURCE.equalsIgnoreCase("EXCLSOURCE"))   	
			{
				 
				 if (Columnname.trim().equalsIgnoreCase("Input_Parameter".trim())&&(Harness.gs_EXCLInputFieldname.length>0) &&(Harness.gs_EXCLInputvalue.length>0 ))
				 {
					 if(Harness.gs_EXCL_INPUTcurrentstart==0)
						 Harness.gs_EXCL_INPUTcurrentstart = Harness.gs_EXCL_INPUTcurrentstart+1;
					 
				  		li_EXCLindex =Harness.gs_EXCL_INPUTcurrentstart;
				 }
				  else if ((Harness.gs_EXCLOutputFieldname.length>0)&&(Harness.gs_EXCLOutputvalue.length>0))
				  {
					  li_EXCLindex =Harness.gs_EXCL_OUTPUTcurrentstart;
				  }
			}//if for gi_DATASOURCE
			
		}catch(Exception e)
		{
			LOG.error("Ecxetion in if condion of gi_DataSource IN PARSER Function");
		}
			// Using for loop apply split on string content with delimiter colon
		try
		{
			for( li_loop= 0 ;li_loop<=li_arrayubound1;li_loop++)
		 	{    
				
			      // ****This  holds the array text****
			      ls_strRow=ls_parserarray[li_loop];
			     
			      //****This Read's  the lengh of the entire string****
			      //ls_total_lenght1 = ls_strRow.lastIndexOf(">");
			      ls_total_lenght1 = ls_strRow.length();
			     
			      // *****This Read's the lengh till the colon from the supplied string ****
			      ls_total_lenght2 =  ls_strRow.indexOf(":");
			     
			      // *****This Read's the lengh till the Bracket from the supplied string ****
			      ls_total_lenght3 = ls_strRow.lastIndexOf("<");
			     
			      // ****This Read's the parameter Name ****
			      ls_Parameter =ls_strRow.substring(ls_total_lenght3+1,ls_total_lenght2);
			      
			       // ****This Read's the parameter value ****
			      ls_ExpectedParamValue =ls_strRow.substring(ls_total_lenght2+1, ls_total_lenght1);
			      ls_Parameter_Value=ls_ExpectedParamValue;
	
			      // Verifying the Column  name
			      if(Columnname.trim().equalsIgnoreCase("Input_Parameter".trim()))
			      	{
			    	  //****This Verifies the  Input_Parameter parameter value is not equal********
			    	  //************  to "ENTER_VALUE or "Null string  or "CTDR" if so it add the********
			    	  //************** values which is been entered in Excel sheet"****
			    	  	if ((! ls_Parameter_Value.toUpperCase().equals("ENTER_VALUE".trim().toUpperCase())) && ( ls_Parameter_Value!=null) && ( ! ls_Parameter_Value.toUpperCase().equals("CTDR".trim().toUpperCase())) && ( ! ls_Parameter_Value.toUpperCase().equals("EXCL".trim().toUpperCase())) && (! ls_Parameter_Value.toUpperCase().equals("*".trim())) &&(! ls_Parameter_Value.toUpperCase().equals("$".trim()))) 
			    	  	{
			    	  		//setting the excel value to true 
		           			obj_harness.gs_Excel=true;
			    	  		// **** This Concatinates all the parsed values****
			    	  		
		           			if (li_loop==0)
			    	  		{
			    	  			ls_Paramvalue =ls_Parameter_Value;
			    	  			ls_Param=ls_Parameter;
			    	  		}else
			    	  		 {
			    	  			ls_Paramvalue= ls_Paramvalue+"##"+ls_Parameter_Value;
			    	  			ls_Param= ls_Param+"##"+ls_Parameter;
			    	  		 }//else of li_loop
			    	  			
			    	  	 }else if ( ls_Parameter_Value.trim().equalsIgnoreCase("EXCL".trim())) 
			    	  	  {
			    	  		ls_excl_parameter=Harness.gs_EXCLInputFieldname[li_EXCLindex];

			    	  		//Addded by Ambika on 15/1/2018 t check whether the test caes object is matching with the object in data sheet
			    	  		if(ls_excl_parameter.equals(ls_Parameter.trim()))
			    	  		{
			    	  			bln_match=true;
			    	  		 ls_Parameter_Value = Harness.gs_EXCLInputvalue[li_EXCLindex];
			    	  		 if (li_loop==0) 
			    	  		 {
			    	  			 ls_Param=ls_Parameter;
			    	  			 ls_Paramvalue =ls_Parameter_Value;
			    	  			 //blnFlag=true;
			    	  		 }else
			    	  		  {
			    	  			 ls_Param= ls_Param+"##"+ls_Parameter;
			    	  			 ls_Paramvalue= ls_Paramvalue+"##"+ls_Parameter_Value;
			    	  			 //blnFlag=true;
			    	  		  }
			    	  		}else
			    	  		{
			    	  			System.out.println(ls_excl_parameter+"**************"+ls_Parameter);
			    	  			ls_expected=ls_Parameter;
			    	  			ls_actual=ls_excl_parameter;
			    	  			ls_Msg="Not Matched in input sheet";
			    	  			ls_Status="Fail";
			    	  			
			    	  			break;
			    	  		}
			    	  		 li_EXCLindex = li_EXCLindex + 1;
			    	  		 
			    	  	  	}else if ( ls_Parameter_Value.trim().toUpperCase().equals("*".trim()))
			    	  	  	 {
			    	  	  		ls_Dictionary = ls_Parameter_Value;
			    	  	  		if (ls_Dictionary.substring(0).equals("*"))
			    	  	  		{
			    	  	  			try
			    	  	  			{
			    	  	  				ls_DictionaryValue =obj_dict.GET_VALUE_FROM_VAR_DIC(ls_Dictionary);
			    	  	  			}catch(Exception e)
			    	  	  			{
			    	  	  				LOG.error("The dictionary value is null(*) from the variable dictionary in PARSER function");
			    	  	  			}//end of catch stmt
			    	  	  			
			    	  	  		}//if of ls_Dictionary
			    	  	  		
			    	  	  	 }else if(ls_Parameter_Value.trim().toUpperCase().equals("$".trim()))
			    	  	  	  {
			    	  	  		 // ****This Verifies the  Expected Output parameter value is equal  to "$" if so it add *******
			    	  	  		 //************the values which is been retrived from  Variable"****  
		             	
			    	  	  		 ls_Variable= ls_Parameter_Value;
			    	  	  		 if (ls_Variable.substring(0).equals("$"))
			    	  	  		 {
			    	  	  			 try
			    	  	  			 {
			    	  	  				 ls_VariableValue =obj_dict.GET_VALUE_FROM_VAR_DIC(ls_Variable);
			    	  	  			}catch(Exception e)
				    	  	  			{
				    	  	  				LOG.error("The dictionary value is null($) from the variable dictionary ");
				    	  	  			}//end of catch stmt
			    	  	  		 } else  
			    	  	  			 //Parameters to which the values are not entered are concatinated
			    	  	  			 ls_Remark= ls_Remark+"##"+ ls_Parameter;
		              	
			    	  	  	  }//else of $
			    	  	 	
			    	  	 
			      	} else if(Columnname.trim().equalsIgnoreCase("Expected_Output".trim()))
					   {
		      
			      			//****This Verifies the  Expected Output parameter value is not equal********
			    	  		//************  to "ENTER_VALUE or "Null string  or "CTDR" if so it add the********
			      			
			      			if ( (!ls_Parameter_Value.trim().toUpperCase().equals("CHECK_VALUE".trim().toUpperCase())) && ( ls_Parameter_Value!=null)&&(! ls_Parameter_Value.trim().toUpperCase().equals("CTDR".trim().toUpperCase())) && (ls_Parameter_Value.trim().toUpperCase().equals("EXCL".trim().toUpperCase())) && 
					    			  (ls_Parameter_Value.substring(0).equals("*".trim())) && (! ls_Parameter_Value.equals("$")))
			      			{
			      				obj_harness.gs_Excel=true;
			      				// **** This Concatinates all the parsed values****
			      				if( li_loop==0) 
					    		  {
			      						ls_Paramvalue=ls_Parameter_Value;
			      						ls_Param=ls_Parameter;
					    		  }else
					    		  {
					    			  ls_Paramvalue= ls_Paramvalue+"##"+ls_Parameter_Value;
					    			  ls_Param= ls_Param+"##"+ls_Parameter;
					    		  }//else of li_loop
					     
					     } else if (ls_Parameter_Value.equalsIgnoreCase("EXCL"))
					     	{
					    		  //**** This Concatinates all the parsed values****
					    		 // LOG.info("OUTPUT VALUE IS EXCL ");
					    	 ls_excl_parameter=Harness.gs_EXCLOutputFieldname[li_EXCLindex+1];

				    	  		//Addded by Ambika on 15/1/2018 t check whether the test caes object is matching with the object in data sheet
				    	  		if(ls_excl_parameter.equals(ls_Parameter))
				    	  		{
				    	  			bln_match=true;
					    		  ls_Parameter_Value = Harness.gs_EXCLOutputvalue[li_EXCLindex+1];
//					    		  LOG.info("ls_Parameter_Value"+ls_Parameter_Value);
					    		  if (li_loop==0) 
					                 {
					                    ls_Param=ls_Parameter;
					                    ls_Paramvalue =ls_Parameter_Value;
					                    //blnFlag=true;
					                 }
					                 else
					                 {
					                    ls_Param= ls_Param+"##"+ls_Parameter;
					                    ls_Paramvalue= ls_Paramvalue+"##"+ls_Parameter_Value;
					                    //blnFlag=true;
					                 }
				    	  		}else
				    	  		{
				    	  			System.out.println(ls_excl_parameter+"**************"+ls_Parameter);
				    	  			ls_expected=ls_Parameter;
				    	  			ls_actual=ls_excl_parameter;
				    	  			ls_Msg="Not Matched in output sheet";
				    	  			ls_Status="Fail";
				    	  			break;
				    	  		}      
					    		  li_EXCLindex = li_EXCLindex + 1;
					               
					    		  if (ls_Parameter_Value.substring(1).trim().equals("*".trim().toUpperCase()))
					    		  {
					    			  ls_Dictionary = ls_Parameter_Value;
					    			  Get_Value_From_Var_Dic ls_obj = new Get_Value_From_Var_Dic();
					    			  try
					    			  {
					    				  ls_VariableValue =ls_obj.GET_VALUE_FROM_VAR_DIC(ls_Dictionary);
					    			  }catch(Exception e)
				    	  	  			{
				    	  	  				LOG.error("The dictionary value is nullof variable dictionary");
				    	  	  			}//end of catch stmt
					    			  ls_Paramvalue= ls_DictionaryValue;
		            			
					    		  } else if (ls_Parameter_Value.substring(0).equals("$".trim().toUpperCase()))
					    		   {
					    			  ls_Variable=ls_Parameter_Value;
					    			  Get_Stored_Variable obj_stored_var = new Get_Stored_Variable();
					    			  try
					    			  {
					    				  ls_VariableValue =obj_stored_var.GET_STORED_VARIABLE(ls_Variable);
					    			  }catch(Exception e)
				    	  	  			{
				    	  	  				LOG.error("The dictionary value is null of stored variable  in PARSER function");
				    	  	  			}//end of catch stmt
					    			  ls_Paramvalue= ls_VariableValue;  
					    		   }// else of ls_parameter
					    		 
					    	 } else if (ls_Parameter_Value.substring(0).trim().toUpperCase().equals("*".trim()))  // updated this condition in order to maintain uniformity
				            	{
		                                        
					    		 	//  ****This Verifies the  Expected Output parameter value is equal  to "*" if so it add *******
					    		 	//************the values which is been retrived from  dicttonary"****    
					  
					    		 	ls_Dictionary= ls_Parameter_Value;
					    		 	Get_Value_From_Var_Dic ls_obj = new Get_Value_From_Var_Dic();
					    		 	try
					    		 	{
					    		 		ls_DictionaryValue = 	ls_obj.GET_VALUE_FROM_VAR_DIC(ls_Dictionary);
					    		 	}catch(Exception e)
			    	  	  			{
			    	  	  				LOG.error("The dictionary value is null  from variable dictionary in PARSER function");
			    	  	  			}//end of catch stmt
					    		 	
					    		 	ls_Paramvalue= ls_DictionaryValue;  
					    		 	ls_Param=ls_Parameter ; 
					    		 	
				            	}else if ( ls_Parameter_Value.substring(0).trim().toUpperCase().equals("$".trim().toUpperCase()))
				            	 { 
		          
				            		// ****This Verifies the  Expected Output parameter value is equal  to "$" if so it add *******
				            		//************the values which is been retrived from  Variable"****  
				            		//	updated this condition in order to maintain uniformity
				            		
				            		ls_Variable=ls_Parameter_Value;
				            		Get_Stored_Variable obj_stored_var = new Get_Stored_Variable();
				            		try
				            		{
				            			ls_VariableValue =obj_stored_var.GET_STORED_VARIABLE(ls_Variable);
				            		}catch(Exception e)
			    	  	  			{
			    	  	  				LOG.error("The dictionary value is null from the stored variable in PARSER function");
			    	  	  			}//end of catch stmt
				            		ls_Paramvalue= ls_VariableValue;  
				            		ls_Param=ls_Parameter;
				            		
				            	 }else 
					              {
		          	
				            		 //Parameters to which the values are not entered are concatinated
				            		 ls_Remark= ls_Remark+"##"+ ls_Parameter;
				            		 
					              }
			    	  
					      	
					   }//if of Columnname
			    
							
			      try
			      {
			      	map.put(ls_Parameter, ls_Parameter_Value);
			      }catch(Exception e)
			      {
			    	  LOG.error("UNABLE TO ADD IN MAP OF PARSER FUNCTION");
			      }//END OF CATCH
			      	
		 	}//for of li_loop
			 if(report_type.equals("DETAIL")&&ls_Status.equals("Fail"))
				{
					//for Excel detail reporting
					report_data.add(ls_FunctionName);//Function Name
					report_data.add("");//object name
					report_data.add(ls_expected);//Expected
					report_data.add(ls_actual);//Actual
					report_data.add(ls_Msg);//Detail
					report_data.add(ls_Status);//Status
					obj_Generic.Report(report_file,report_data );
					
					Assert.assertTrue(false, "The "+ls_expected+" is not matched in datasheet ");
				}
						
		}catch(Exception e)
		{
			LOG.error("Exception in For loop of array in Parser Function");
		}//END OF CATCH
			
		 try
		 {
			 if (Columnname.equalsIgnoreCase("Input_Parameter"))
		   	 {
			      // ***ls_text  value is split  and fed to an environment array ****
		          Harness.gs_InputParameter_Value=  ls_Paramvalue.split("##");
			      Harness.gs_InputParameter= ls_Param.split("##");
		
		         Harness.gs_EXCL_INPUTcurrentstart=li_EXCLindex ;
		       	}else if (Columnname.equalsIgnoreCase("Expected_Output"))
		          {		          
		          	// ***ls_text  value is split  and  fed to an environment array****
		        	 Harness.gs_Output_Object_Value=  ls_Paramvalue.split("##");
		      		// '  ***ls_text  value is split and fed to an environment array****
		      		Harness.gs_Output_Object= ls_Param.split("##");
		         
		        	  Harness.gs_EXCL_OUTPUTcurrentstart=li_EXCLindex ;
		         
		         }//END OF ELSE COLUMN NAME
		          
			 }catch(Exception e)
			 {
				//LOG.error("Exception in if of columnName in Parser Function");
			 }
		
		return map;
		
  }//method ends
	
	
}//class


