package Core_Lib;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class Check_Object_Enabled 
{

	public boolean CHECK_OBJECT_ENABLED(String object_name)  
	{
		//LOGGER
		Logger LOG = Logger.getLogger(Check_Object_Exist.class.getName());

		//Detail Reporting
		 GenericLibrary obj_Generic = new GenericLibrary();
		 String report_file = Harness.report_testcase;
		 List<String> report_data = new ArrayList<String>();
		 String report_type=Harness.ls_ReportingType;
		 String ls_Functionname="CHECK_OBJECT_ENABLED";
		 String ls_Msg=null;
		 String ls_status=null;
		
		Get_Object_Identifier gui_object= new Get_Object_Identifier();
		
		//Getting WebDriver Control to perform action
		 WebDriver driver = Browser_Invoke_Url.driver;
		 
		 boolean lb_exist =false;
		 String optional_ERR_FLAG=null;
		 WebElement element=null;
		
		//Identifying the object
		
			try {
				////Muthu-thread.sleep(10000);
				element =	gui_object.GET_OBJECT_IDENTIFIER(driver, object_name,null, optional_ERR_FLAG); 
				
			
		//check the element is exist or not		
		if (element.isEnabled())
		{
			lb_exist=true;
			ls_Msg="The Object is Enabled";
			ls_status="Pass";
		}else
		{
			if(optional_ERR_FLAG.equalsIgnoreCase("NotEnabled"))
			{
				lb_exist=true;
				ls_Msg="The Object is Enabled";
				ls_status="Pass";
			}else
			{
				
				ls_Msg="The Object does not Enabled";
				ls_status="Fail";
			}
			/*//validation
			Assert.assertTrue(lb_exist, "The WebElement doesnot exist");*/
		}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		if(report_type.equals("DETAIL"))
		{
			//for Excl DETAIL reporting
			report_data.add(ls_Functionname);
			report_data.add(object_name);
			report_data.add("");
			report_data.add("");
			report_data.add(ls_Msg);
			report_data.add(ls_status);
			obj_Generic.Report(report_file,report_data );
		}//if of report
		
		return lb_exist;
		
	 }//
}
