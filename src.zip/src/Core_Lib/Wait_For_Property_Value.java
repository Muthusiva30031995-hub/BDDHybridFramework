package Core_Lib;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;


// WAITFOR_PROPERTY_VALUE waits for a runtime properties value to be in the state needed for a test case
//to continue to run and to provide a certain level of synchronization 
public class Wait_For_Property_Value 
{
	public boolean  WAITFOR_PROPERTY_VALUE (WebDriver driver,String ls_ObjectName,String ls_Property,String ls_Value,int li_TimeOut,String InFunction, String optional_ERR_FLAG)
	{
		//LOGGER
		Logger LOG = Logger.getLogger(Wait_For_Property_Value.class.getName());	
		
		Get_Object_Identifier ls_obj = new Get_Object_Identifier();
		
		String ls_PropertyFullName;
		String sChkState;
		String myStr;
		boolean bReturn;
		
		int Cnt;
		
		WebElement ele_object = null;
				
			
		ls_PropertyFullName = "attribute/"+ ls_Property;
		sChkState = "";
		bReturn = false;
		Cnt = 0;
		
		if (InFunction.toLowerCase().equals("true"))
		{
			try
			{
				ele_object= ls_obj.GET_OBJECT_IDENTIFIER(driver, ls_ObjectName,ls_Value, optional_ERR_FLAG);
			}catch(Exception e)
			{
					LOG.error("Unable to find the WebElement in Wait_For_Property_Value");
			}//end of catch stmt
				
		}//if of InFunction
			      
		//Wait for the property in question to attain a certain value
			
        myStr = "bReturn = ." +ls_ObjectName+"(sObjectName).WaitProperty(";
        myStr = myStr+"attribute/" + ls_Property+ ", " +ls_Value+ "," + li_TimeOut + ")";
			        
	    //if the properties value does not match sValue after the timeout period then perform the following checks
	    //as the WaitProperty method does not always work for all properties
		    
        if (!bReturn)
		{                           
          while (sChkState != ls_Value && Cnt <= li_TimeOut)
           {
        	  try
	           {
	       		   sChkState= ele_object.getAttribute(ls_Property);
	       	   }catch(Exception e)
				{
	       		   LOG.error("Unable to get attribute value  in Wait_For_Property_Value");
				}//end of catch stmt
	        	   
	            if (sChkState.equals("" )) 
	            {
	           	  try
	           	  {
	           		  sChkState= ele_object.getAttribute( ls_PropertyFullName);
	           	  }catch(Exception e)
					{
	           		  	LOG.error("Unable to get attribute value  in Wait_For_Property_Value");
					}//end of catch stmt
	                  
	           	  	if (sChkState.equals("" ))  
	                 {
	               	  try
	               	  {
	               		  sChkState= ele_object.getAttribute( ls_PropertyFullName);
	               	  }catch(Exception e)
	               	  {
	               		LOG.error("Unable to get attribute value  in Wait_For_Property_Value");
	               	  }//end of catch stmt

	                  if (sChkState.equals("" ))  
	                  {
	                	  try
	                	  {
	                		  ele_object.getAttribute( ls_Property);
	                	  }catch(Exception e)
	  						{
	                		  LOG.error("Unable to get attribute value  in Wait_For_Property_Value");
	  						}//end of catch stmt
	                	  
	                  	}//end of if 
	                  }//IF OF SCHKSTATE
	           	  	
	              } else
	              {
	            	  try
	              		{
	            		//  //Muthu-Thread.sleep(li_TimeOut);
	            		  
	              		}catch(Exception e)
						{
	              			LOG.error("Exception of //Muthu-Thread statment  in Wait_For_Property_Value");
						}//end of catch stmt
	              }//ELSE
	              Cnt = Cnt + 1;      
	                   
	           }//end while         
			        
	        }//end if
			        
			if  (!(sChkState==null)||(sChkState != "" ))
			{
			    //check if the property value matchs sValue
			     if(sChkState.toLowerCase().trim().equals(ls_Value.trim().toLowerCase()))
			     {
			         bReturn = true;
			         LOG.error( "The property " + ls_Property +" of object " + ls_ObjectName+"was successfully compared to the expected result. ");
			     }// if of comparing sChkState with ls_Value
			}//end of if 
	                                                         
			 Assert.assertTrue(bReturn, "Object Actual Value: "+ sChkState+" and the Expected Value: "+ls_Value+" have been successfully compared." );
			
		
	    return bReturn;
			
	 }// wait method end 
	                    	 
 }//end class



