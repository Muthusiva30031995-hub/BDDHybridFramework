package Core_Lib;


import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

public class Browser_Close 
{
	public void BROWSER_CLOSE(String optional_ERR_FLAG)
	{
		//Logger
		Logger LOG = Logger.getLogger(Browser_Close.class.getName());
		
		//Reporting
		 GenericLibrary obj_Generic = new GenericLibrary();
		 String report_file = Harness.report_testcase;
		 List<String> report_data = new ArrayList<String>();
		 List<String> popup_report_data = new ArrayList<String>();
		 List<String> catch_report_data = new ArrayList<String>();
		 String report_type=Harness.ls_ReportingType;
		 String ls_Functionname="BROWSER_CLOSE";
		 String ls_Msg=null;
		 String ls_status=null;
		 
		//Getting the driver control from screen_Driver function
		WebDriver  driver=  ScreenDriver.scr_driver;	
		
		//Getting the pop_up driver control from screen_Driver function
		 WebDriver  pop_updriver =ScreenDriver.popup_driver;
		
		   try
		   {
			   /*if(pop_updriver!=null)    //  condition commented by shanmugakumar 25 Jan 18
			   {
//				   pop_updriver.close();
				   pop_updriver.quit();  
				   //Muthu-thread.sleep(2000);
				  
				   GenericLibrary.shiftContrlToParentWindow(pop_updriver);
				   pop_updriver=null;
				   ls_Msg="The Pop_Up Application is Closed  Successfully";
				   ls_status="Pass";
				   if(report_type.equals("DETAIL"))
					{
						//for Excl DETAIL reporting
					   popup_report_data.add(ls_Functionname);
					   popup_report_data.add("");
					   popup_report_data.add("");
					   popup_report_data.add("");
					   popup_report_data.add(ls_Msg);
					   popup_report_data.add(ls_status);
						GenericLibrary.Report(report_file,popup_report_data );
					}//if of report
				   LOG.info("The Pop_Up Application is Closed  Successfully");				   
			   }//END OF POP_UP DRIVER
*/			 
			   //check if the driver is not null 
			   if (driver!=null)
			   {
				   //Muthu-thread.sleep(2000);
 			   driver.close();//quitting the browser
				  // driver.quit(); // closing the browser and kill the back end process - shanmugakumar N   25 Jan 18
				  // driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
				   //for reporting
				   ls_Msg="The Application is Closed  Successfully";
				   ls_status="Pass";
				   LOG.info("The Application is Closed  Successfully");
				   
				   if(driver!=null)
				   {
					   driver=null;
				   }//END OF IF
			   }else
			    {
				   ls_Msg="Unable to close the Application ";
				   ls_status="Fail";
				  LOG.info("THE DRIVER IS NULL");
			    }//else of driver
			   if(report_type.equals("DETAIL"))
				{
					//for Excl DETAIL reporting
					report_data.add(ls_Functionname);
					report_data.add("");
					report_data.add("");
					report_data.add("");
					report_data.add(ls_Msg);
					report_data.add(ls_status);
					obj_Generic.Report(report_file,report_data );
				}//if of report
							 	
		}catch(Exception e)
		    {
			   LOG.error("EXCEPTION IN BROWSER CLOSE FUNCTION");
			   ls_Msg="EXCEPTION IN BROWSER CLOSE FUNCTION";
			   ls_status="Fail";
			   if(report_type.equals("DETAIL"))
				{
					//for Excl DETAIL reporting
				   catch_report_data.add(ls_Functionname);
				   catch_report_data.add("");
				   catch_report_data.add("");
				   catch_report_data.add("");
				   catch_report_data.add(ls_Msg);
				   catch_report_data.add(ls_status);
				   obj_Generic.Report(report_file,catch_report_data );
				}//if of report
			   
		    }//catch
		   
		  // return driver;		//return the driver
	        	
	    }//method end

	}//end class


