package Core_Lib;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.testng.Assert;


//This function stores the value in a variable by loading it into the Dictionary object
public class Store_Value

{ 
	public static  Map<String, String> variable_value = new LinkedHashMap<String, String>();//This map is used to store values from text file
	
	public void  STORE_VALUE(String ls_ObjectName,String Data_String,String Var_Name) 
	{
	
		//LOGGER
		Logger LOG = Logger.getLogger(Store_Value.class.getName());
		
		//Reporting
		GenericLibrary obj_Generic = new GenericLibrary();
		String report_file = Harness.report_testcase;
		List<String> report_data = new ArrayList<String>();
		String report_type=Harness.ls_ReportingType;
		
		String ls_Msg,ls_FunctionName="STORE_VALUE",ls_Status;	
		
		boolean lb_storevalue=false;
	 
		Get_Value_From_Var_Dic ls_obj = new Get_Value_From_Var_Dic();
		try
		{
//			variable_value=ls_obj.get_dic_map(); // commented by shan - 13 Feb 18
			variable_value.put(Var_Name, Data_String);
				  //To check for the existence of the variable in the dictionary object
			   
				  for (String key : variable_value.keySet()) 
				  {
					  if(key.equals(Var_Name))
						  lb_storevalue=true; 
					 
				  }//for of value
				  if(lb_storevalue)
				  {
					  ls_Msg = "The Key " + Var_Name + " with the value "  + Data_String + " is added to the VariableValues dictionary object";
					  LOG.info(ls_Msg);
					  ls_Status = "Done";
				  }
				  else
				  {
					ls_Msg =  "The Value does not exist and is not added into the VariableValues dictionary.";
		    		LOG.error(ls_Msg);
		    		ls_Status = "Fail";
				  }

		}
		catch(Exception e)
		{
			ls_Msg = "The Value does not exist  in the VariableValues dictionary in Store_Value Function ";
    		LOG.error(ls_Msg);
    		ls_Status = "Fail";
		}//end of catch stmt
		 
		//	To Load the variable into the dictionary
	 
		
		/*if(report_type.equals("DETAIL"))
		{
			//for Excel detail reporting
			report_data.add(ls_FunctionName);//Function Name
			report_data.add("");//object name
			report_data.add(Data_String);//Expected
			report_data.add("");//Actual
			report_data.add(ls_Msg);//Detail
			report_data.add(ls_Status);//Status
			GenericLibrary.Report(report_file,report_data );
		}   */
		
		//VALIDATION
		Assert.assertNotNull(variable_value, ls_Msg);

}//method end 

}//class end
