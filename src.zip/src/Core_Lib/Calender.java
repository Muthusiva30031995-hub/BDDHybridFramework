package Core_Lib;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Calender 
{
	public static void DATE_PICKER()
	{
		Logger LOG = Logger.getLogger(Calender.class.getName());
		
		//Detail Reporting
		 GenericLibrary obj_Generic = new GenericLibrary();
		 String report_file = Harness.report_testcase;
		 List<String> report_data = new ArrayList<String>();
		 String report_type=Harness.ls_ReportingType;
		 String ls_Functionname="Calender";
		 String ls_Msg=null;
		 String ls_status=null;
		
		WebDriver driver = ScreenDriver.scr_driver;
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MMMMM/dd");
		Date date = new Date();
		try
		{
		LOG.info(dateFormat.format(date));
		
		String[] ls_arr_date =date.toLocaleString().split("-");
		String[] ls_arr_year =ls_arr_date[2].split(" ");
		
		String ls_date = ls_arr_date[0];
		String ls_year = ls_arr_year[0];
		
		LOG.info("Date"+ls_date);
		LOG.info("year"+ls_year); 
		
		
		WebElement ele_year = driver.findElement(By.xpath("//tr[@id='calDateFrom_HeaderTr']/td/div/span[2]"));
		String ls_monthYear = ele_year.getText();
		
		String[] ls_arr = ls_monthYear.split(" ");
		String ls_appyear = ls_arr[1];
		
		//if(!ls_appyear.equals(ls_year))
		//{
			int li_year=Integer.parseInt(ls_year);
			int li_appyear=Integer.parseInt(ls_appyear);
			if(li_appyear>li_year)
			{
				
				WebElement down_year_link = driver.findElement(By.xpath("//tr[@id='calDateFrom_HeaderTr']/td/div/span[1]/span[1]"));
				down_year_link.click();
				
			}//if of greater then year
					
		//}//if of not equals years
		
		String id = "calDateFrom_2018_10_"+ls_date+"_0";
		WebElement ele_day = driver.findElement(By.id(id));
		ele_day.click();
		
		WebElement ele_ok_btn = driver.findElement(By.xpath("//td[@id='calDateFrom_FooterTd']/div/span/input[1]"));
		ele_ok_btn.click();
		
		}catch(Exception e)
		{
			LOG.info("Exception in calender function");
			ls_Msg="Exception in calender function";
			ls_status="Fail";
			 if(report_type.equals("DETAIL"))
				{
					//for Excl DETAIL reporting
					report_data.add(ls_Functionname);
					report_data.add("");
					report_data.add("");
					report_data.add("");
					report_data.add(ls_Msg);
					report_data.add(ls_status);
					obj_Generic.Report(report_file,report_data );
				}//if of report
		}
		
	}
}
