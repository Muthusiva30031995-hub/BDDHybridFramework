package Core_Lib;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;


// This function is used to check the property value of an object.
// It Calls the GET_PROPERTY_VALUE function to get the property value of the object which needs to be checked.
//Then it calls the CHECK_VALUE function to compare the Actual and Expected property values and return TRUE/FALSE.

public class Check_Empty_Value
{
	
	public boolean CHECK_EMPTY_VALUE(WebDriver driver, String ls_ObjectName, String ls_Property,String  ls_Value, String Label_Name, String optional_ERR_FLAG)
	{ 
		//LOGGER
		Logger LOG = Logger.getLogger(Check_Empty_Value.class.getName());
	
		//Detail Reporting
		 RoundValue obj_RoundValue = new RoundValue();
		 GenericLibrary obj_Generic = new GenericLibrary();
		 String report_file = Harness.report_testcase;
		 List<String> report_data = new ArrayList<String>();
		 String report_type=Harness.ls_ReportingType;
		 String ls_Functionname="CHECK_EMPTY_VALUE";
		 String ls_Msg=null;
		 String ls_status=null;
		
		 String check_Prop_Value = null;
		 boolean blnCheck = false;
		 
		 boolean lb_check_empty = false;
	
		 //creating object for the particular class
		 Get_Property_Value object_property = new Get_Property_Value();
		 GET_ExpectedValue obj_ExpVal = new GET_ExpectedValue();
		 Check_Value obj_check_value = new Check_Value();
	
		if(ls_ObjectName.toLowerCase().contains("RadioGroup"))
		{
			if(ls_Property.equals("selected item index")) 
				ls_Value = ls_Value + 1;
	                               
		}//check objectName contains RadioGroup
	                                
		//Call the GET_PROPERTY_VALUE function to get the property value of the object which needs to be checked
		
		check_Prop_Value = object_property.GET_PROPERTY_VALUE(driver, ls_ObjectName, ls_Property,ls_Value, optional_ERR_FLAG);
         
		if(!check_Prop_Value.equalsIgnoreCase("Obj Issue"))
		{
			lb_check_empty = true;
			//Call the CHECK_VALUE Function for Comparing the Property Values
		
			ls_Value = ls_Value.trim();
			
			if(check_Prop_Value.equalsIgnoreCase("") && (ls_Value.equalsIgnoreCase("")))
			{
				blnCheck = true;
			}
			//calling Check_VAlue Function
	
			//Validation
	   		if(blnCheck)
	   		{
	   			ls_status="Pass";
	   			ls_Msg="Compared";	
	   		}
	   		else
	   		{
	   			ls_status="Fail";
	   			ls_Msg="Mismatch";
	   		}//else of blnflag
	   		
	        if(report_type.equals("GENERAL"))
			{
				//reporting
				report_data.add(ls_Functionname);
				report_data.add(ls_ObjectName);
				report_data.add(ls_Value);
				report_data.add(check_Prop_Value);
				report_data.add(ls_status);
				obj_Generic.Report(report_file,report_data );
			}//if of reporting
		    else if(report_type.equals("DETAIL"))
		    {
		    	//reporting
				report_data.add(ls_Functionname);
				report_data.add(ls_ObjectName);
				report_data.add(ls_Value);
				report_data.add(check_Prop_Value);
				report_data.add(ls_Msg);
				report_data.add(ls_status);
				obj_Generic.Report(report_file,report_data );
		    }
		} // End if obj issue
	return lb_check_empty;
	   
   }//end of method 

}//end of Function

