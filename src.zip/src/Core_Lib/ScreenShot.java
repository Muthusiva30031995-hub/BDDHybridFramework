package Core_Lib;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;

public class ScreenShot 
{
	public static String tempSnapshotStr="";
	public void screenShot(ITestResult result)
	{
		//LOGGER
		Logger LOG = Logger.getLogger(ScreenShot.class.getName());
		
		WebDriver driver = Browser_Invoke_Url.driver;
		 try 
		 {
			 if ( (Harness.gs_Screenshot.equalsIgnoreCase("Yes")))
	            {

			 // Create refernce of TakesScreenshot
			 TakesScreenshot ts=(TakesScreenshot)driver;
	 	
			 // Call method to capture screenshot
			 File source=ts.getScreenshotAs(OutputType.FILE);
		  
			 // Copy files to specific location here it will save all screenshot in our project home directory and
			 // result.getName() will return name of test case so that screenshot name will be same
			 DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy/HH/mm/ss");
			 Date date = new Date();
				
			String ls_date=dateFormat.format(date);
			//String ls_destinationFilepath =Harness.gs_root_path;			
			String ls_destinationFilepath1 =Harness.reportExcelScreenShotFolder;
			ls_date =ls_date.replaceAll("/","-");
			//FileUtils.copyFile(source, new File(ls_destinationFilepath+"ScreenShot"+"/Failure/"+Harness.ls_Testcaseid+ls_date+".png"));
			
			tempSnapshotStr=ls_destinationFilepath1+ "/Failure/" + Harness.ls_Testcaseid+ls_date+".png";
			FileUtils.copyFile(source, new File(tempSnapshotStr));
		  
			LOG.info("Screenshot is  taken Successfully");
			//closing the browser 
	            }
		 }
		 catch (Exception e)
		 {
		 LOG.error("Exception while taking screenshot "+e.getMessage());
		 } 
		 
	}	
		
	public static String getScreenhot(WebDriver driver, String screenshotName) throws Exception {
				String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
				TakesScreenshot ts = (TakesScreenshot) driver;
				File source = ts.getScreenshotAs(OutputType.FILE);
		                //after execution, you could see a folder "FailedTestsScreenshots" under src folder
				String destination = System.getProperty("user.dir") + "/FailedTestsScreenshots/"+screenshotName+dateName+".png";
				File finalDestination = new File(destination);
				FileUtils.copyFile(source, finalDestination);
				return destination;
			}

}
