package Core_Lib;

import Core_Lib.GenericLibrary;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;


//Functionality to allow the use of pop-up browsers. Will obtain the handle of the open browser
//and save to file. This is then used to uniquely reference the pop-up window.

public class Get_PopUp_Objects 

{
	//public static WebDriver popup_driver = Browser_Invoke_Url.driver;
	
	public WebDriver get_PopUp_Objects(String ls_URLtype, String lb_optional_ERR_FLAG)
	{  
		//LOGGER
		Logger LOG = Logger.getLogger(Get_Object_Identifier.class.getName());
		
		//Detail Reporting
		 GenericLibrary obj_Generic = new GenericLibrary();
		 String report_file = Harness.report_testcase;
		 List<String> report_data = new ArrayList<String>();
		 String report_type=Harness.ls_ReportingType;
		 String ls_Functionname="GET_POPUP_OBJECTS";
		 String ls_Msg=null;
		 String ls_status=null;
		 
	   // String hWND = null ;    // handle of the window
	    
	    Harness obj_harness = new Harness();
	    
	    String ls_openurl = null,  ls_patrn = null, ls_patrn1=null;
	    String ls_searchtitle = null,ls_leftstring=null;

	    String WTM_APP_URL =Harness.gs_url;
	    String WTM_PegaODM_URL = Harness.gs_ODM_Url;
	    String Browser = Harness.gs_Browser;
  
	   // Assignment of appropriate patern to look for depending on the type of pop-up
	    try
	    {  
	    	switch(ls_URLtype)
	    	{
	    		case "Switch" :
	    			ls_patrn = "GenericPopUp.jsp?";
	    			break;
	    			
	    		case "Others" :  
	    			ls_patrn = "cdm/";
	    			break;
				
	    		case "PolicyEndorse":
	    			ls_patrn = "/servlet/PremiumServlet";
	    			break;
	    			
	    		case "PrintCurrencyCertificate" :
	    			ls_patrn = "/servlet/WorkersCompCertificateOfCurrencyServlet";
	    			break;
               
	    		case "PolicyRenewal" :
	    			ls_patrn = "/inquiry/RenewDate";
	    			break;
	    			
	    		case "FileNotes" :
	    			ls_patrn = "/ILvoOfHVASukBcAWDohgdkwvWOCyEdlg*";
	    			break;
	    			
	    		case "StartNewProcess" :
	    			ls_patrn = "/ILvoOfHVASukBcAWDohgdkrNo_nrqcdIHPkD0Rhsbbg%5B*";
	    			break;
	    			
	    		case "Calender" :
	    			ls_patrn = "8zdCQQd6Ck4S3A4jCkcQfOmR6SuGEnVOeKw-ToCa_TU%5B*/!STANDARD?pyActivity=ShowCalendar";
	    			break;
	    			
	    		case "NewCalender" :
	    			ls_patrn = "b3yLOswWX-MzLYp2OTvEun4MLeS1tD0Y*/!STANDARD?pyActivity=ShowCalendar";
	    			break;
               
	    		case "ClaimWrite" :
	    			ls_patrn = "8zdCQQd6Ck4S3A4jCkcQfOmR6SuGEnVOeKw-ToCa_TU%5B*/!STANDARD?pyActivity=QBE-Ins-UW-QuoteInstance.CallCchange";
	    			break;
                
	    		case "ReLaunchClaimWrite":
	    			ls_patrn = "aV1dhqTUu8d4H-CI0KvsBQ%5B%5B*/!STANDARD?pyActivity=QBE-Ins-UW-QuoteInstance.CallCchange";
	    			break;
                
	    		case "AdvanceFilters": 
                      ls_patrn="!STANDARD?pyActivity=QBE-Ins-UW-QuoteInstance";
                      break;
	    		case "PolicyCancel" :
	    			ls_patrn ="/servlet/PolicyCancelServlet?" ;
	    			break;
               
	    		case "AdvanceFilters_QUW" :
	    			ls_patrn="!STANDARD?pyActivity=QBE-Ins-UW-QuoteInstance";
	    			break;
	    			
	    		case "Response" :
	    			ls_patrn ="/util/show_log.jsp";
	    			break;
				
	    		case "HelpElders-IntranetLogon":
	    			//Muthu-Thread.sleep(10); //wait 10 'this wait time added to compensate the launching time of new popup browser;
	    			ls_patrn="cmlogin.";
	    			break;
	    			
	    		case "IWWiseReportingLogon" :
	    			ls_patrn="ibi_apps/Home";
	    			break;
			
	    		case "TPOSPreviewQuote":
	    			ls_patrn="/QBETravel?certificate";
	    			break;
		
	    		case "TPOSViewRemu" :
	    			ls_patrn="?getDoc=true&documenttype=PFS&documentid";
	    			break;
			
	    		case "TPOSViewPolicy":
	    			ls_patrn="?certificate=true&type=Q&dbtype=tpos&policy_no=";
	    			break;
			
	    		case "TPOSProductDisclosure":
	    			ls_patrn="document=true&documentid=";
	    			break;
			
	    		case "TPOSPublicCertiifcate":
	    			ls_patrn="/QBETravel?document";
	    			break;
	    			
	    		case "TPOSTermofuse":
	    			System.out.println("Term of use");
	    			ls_patrn="/QBETravel?other";
	    			break;
			
	    		case "TPOSBenefits":
	    			ls_patrn="getDoc=true&documenttype=PBF";
	    			break;
			
	    		case "TPOSCertificate":
	    			ls_patrn="certificate=true&type=P&policy_no=";
	    			break;
		
	    		case "TPOSContactus":
	    			ls_patrn="pageWrapper=common/popupWrapper.jsp&pageName=contact&aid";
	    			break;
	    		
	    		case "IPortalGenius":
	    			ls_patrn="Genius.aspx?";
	    			break;
	    		
	    		//below cases added by shanmugakumar 11-01-18
	    		case "ODM_DocumentLink":
	    			ls_patrn="wccdoc?dDocName";
	    			break;
	    			
	    		case "ODM_MySavedSearch":
	    			ls_patrn="?fFolderGUID"; 
	    			break;
	    		
	    		case "PegaODM_DocumentLink":
	    			ls_patrn1 = "/faces/wccdoc";
	    			ls_patrn = "/adfAuthenticati"; 
	    			break;
	    		case "PegaODM_DocLink":
	    			ls_patrn = "/faces/wccdoc";
	    			break;
	    			
	    		case "QGlobal":
	    			ls_patrn=""; 
	    			break;

			case "ODM_CreateAliasLink"://this case added by Moorthy 07/05/2018
	    			ls_patrn="?alias";
//	    			System.out.println("===================="+ls_patrn);
	    			break;
	    			
	    		default :
	    			LOG.info("DEFAULT CASE STMT OF ls_patrn");	
	    			break;
	    	}//switch
		
	    	//To handle an Application launched in a New Popup with independent URL from parent window
	    	switch(ls_URLtype)
	    	{	    
		    	//below case added by shan 06-06-18
	    		case "PegaODM_DocumentLink":
	    			String ls_ODMUrl1 = WTM_PegaODM_URL;
	    			if (Browser.equalsIgnoreCase("FireFox"))
	    			{
	    			ls_searchtitle = ls_ODMUrl1+ls_patrn;
	    			}
	    			else
	    			{
	    			ls_searchtitle = ls_ODMUrl1+ls_patrn1;
	    			}
	    			break;
	    			
	    			//below case added by shan 11-06-18
	    		case "PegaODM_DocLink":
	    			String ls_ODMUrl2 = WTM_PegaODM_URL;

	    			ls_searchtitle = ls_ODMUrl2+ls_patrn;

	    			break;
	    			//below case added by shanmugakumar 11-01-18
	    		case "ODM_DocumentLink":
	    			String ls_AppUrl = WTM_APP_URL;
	    			ls_AppUrl = ls_AppUrl.replaceAll("wccmain","");
	    			ls_searchtitle = ls_AppUrl+ls_patrn; // Need update
	    			break;
	    			
	    		case "ODM_MySavedSearch":
	    			ls_searchtitle = WTM_APP_URL+ls_patrn;
	    			break;
	    			//below case added by shanmugakumar 29-01-18	
	    		case "CMS_IssueChequeLetter":
	    			String ls_Environment = WTM_APP_URL.substring(17, 18);
//	    		    System.out.println(ls_Environment);
	    		    int li_Environment = Integer.parseInt(ls_Environment);
	    			ls_searchtitle = "http://svc-itp-it"+li_Environment+".qbe.eo/itp/app/ClaimCenter/runmodel.aspx"; 
	    			break;

			case "ODM_CreateAliasLink": //This case added by Moorthy on 05/07/2018
	    			String ls_AppUrl1 = WTM_APP_URL;
	    			ls_AppUrl1 = WTM_APP_URL.replaceAll("wccmain","wccdoc");
	    			ls_searchtitle = ls_AppUrl1+ls_patrn; 
//	    			System.out.println("===================="+ls_searchtitle);
	    			break;

	    			
	    		case "Calender" :
	    			ls_searchtitle = WTM_APP_URL+ls_patrn;
	    			break;
          
	    		case "NewCalender":
	    			ls_searchtitle = WTM_APP_URL+ls_patrn;
	    			break;
	    			
	    		case "ClaimWrite":
	    			ls_searchtitle=WTM_APP_URL +ls_patrn;
	    			break;
           
	    		case "ReLaunchClaimWrite": 
	    			ls_searchtitle=WTM_APP_URL +ls_patrn;
	    			break;
          
	    		case "PolicyEndorse":
	    			ls_searchtitle = WTM_APP_URL+ls_patrn;
	    			break;
          
	    		case "TPOSBenefits":
	    			ls_searchtitle = WTM_APP_URL+ls_patrn;
	    			break;
	          
	    		case "PrintCurrencyCertificate":
	    			ls_searchtitle = WTM_APP_URL+ls_patrn;
	    			break;
          
	    		case "PolicyRenewal":
	    			ls_searchtitle = WTM_APP_URL+ls_patrn;
	    			break;
          
	    		case "FileNotes":
	    			ls_searchtitle = WTM_APP_URL+ls_patrn;
	    			break;
          
	    		case "TPOSViewPolicy":
	    			ls_searchtitle = WTM_APP_URL+ls_patrn;
	    			break;
          
	    		case "AdvanceFilters":
	    			ls_searchtitle = WTM_APP_URL+ls_patrn;
	    			break;
          
	    		case "TPOSTermofuse":
	    			ls_searchtitle = WTM_APP_URL+ls_patrn;
	    			break;
			  
	    		case "PolicyCancel":
	    			ls_searchtitle = WTM_APP_URL+ls_patrn;
	    			break;
          
	    		case "AdvanceFilters_QUW":
	    			ls_searchtitle = WTM_APP_URL+ls_patrn;
	    			break;
          
	    		case "StartNewProcess":
	    			ls_searchtitle =WTM_APP_URL+ls_patrn;
	    			break;
		  
	    		case "Response" :
	    			ls_searchtitle = WTM_APP_URL+ls_patrn;
	    			break;
	    			
	    		case "TPOSProductDisclosure":
	    			ls_searchtitle =WTM_APP_URL+ls_patrn;
	    			break;
	    		
	    		case "IPortalGenius":
	    			ls_searchtitle =WTM_APP_URL+ls_patrn;
	    			break;

	    		case "HelpElders-IntranetLogon":
	    			//ls_searchtitle = WTM_APP_Help_URL +ls_patrn;
	    			break;
                  
	    		case "IWWiseReportingLogon":
	    			//ls_searchtitle = WTM_APP_Wise_URL+ls_patrn;*/
	    			break;
	    		case "QGlobal":
	    			ls_searchtitle =WTM_APP_URL+ls_patrn;
	    			break;
	    			
	    		default :
	    			LOG.info("DEFAULT CASE STMT OF ls_patrn");	
	    			break;
	    	}//switch of popups
	   
	    	// Search title
	    	
	    	//to Shift the control to Child Window
	    	GenericLibrary.shiftContrlToChildWindow(ScreenDriver.scr_driver);
	    	int  li_searchstringlen = ls_searchtitle.length();
    		//GenericLibrary.shiftContrlToChildWindow(popup_driver);
	    	//Mani-2
	    	//ScreenDriver.popup_driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    	
	    	//added by shanmugakumar N - 14 Feb 18
	    	ScreenDriver.popup_driver.manage().window().maximize();	 //maximize browser window
	    	
	    	ls_openurl=	ScreenDriver.popup_driver.getCurrentUrl();
		 	//System.out.println("===================="+ls_openurl);
		  	int li_browserurllen = ls_openurl.length();
		  	
		  	if  ( li_browserurllen >= li_searchstringlen)
		  		 ls_leftstring = ( ls_openurl.substring(0, li_searchstringlen));

		  	// Check if browser displayed is the same as the browser name passed in
			if (ls_openurl.contains(ls_searchtitle))	// Changes updated by shan - 06-06-18							
			{
				try
				{
	               String  hWND  =ScreenDriver.popup_driver.getWindowHandle();
				}catch(Exception e)
		    	{
		    		LOG.error("Unable to get the window handle  in GET POPUP OBJECTS Function");
		    	}//end of catch stmt
					
	             obj_harness.gb_browserpopup_exists=true;
					 
			}//if of open url
			
	    }catch(Exception e)
	     {
	    	LOG.error(" Exception in GET POP UP OBJECTS Function ");
	     }//END OF CATCH

//	    if(ls_openurl!=null)
	    if(ls_openurl.contains(ls_searchtitle)) // Changes updated by shan - 06-06-18
	    {
	    	ls_Msg="THe popup Url is captured";
	    	ls_status="Pass";
	    }
	    else
	    {
	    	ls_Msg="NOT ABLE TO GET THE POPUP URL";
	    	ls_status="Warning"; // updated by shanmugakumar - 11-Jan-18
	    }//else
	    if(report_type.equals("DETAIL"))
		{
			//for Excl DETAIL reporting
			report_data.add(ls_Functionname);
			report_data.add("");
			report_data.add("");
			report_data.add("");
			report_data.add(ls_Msg);
			report_data.add(ls_status);
			obj_Generic.Report(report_file,report_data );
		}//if of report
	    //VALIDATION
//    	Assert.assertNotNull(ls_openurl, "NOT ABLE TO GET THE POPUP URL");
	    return ScreenDriver.popup_driver;
	
	}

	private int parseint(String substring) {
		// TODO Auto-generated method stub
		return 0;
	}//method end 
	

}//class end 