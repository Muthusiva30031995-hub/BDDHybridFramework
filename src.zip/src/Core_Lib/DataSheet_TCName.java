package Core_Lib;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.google.common.collect.ArrayListMultimap;
//To read the Execution Sheet to get the list of Test case name,browser,row no of the each Test case

public class DataSheet_TCName
{
	
	 public static List<String> TestId = new ArrayList<String>();
	 public static Map<String, String> TC_Browser = new LinkedHashMap<String, String>();
	 public static  ArrayListMultimap<String, Integer> TC_Row = ArrayListMultimap.create();
	 
	public static void Get_TCName(String DataSheetPath) 
	{
		    	Workbook workbook;
		    	Sheet InputSheet, ExpectedOutputSheet;
		    	int i, li_RC;
		        String ls_TestId_Input, ls_Flag_Input, ls_TestId_Expected, ls_Flag_Expected, ls_FlagExp,ls_Browser;
		        Row currentRowIP, currentRowOP;
		        boolean bln_TestidCheck = false;
		        
		        try
		        {
		        	 //Added by Ambika on 12/1/2018 to validate file exist or not
		            File_Exists obj_file = new File_Exists();
		            obj_file.FILE_EXISTS(DataSheetPath);
		        	
		            FileInputStream excelFile = new FileInputStream(new File(DataSheetPath));
		            
		            if (DataSheetPath.endsWith("xlsx"))
		            {
		                workbook = new XSSFWorkbook(excelFile);
		            } 
		            else if (DataSheetPath.endsWith("xls")) 
		            {
		                workbook = new HSSFWorkbook(excelFile);
		            } 
		            else
		            {
		                throw new IllegalArgumentException("The specified file is not Excel file");
		            }

		            InputSheet = workbook.getSheetAt(0);
		           // ExpectedOutputSheet = workbook.getSheetAt(1);
		            
		            li_RC = InputSheet.getLastRowNum();
		          
		            for(i = 1 ; i <= li_RC ; i++)
		            {            	
		            	currentRowIP = InputSheet.getRow(i);
		            	//currentRowOP = ExpectedOutputSheet.getRow(i);

		            	ls_TestId_Input = currentRowIP.getCell(0).getStringCellValue();
		            	ls_Flag_Input = currentRowIP.getCell(1).getStringCellValue();
		            	ls_Browser= currentRowIP.getCell(4).getStringCellValue();
		            	
		            	
		            	ls_FlagExp = "Y";
		            	 
		            	//To get the TC_Name with flag Y
		            		if((ls_Flag_Input.equals(ls_FlagExp)))
		            		{
		            			//the map added by ambika to get the Browser name from the execution sheet  according to 
		            			TC_Browser.put(ls_TestId_Input,ls_Browser);
		            			//String row = Integer.toString(i);
		            			
		            			//To Store the row no of the TC
		            			TC_Row.put(ls_TestId_Input, i);
		            			
		            			//to store the TC_Name
		            			TestId.add(ls_TestId_Input);
		            			
		            		}
		            	
		            }//for loop
		            
		            excelFile.close();   
		        } 
		        catch (FileNotFoundException e) 
		        {
		        	//System.out.println("Exception in Datasheet_TCName");
		        } 
		        catch (IOException e) 
		        {
		        	//System.out.println("Exception in Datasheet_TCName");
		        }
		        catch (NullPointerException e) 
		        {
		        	//System.out.println("Exception in Datasheet_TCName");
		        } 
		       
		    

	}

}
