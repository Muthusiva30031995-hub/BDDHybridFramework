package Core_Lib;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class UpdateReport_With_TC_Number 
{
       
	public void readExcel(String filePath) throws IOException   
	{
				
		File folder = new File(filePath);
				
		File[] listOfFiles = folder.listFiles();
		
//		System.out.println(listOfFiles.length);
		
		for (int ifile = 0; ifile < listOfFiles.length; ifile++) // first for loop start
		{
			if (listOfFiles[ifile].isFile()) // first if start
			{
				String fileName = listOfFiles[ifile].getName();
				
				//Create an object of File class to open xlsx file
				File file = new File(filePath+"\\"+fileName);
						
				//Create an object of FileInputStream class to read excel file
				FileInputStream inputStream = new FileInputStream(file);
						
				Workbook Workbook = null;
						
				//Find the file extension by splitting file name in substring  and getting only extension name
				String fileExtensionName = fileName.substring(fileName.indexOf("."));
						
				//Extension Check
				if(fileExtensionName.equals(".xlsx"))
				{
					Workbook = new XSSFWorkbook(inputStream); // object of XSSFWorkbook class -> .xlsx
				}	
				else if(fileExtensionName.equals(".xls"))
				{
				Workbook = new HSSFWorkbook(inputStream); //object of XSSFWorkbook class -> .xls
				}
					
				String TC_NAME = "",TC_NAME_ALL="";
				int iFlagval = 1;
//				System.out.println(Workbook.getNumberOfSheets());
				
				//for each sheet in the workbook
				int li_NumberOfSheets = Workbook.getNumberOfSheets();
				int sheetNum; 
				
				try
				{
					for (sheetNum = 0;sheetNum < li_NumberOfSheets; sheetNum++) // second For Loop Start
					{
						String Sheetname = Workbook.getSheetName(sheetNum);
						//Read sheet inside the workbook by its name
						Sheet Sheet = Workbook.getSheet(Sheetname);
									    
						//Find number of rows in excel file
						int rowCount = Sheet.getLastRowNum()-Sheet.getFirstRowNum();
						int iCount=0,iterationcount = 0;
						int rowStart;
								
						//To find Testcase count
						for( rowStart = 1; rowStart<=rowCount;rowStart++)
						{
							try
							{
								Row row = Sheet.getRow(rowStart);
								String cellval = row.getCell(0).getStringCellValue();
											       
								if(cellval.contains("_TD"))
								{
									iterationcount = iterationcount + 1;
								}
							}
							catch(NullPointerException e)
							{
								break;
							}
						}
						//System.out.println("Iteartion Count : " + String.valueOf(iterationcount));
									    
						if(iterationcount > 0)
						{
							//Create a loop over all the rows of excel file to read it
							for(rowStart = 1; rowStart<=iterationcount;rowStart++)
							{
								try
								{
									Row row = Sheet.getRow(rowStart);
									String cellval = row.getCell(1).getStringCellValue();
													 	       
									if(cellval.equalsIgnoreCase("Pass"))
									{
										iCount = iCount + 1;
									}
								}
								catch(NullPointerException e)
								{
								
								}
							}
						//System.out.println("Pass Count : " + String.valueOf(iCount));
						} // End If  -> if(iterationcount > 0)
								    
						if(iCount > 0)
						{
							int first = Sheetname.indexOf("_");
							int second = Sheetname.indexOf("_", first + 1);
										    	
							String str = Sheetname.substring(0, first);
										    	
							if(str.length()>2)
							{
								TC_NAME = Sheetname.substring(0, first);
							}
							else
							{
								TC_NAME = Sheetname.substring(0, second);
							}
													
							if(iFlagval == 1)
							{
								TC_NAME_ALL = TC_NAME;
								iFlagval = 2;
							}
							else
							{
								TC_NAME_ALL = TC_NAME_ALL+"##"+TC_NAME;
							}
						}
						else
						{
							System.out.println(Sheetname);
							
							Workbook.removeSheetAt(sheetNum); // In-progress
							sheetNum = sheetNum -1;
							li_NumberOfSheets = li_NumberOfSheets - 1;
							
						}  // End IF -> if(iCount > 0)
					}// End second For Loop
				}
				catch(Exception e)
				{
					System.out.println(e.toString());
				}
//				System.out.println("Test Case Name : " +TC_NAME_ALL);
				Workbook.close();
				
				String ls_TC_ALL_Name = TC_NAME_ALL+fileExtensionName;
				
				File newFile = new File(filePath+"\\"+ls_TC_ALL_Name);
				
				//Rename file Name or delete File
				if(!TC_NAME_ALL.equals(""))
				{
					System.out.println(TC_NAME_ALL);
					file.renameTo(newFile);
				}
				else
				{
					System.out.println(fileName);
					file.delete();
				}
			}  // First If close
		} // First For Loop Close
	} // method close

	//Main function is calling readExcel function to read data from excel file
	public static void main(String[] args) throws IOException
	{
		String filePath = "C:/BAU_SELENIUM_AUTOMATION/Automation_Project/src/ODM/Report";
				
		UpdateReport_With_TC_Number obj = new UpdateReport_With_TC_Number();
		obj.readExcel(filePath);
	}
}