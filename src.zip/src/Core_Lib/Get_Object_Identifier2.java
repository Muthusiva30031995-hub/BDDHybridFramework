package Core_Lib;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.google.common.base.Predicate;

import Core_Lib.GenericLibrary;
import config.defs;


/*This class checks the object with the associated Properties exists in the Object Repository*/ 
public class Get_Object_Identifier2 
{
	
	public static String  webelement_type;
	public static String  locator_value=null;
	boolean lb_file = false;
	WebDriverWait wait;
	
	public WebElement GET_OBJECT_IDENTIFIER(WebDriver obj_driver ,String object_name,String ls_value,String optional_ERR_FLAG) 
	{
		//LOGGER
		Logger LOG = Logger.getLogger(Get_Object_Identifier2.class.getName());
		wait=new WebDriverWait(obj_driver,defs.explicitWait);
		
		//Detail Reporting
		 GenericLibrary obj_Generic = new GenericLibrary();
		 String report_file = Harness.report_testcase;
		 List<String> report_data = new ArrayList<String>();
		 String report_type=Harness.ls_ReportingType;
		 String ls_Functionname="GET_OBJECT_IDENTIFIER";
		 String ls_Msg=null;
		 String ls_status=null;
		
		List<String> arraylst = new ArrayList<String>();
		List<String> key_lst = new ArrayList<String>();
		List<String> value_lst = new ArrayList<String>();
		List<String> arraylst1 = new ArrayList<String>();
		
		String ls_object_value = null;
		String locator=null;
		String[] equals_array=null;
		String[] first_spilit_array=null;
		
		WebElement element=null;
		//WebDriver popup_driver=null;
		
		String currDir = System.getProperty("user.dir");
		String applicationName_underRun=defs.getApplicationName();
		String FilePath = currDir+"\\src\\objectRespository\\Object_Repository_"+ applicationName_underRun + ".xlsx";
		///Automation_Project/src/objectRespository/Object_Repository_AutomatedAssignment.xlsx
		
		File_Exists obj_file = new File_Exists();
		String gs_data_path=Harness.gs_data_path;
		
		// file path for Object repository
		String filepath =FilePath; 
		String sheetname = "Sheet1";
		Workbook ls_excel_book = null;
		String excel_objname = null;
		File ls_gui_object_file;
		FileInputStream ls_gui_object_file_open = null;
		boolean lb_objfound=false;	
		int wait_time=50;
		
		try
		{
			 lb_file= obj_file.FILE_EXISTS(filepath);
			 ls_gui_object_file = new File(filepath);
								 
			//Validation
			//Assert.assertTrue(lb_file, "Object Repository file is not found in Get_Object_Identifier Function");

				ls_gui_object_file_open = new FileInputStream(ls_gui_object_file);
			
				ls_excel_book = WorkbookFactory.create(ls_gui_object_file_open);
			
			Sheet ls_excel_sheet = ls_excel_book.getSheet(sheetname);
			int rowcount = ls_excel_sheet.getLastRowNum();

			for(int li_loop=1;li_loop<=rowcount;li_loop++)
			{
				excel_objname=GenericLibrary.getExcelData(filepath, ls_excel_sheet, li_loop, 0);
							
					if(object_name.trim().equals(excel_objname))
					{
						lb_objfound=true;
						ls_object_value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, li_loop, 1);
						//Mani
						String test="";				
						first_spilit_array =ls_object_value.split(";");
		
						for(int lst_loop=0;lst_loop<first_spilit_array.length;lst_loop++)								
						{
								arraylst.add(first_spilit_array[lst_loop]);
									
						}//for loop of array_lst
	
						//spilit using = and store it in an array list
						for(int loop=0;loop<arraylst.size();loop++)
						{
							equals_array=arraylst.get(loop).split("=");
									
							for(int lst_loop=0;lst_loop<=equals_array.length-1;lst_loop++)
							{
								arraylst1.add(equals_array[lst_loop]);
							}//for loop of lst_loop
		
						}//for loop of array_lst
	
						//Read the arraylist and make another two array list to store key and values	
						for(int loop=0;loop<arraylst1.size();loop++)
						{
							if(loop%2==0)
							{
								key_lst.add(arraylst1.get(loop));
							}else
	    					 {
								value_lst.add(arraylst1.get(loop));
				
	    					 }//else of array_lst1
			
						}// for loop of loop
			
						//from key list creating locator list for identify the locators
						for(int loop=0;loop<key_lst.size();loop++)
						{
							if(loop%2!=0)
							{
								locator = key_lst.get(loop);
							}//if of loop
						}//for of key_lst
			
						//the value list is again divided into two list as locator value list and webelement list to store locator value and the type of webelement
						for(int loop=0;loop<value_lst.size();loop++)
						{
							if(loop%2==0)
							{
								webelement_type = value_lst.get(loop);
							}else
							{
								locator_value = value_lst.get(loop);
							}//else of loop
				
						}//for of value_lst
						if(object_name.equals("GWCCExposures_M_Link")){
							String M = locator_value;
							System.out.println(M);
						}
				
				// switch statement customized by shanmugakumr - 22 Feb 18 
				By By_Locator = null;
				try
				{
					switch(locator)
					{
						case "html id":	
							By_Locator = By.id(locator_value);
							break;
						
						case"name":
							By_Locator = By.name(locator_value);
							break;
											
						case "html tag":
							By_Locator = By.tagName(locator_value);
							break;
						
						case "text":
							By_Locator = By.linkText(locator_value);
							break;
						case "Partialtext":
							By_Locator = By.partialLinkText(locator_value);
							break;
						
						case "class":
							By_Locator = By.className(locator_value);				
							break;
													
						case "xpath":
							if (object_name.equals("GWCCDwellingIncident_NoofStories_Text")) {
								//Muthu-Thread.sleep(1000);
							}
							else if(object_name.equals("GWCCPartiesInvolved_Users_value")){
								//locator_value=locator_value + "'"+ls_value+"'"+"]";
								
							}
							locator_value=locator_value.replace("*", "=");
											
							/*if(webelement_type.equals("WebRadioGroup"))
							{
								locator_value=locator_value+"'"+ls_value+"']";
							}//if of webelement type
*/							System.out.println("Object XPATH - " + locator_value);
							By_Locator = By.xpath(locator_value);												
							break;
					
					}// switch of locator
				}
				catch(Exception e)
				{
					ls_Msg="Unable to form locator";
					ls_status="Fail";
				}
				try
				{
				//Added by Ambika to check the Object is Exist or Not 
				if(optional_ERR_FLAG.equalsIgnoreCase("NotExist"))
				{
					System.out.println("Object NOT Exists - " + locator + " by locator - " + locator_value);
					return null;
				}
				else
				{
					System.out.println("Object Exists - " + locator + " by locator - " + locator_value);
				}
				}
				catch(Exception e)
				{
					System.out.println("Exception is Object Finding - " + locator + " by locator - " + locator_value);
					System.out.println("Exceptions");
				}
				
				// below statements using to wait maximum 30 seconds to identify the expected object  by shanmugakumr - 17-05-18 
				for(int i=1;i<=1;i++)
				{
					try
					{
						System.out.println("Checking the Page Status - " + pageStatus(obj_driver));
						if(!pageStatus(obj_driver))
						{
							System.out.println("Waiting for the Page Load");
							wait.until( new Predicate<WebDriver>() 
							{
			                 public boolean apply(WebDriver obj_driver) {
			                     return ((JavascriptExecutor)obj_driver).executeScript("return document.readyState").equals("complete");
			                 }});
						}
							////Muthu-Thread.sleep(1000);
							System.out.println("Waiting for the Element");
							WebElement a=wait.until(ExpectedConditions.presenceOfElementLocated(By_Locator));
							WebElement b=wait.until(ExpectedConditions.visibilityOfElementLocated(By_Locator));
							
							//Mani
							//Muthu-Thread.sleep(defs.beforeObjectLoadTime);
							System.out.println("Found the Element");
							element = obj_driver.findElement(By_Locator);
							//Muthu-Thread.sleep(defs.afterObjectLoadTime);
					if(!b.isDisplayed())
					{
							((JavascriptExecutor) obj_driver).executeScript("arguments[0].scrollIntoView(true);", a);
					}	 
							
							
							if((element!=null)||(ls_value.equalsIgnoreCase("clickhandle")))
							 {
								break;
							 }	
					}
					catch(Exception e)
					{
						ls_Msg="Unable to create element  Object using "+locator;
						ls_status="Fail";
					}
				}
				
				if(element!=null||ls_value.equalsIgnoreCase("clickhandle"))
				 {
					ls_Msg="The Object identified Successfully";
					ls_status="Pass";
				 }	
				else
				 {
					ls_Msg="Unable to identify the  Object using "+locator;
					ls_status="Fail";
				 }
			break;	
			
		
		}//IF OF OBJECT NAME
					else
					{
						ls_Msg="The Object Not Found in Object Repository";
					 	ls_status="Fail";
					}
					
					}//end of for loop
			
			
			} catch (FileNotFoundException e1) {
		LOG.error("FileNotFoundException of fileinputStream in Get_Object_Identifier");	
	} catch (EncryptedDocumentException e1) {
		LOG.error("EncryptedDocumentException of WorkbookFactory in Get_Object_Identifier");
	} catch (InvalidFormatException e1) {
		LOG.error("InvalidFormatException of WorkbookFactory in Get_Object_Identifier");
	} catch (IOException e1) {
		LOG.error("IOException of WorkbookFactory in Get_Object_Identifier");
	}//catch

finally
{
	
	try 
	{
		ls_gui_object_file_open.close();
	}
	catch (IOException e)
	{
			LOG.error("IOException OF Closing file in  Get_Object_Identifier");

	}
}//finally
		 
			 if(report_type.equals("DETAIL")&&ls_status.equals("Fail"))
			 {
				//reporting
				report_data.add(ls_Functionname);
				report_data.add(object_name);
				report_data.add("");
				report_data.add("");
				report_data.add(ls_Msg);
				report_data.add(ls_status);
				obj_Generic.Report(report_file,report_data );
				
		 }//if of reporting
		 
			//VALIDATION
			/*Assert.assertTrue(lb_objfound, object_name+" is not found in ObjectRepository");
			//VALIDATION
			Assert.assertNotNull(element, "Unable to Identify the Object in ObjectRepository");*/
			return element;
}//end of method
		
	public boolean pageStatus(WebDriver scr_driver) {
        return ((JavascriptExecutor)scr_driver).executeScript("return document.readyState").equals("complete");
	}
}//class end
