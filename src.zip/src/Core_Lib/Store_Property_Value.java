package Core_Lib;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ddf.EscherColorRef.SysIndexSource;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
// This function stores the property values by loading it into the Dictionary object.
// It Calls the GET_PROPERTY_VALUE function to get the property value of the object which needs to be stored.
// It also calls the STORE_VALUE function to store the value in the dictionary object

public class Store_Property_Value
{
	
	public void  STORE_PROPERTY_VALUE(WebDriver driver_store,String  ls_ObjectName,String  ls_Property,String ls_var,String  optional_ERR_FLAG)
	{          
		//LOGGER
		Logger LOG = Logger.getLogger(Get_Property_Value.class.getName());
		
		GenericLibrary genlib = new GenericLibrary();
		
	     String GetPropValue = null;
	     String[]  startpos;
	     String[] endpos;
	     
	     Store_Value_Variable store= new Store_Value_Variable();//Added by suman, to store values in StoredNum.txt file
	     Get_Property_Value ls_obj = new Get_Property_Value();
	     Store_Value ls_obj_store = new Store_Value();
	     String datapath = Harness.ls_TestdatasheetPath;;
	     String sheet = "RuntimeValues";
	     String dataTowrite = null;
	     int rownum = 0;
	     
	     
	          	               
	    //Call the GET_PROPERTY_VALUE function to get the property value of the object which needs to be stored
	     try
	     {
	    	 GetPropValue = ls_obj.GET_PROPERTY_VALUE(driver_store, ls_ObjectName,  ls_var ,ls_Property, optional_ERR_FLAG);
	     }catch(Exception e)
			{
				LOG.error("Unable to get the property value in Store_Property_value Function");

			}//CATCH
	     
	     //VALIDATION
	     Assert.assertNotNull(GetPropValue, "The property values is null in Store_Property_Value Function");
	    
	    try
	    {
	      if (!GetPropValue.trim().equals(""))
	      {
	            if (ls_Property.equals("DiscPercnt"))
	            	GetPropValue=GetPropValue.substring(0, 2);//15.00- will changed to 15
	            
	            switch (ls_Property)
	            {
	               				   
	               case "policynum":
	            	      GetPropValue=GetPropValue.trim();
		            	  LOG.info("The policy num is"+GetPropValue);
		            	 //Added by suman
		            	  store.STORE_VALUE_VARIABLE(ls_ObjectName,GetPropValue,ls_Property);
					   break;
	               case "city":
	            	      GetPropValue=GetPropValue.trim();
		            	  LOG.info("The policy num is"+GetPropValue);
		            	 //Added by suman
		            	  store.STORE_VALUE_VARIABLE(ls_ObjectName,GetPropValue,ls_Property);
					   break;
					   
	               case "PolicyNo":
	            	      GetPropValue=GetPropValue.trim();
		            	  LOG.info("The policy num is"+GetPropValue);
		            	 //Added by suman
		            	  GetPropValue= GetPropValue.replace("Quote #: ","");
		            	  store.STORE_VALUE_VARIABLE(ls_ObjectName,GetPropValue,ls_Property);
					   break;
	               case "PolicyNumber":
	            	      GetPropValue=GetPropValue.trim();
		            	  LOG.info("The policy num is"+GetPropValue);
		            	 //Added by suman
		            	  GetPropValue= GetPropValue.replace("Claim (","");
		            	  GetPropValue= GetPropValue.replace(")","");
		            	//  store.STORE_VALUE_VARIABLE(ls_ObjectName,GetPropValue,ls_Property);
					   break;
	               case "ClaimNoSymb":
	            	      GetPropValue=GetPropValue.trim();
		            	  LOG.info("The ClaimNoSymb num is"+GetPropValue);
		            	 //Added by suman
		            	  
		            	  store.STORE_VALUE_VARIABLE(ls_ObjectName,GetPropValue,ls_Property);
					   break;
					   
	               case "SendDeskAdj":
	            	      GetPropValue=GetPropValue.trim();
		            	  LOG.info("The SendDeskAdj num is"+GetPropValue);
		            	 //Added by suman
		            	  
		            	  store.STORE_VALUE_VARIABLE(ls_ObjectName,GetPropValue,ls_Property);
					   break;
					   
	               case "SymSendStatus":
	            	      GetPropValue=GetPropValue.trim();
		            	  LOG.info("The SymSendStatus num is"+GetPropValue);
		            	 //Added by suman
		            	  
		            	  store.STORE_VALUE_VARIABLE(ls_ObjectName,GetPropValue,ls_Property);
					   break;
	               case "DeskAdj":
	            	      GetPropValue=GetPropValue.trim();
		            	  LOG.info("The DeskAdj is"+GetPropValue);
		            	 //Added by suman
		            	 // GetPropValue= GetPropValue.replace("Claim (","");
		            	//  GetPropValue= GetPropValue.replace(")","");
		            	  store.STORE_VALUE_VARIABLE(ls_ObjectName,GetPropValue,ls_Property);
					   break;
	               case "QuotationNum":
	            	      GetPropValue=GetPropValue.trim();
		            	  LOG.info("The Quotation num is"+GetPropValue);
		            	  store.STORE_VALUE_VARIABLE(ls_ObjectName,GetPropValue,ls_Property);
					   break;   
					   
	               case "ClaimNo":
	            	      GetPropValue=GetPropValue.trim();
		            	  LOG.info("The claim num is"+GetPropValue);
		            	 //Added by suman
		            	  store.STORE_VALUE_VARIABLE(ls_ObjectName,GetPropValue,ls_Property);
					   break;
	               case "ClaimSegment":
	            	      GetPropValue=GetPropValue.trim();
		            	  LOG.info("The claim num is"+GetPropValue);
		            	 //Added by suman
		            	  store.STORE_VALUE_VARIABLE(ls_ObjectName,GetPropValue,ls_Property);
					   break;
	               case "Adjuster":
	            	      GetPropValue=GetPropValue.trim();
		            	  LOG.info("The claim num is"+GetPropValue);
		            	 //Added by suman
		            	  store.STORE_VALUE_VARIABLE(ls_ObjectName,GetPropValue,ls_Property);
					   break;
	               case "TposAmendpolicyNum":
	            	   startpos=GetPropValue.split("Your New Policy No is ");
					   endpos=startpos[1].split("//.");
			           GetPropValue=endpos[0].trim();
					   break;
					default:
						break;
	            }//SWITCH
	            
	            
	            dataTowrite = GetPropValue;
	            
	       //To load the variable into the dictionary
	            
	            //Getting the now num value from below try block
	            Return_Rownum row_num = new Return_Rownum();
	            try
	            {
	            	//calling Return_rownum_Datasheet for rownumber
	            	rownum = row_num.Return_rownum_Datasheet();
	            	 
	            }catch(Exception e)
	            {
	            	LOG.error("EXCEPTION IN GETTING ROWNUM VALUE OF TESTCASE");
	            }//CATCH
	       
	      switch(ls_Property)
	      {
	         case "policynum":
	        	 //calling GenericLibrary writeToExcel to write policy num to Datasheet
	        	 genlib.writeDataTOExcel(datapath, sheet, rownum, 1, dataTowrite);
	        	 break;
	         case "PolicyNumber":
	        	 //calling GenericLibrary writeToExcel to write policy num to Datasheet
	        	 genlib.writeDataTOExcel(datapath, sheet, rownum, 2, dataTowrite);
	        	 break;
	         case "ClaimNo":
	        	 //calling GenericLibrary writeToExcel to write policy num to Datasheet
	        	 genlib.writeDataTOExcel(datapath, sheet, rownum, 1, dataTowrite);
	        	 break;
	         case "ClaimSegment":
	        	 //calling GenericLibrary writeToExcel to write policy num to Datasheet
	        	 genlib.writeDataTOExcel(datapath, sheet, rownum, 1, dataTowrite);
	        	 break;
	         case "Adjuster":
	        	 //calling GenericLibrary writeToExcel to write policy num to Datasheet
	        	 genlib.writeDataTOExcel(datapath, sheet, rownum, 2, dataTowrite);
	        	  
	        	 break;
	         case "DeskAdj":
	        	 //calling GenericLibrary writeToExcel to write policy num to Datasheet
	        	 genlib.writeDataTOExcel(datapath, sheet, rownum, 3, dataTowrite);
	        	  
	        	 break;
	         case "ClaimNoSymb":
	        	 //calling GenericLibrary writeToExcel to write policy num to Datasheet
	        	 genlib.writeDataTOExcel(datapath, sheet, rownum, 4, dataTowrite);
	        	  
	        	 break;	 
	         case "SendDeskAdj":
	        	 //calling GenericLibrary writeToExcel to write policy num to Datasheet
	        	 genlib.writeDataTOExcel(datapath, sheet, rownum, 5, dataTowrite);
	        	  
	        	 break;
	         case "SymSendStatus":
	        	 //calling GenericLibrary writeToExcel to write policy num to Datasheet
	        	 genlib.writeDataTOExcel(datapath, sheet, rownum, 6, dataTowrite);
	        	  
	        	 break;
	         case "city":
	        	 //calling GenericLibrary writeToExcel to write policy num to Datasheet
	        	 genlib.writeDataTOExcel(datapath, sheet, rownum, 3, dataTowrite);
	        	  
	        	 break;
	        	 	 
	         case "PolicyNo":
	        	 //calling GenericLibrary writeToExcel to write policy num to Datasheet
	        	 genlib.writeDataTOExcel(datapath, sheet, rownum, 1, dataTowrite);
	        	  
	        	 break;	 
	        	 
	         case "QuotationNum" :  
	        	//calling GenericLibrary writeToExcel to write policy num to Datasheet
	        	 genlib.writeDataTOExcel(datapath, sheet, rownum, 2, dataTowrite);
	        	// store the claim number displayed in the claim center application
	        	 //Call gfn_get_ClaimNumber(sObjectName,sVar)
	        	 break;
	        	 
	         case "PolicyString" :
	        	 //to store the table text string from Mainframe screen and retrieve the Policy Number
	        	//Call gfn_Retrieve_PolicyNumberfromMFTable(sObjectName,sVar)
	        	 break;
	        	 
	         case"Incepdate":
	        	 //This code to get the date in mainframe format (DDMMYYYY)
	        	// ls_incepdate=variablevalues.get(ls_Var);
	        	// call FORMAT_DATE(ls_incepdate,"DD|MM|YYYY",ls_Inceptiondate, optional_ERR_FLAG)
	        	 break;
	        	 
	         case "Expdate" :
	        	  //this code is used to get the date in mainframe format (DDMMYYYY)
	        	  //ls_expdate=variablevalues.get(ls_Var);
	        	  //call FORMAT_DATE(ls_expdate,"DD|MM|YYYY",ls_ExpiryDate, optional_ERR_FLAG)
	        	  break;
	        	  
	        	 
	      }//Switch of ls_var
	      
	      }//IF
	      
	   }catch(Exception e)
	     {
		   LOG.error("EXCEPTION OF STORE PROPERTY VALUE");
	     }//catch
	    
	    
}

	public boolean  STORE_PROPERTY_VALUE(WebDriver driver_store,String  ls_ObjectName,String  ls_Property,String ls_Var,String  optional_ERR_FLAG,String ls_variablestore)
	{          
		//LOGGER
		Logger LOG = Logger.getLogger(Get_Property_Value.class.getName());
		
	     String GetPropValue = null;
	     String[]  startpos;
	     String[] endpos;
	     
			//Reporting
			GenericLibrary obj_Generic = new GenericLibrary();
			String report_file = Harness.report_testcase;
			List<String> report_data = new ArrayList<String>();
			String report_type=Harness.ls_ReportingType;
			
			String ls_Msg,ls_FunctionName="STORE_PROPERTY_VALUE",ls_Status;	
			
	     Get_Property_Value ls_obj = new Get_Property_Value();
	     Store_Value ls_obj_store = new Store_Value();
	     Store_Value_Variable ls_obj_variable = new Store_Value_Variable();
          
	     boolean lb_Store_property = false;
	    //Call the GET_PROPERTY_VALUE function to get the property value of the object which needs to be stored
	  
	     GetPropValue = ls_obj.GET_PROPERTY_VALUE(driver_store, ls_ObjectName, ls_Property, ls_Var, optional_ERR_FLAG);
	     System.out.println("GetPropValue "+GetPropValue);
	     
	    if(!GetPropValue.equalsIgnoreCase("Obj Issue"))
		{
	    
	     lb_Store_property = true;
	     //writing into Execution sheet
	     String data_filepath = Harness.gs_data_path+"/ExecutionSheet.xlsx";
	     FileInputStream data_file;
		 Workbook data_wb = null;
		 FileOutputStream out_data;
	    	 
	     //VALIDATION
	     if(!GetPropValue.trim().equals(""))
	     {
	    	 switch (ls_Property)
	            {
	            	case "DiscPercnt":
	            		GetPropValue=GetPropValue.substring(0, 2);//15.00- will changed to 15
	            		break;
	            		
	            	case "SplitCaseID":
	            		int starpos=GetPropValue.indexOf("RCS-");
	            		//below condition added by shan
	            		int posHas = GetPropValue.indexOf("has");
	            		GetPropValue=GetPropValue.substring(starpos, posHas-1);
	            		GetPropValue = GetPropValue.trim();
	            		break;
	            		
	            		
	            	case "PolNumber":
		            	 startpos=GetPropValue.split("Policy Documents: ");
		            	 GetPropValue =startpos[1].substring(0, 9);
						 break;
	            	
	               case "TposnewquoteNum":
	            	   startpos=GetPropValue.split("Your New Quote No is ");
					   endpos=startpos[1].split("\\.");
					   GetPropValue=endpos[0].trim();
					   break;
					   
	               case "TposnewpolicyNum":
	            	   startpos=GetPropValue.split("Your New Policy No is ");
		            	endpos=startpos[1].split("\\.");
		            	GetPropValue=endpos[0].trim();
					   break;
				// Changes need
	               case "quotenum":
	            	   startpos=GetPropValue.split("Quotation No is ");
		            	 endpos=startpos[1].split("\\.");
		            	 GetPropValue=endpos[0].trim();
					   break;
					   
	               case "policynum":
	            	   startpos=GetPropValue.split("Policy Number is ");
		            	  endpos=startpos[1].split("//.");
		            	  GetPropValue=endpos[0].trim();
					   break;
					      
	               case "TposAmendpolicyNum":
	            	   startpos=GetPropValue.split("Your New Policy No is ");
					   endpos=startpos[1].split("//.");
			           GetPropValue=endpos[0].trim();
					   break;
					   
					   
					 //Added by Ambika to store Document ID in the Execution Sheet on 1-06-2018   
	               case "DocumentID":
	            	  
	           			if(optional_ERR_FLAG.equalsIgnoreCase("Execution_Sheet"))
	           			{
		           			try {
		           					data_file = new FileInputStream(data_filepath);
		           					 data_wb = WorkbookFactory.create(data_file);
		           			} catch ( EncryptedDocumentException | InvalidFormatException | IOException e1) {
		           				
		           				e1.printStackTrace();
		           			}// try of data_file
		           			
		           			
		           			try {
		           				
								Sheet data_sheet = data_wb.getSheet("Input");
								int datarow_count = data_sheet.getLastRowNum();
								System.out.println(datarow_count);
								int i=0;
								for (String key : DataSheet_TCName.TC_Row.keySet()) 
						 		{
						 			if(key.equals(Harness.sheetname))
						 			{
						 				List<Integer> rowno = DataSheet_TCName.TC_Row.get(key);
						 				int li_rowno =(rowno.get(i));
						 				Row data_row = data_sheet.getRow(li_rowno);
						 				System.out.println(li_rowno);
						 				Cell data_cell = data_row.createCell(6);
										data_cell.setCellValue(GetPropValue);
										System.out.println(DataSheet_TCName.TC_Row);
						 				i++;
						 				 break;
						 			}else
						 			{
						 				
						 			}
						 				
						 		}// for of key
														
							} catch (EncryptedDocumentException e)
		           			{
								
							} //Catch of Sheet
		           			
		           			//to close the Execution Sheet
		           			try {
		           					           				
		           				//to close datasheet file
		           				out_data = new FileOutputStream(data_filepath);
		           				data_wb.write(out_data);
		           				out_data.close();
		           			} catch (IOException e) {
		           				// TODO Auto-generated catch block
		           				e.printStackTrace();
		           			}//try of closing Execution sheet
	           			}//if of optional_ERR_FLAG
	           			break;
	           		//Added by Ambika to store Document ID in the Execution Sheet on 1-06-2018 	
	               case "CaseID":
		            	 
	            	   if(optional_ERR_FLAG.equalsIgnoreCase("Execution_Sheet"))
	           			{
		           			try {
		           					data_file = new FileInputStream(data_filepath);
		           					 data_wb = WorkbookFactory.create(data_file);
		           			} catch ( EncryptedDocumentException | InvalidFormatException | IOException e1) {
		           				
		           				e1.printStackTrace();
		           			}// try of data_file
		           			
		           			
		           			try {
		           				
								Sheet data_sheet = data_wb.getSheet("Input");
								int datarow_count = data_sheet.getLastRowNum();
								System.out.println(datarow_count);
								int i=0;
								for (String key : DataSheet_TCName.TC_Row.keySet()) 
						 		{
						 			if(key.equals(Harness.sheetname))
						 			{
						 				List<Integer> rowno = DataSheet_TCName.TC_Row.get(key);
						 				int li_rowno =(rowno.get(i));
						 				Row data_row = data_sheet.getRow(li_rowno);
						 				System.out.println(li_rowno);
						 				Cell data_cell = data_row.createCell(5);
										data_cell.setCellValue(GetPropValue);
										System.out.println(DataSheet_TCName.TC_Row);
						 				i++;
						 				 break;
						 			}else
						 			{
						 				
						 			}
						 				
						 		}// for of key
														
							} catch (EncryptedDocumentException e)
		           			{
								
							} //Catch of Sheet
		           			
		           			//to close the Execution Sheet
		           			try {
		           					           				
		           				//to close datasheet file
		           				out_data = new FileOutputStream(data_filepath);
		           				data_wb.write(out_data);
		           				out_data.close();
		           			} catch (IOException e) {
		           				// TODO Auto-generated catch block
		           				e.printStackTrace();
		           			}//try of closing Execution sheet
	           			}//if of optional_ERR_FLAG
		           			break;
					   
					default:
						
			            	 GetPropValue =GetPropValue;
							break;
	            }//SWITCH

		    	 ls_Msg = "The Property - "+ls_Property+" : contains the value - "+GetPropValue;
		    	 LOG.info(ls_Msg);
		    	 ls_Status = "Pass";
		    	 
		    	 try // added by shan - 28-May-18
		    	 {
			    	 if(ls_variablestore.equalsIgnoreCase("Y")) 
			    	 {
			    		 ls_obj_variable.STORE_VALUE_VARIABLE(ls_ObjectName, GetPropValue, ls_Var); 
			    	 }
			       //To load the variable into the dictionary
		    	 }
		    	 catch(NullPointerException e)
		    	 {
		    		 System.out.println(ls_variablestore);
		    	 }
			    ls_obj_store.STORE_VALUE(ls_ObjectName,GetPropValue,ls_Var);
	     }
	     else
	     {
	    	 ls_Msg = "Unable to get the property value in Store_Property_value Function";
	    	 LOG.error(ls_Msg);
	    	 ls_Status = "Fail";
//	    	 Assert.assertNotNull(GetPropValue, "The property values is null in Store_Property_Value Function");
	     }
	     
	     if(report_type.equals("DETAIL"))
			{
				//for Excel detail reporting
				report_data.add(ls_FunctionName);//Function Name
				report_data.add(ls_ObjectName);//object name
				report_data.add(GetPropValue);//Expected
				report_data.add("");//Actual
				report_data.add(ls_Msg);//Detail
				report_data.add(ls_Status);//Status
				obj_Generic.Report(report_file,report_data );
			}
		} // End if obj issue
	     
		return lb_Store_property;
}//method end 


}//class end