package Core_Lib;

import java.util.ArrayList;
import java.util.List;

//This function compares the two strings and returns TRUE or FALSE.  
public class Check_Value 
{

	public  boolean CHECK_VALUE(String ls_ActualVal,String ls_ExpectedVal, String Label_Name, String compulsory_flag)
	{
		//Reporting
		boolean blnFlag = false;
		
		if(Label_Name.contains("NagativeCheck")) // condition added by shanmugakumar for to check negative scenarios - 08 Feb 18
		{
			String lc_firstchar=ls_ExpectedVal.substring(0,1); // first character 
			
			if (lc_firstchar.equals("~"))
			{
				if (!ls_ActualVal.contains(ls_ExpectedVal.substring(1)))
	        	{
					blnFlag = true;
					
	        	}
			}
			else if (!ls_ActualVal.equals(ls_ExpectedVal))
	    	{
	    		//LOG.info("The -  Actual Value: " + ls_ActualVal + " is matched with - Expected Value: " + ls_ExpectedVal);
	            blnFlag = true;    
	    	}  
		}
		else if(Label_Name.contains("contains")) // condition added by shanmugakumar for to check negative scenarios - 08 Feb 18
		{
			//String lc_firstchar=ls_ExpectedVal.substring(0,1); // first character 
			
			 if (ls_ActualVal.trim().contains(ls_ExpectedVal.trim()))
	    	{
	    		System.out.println("The -  Actual Value: " + ls_ActualVal + "\n Matched with - Expected Value: \n" + ls_ExpectedVal);
	            blnFlag = true;    
	    	}  
		}
		else if(Label_Name.contains("innertext")) // condition added by shanmugakumar for to check negative scenarios - 08 Feb 18
		{
			//String lc_firstchar=ls_ExpectedVal.substring(0,1); // first character 
			
			 if (ls_ActualVal.trim().toLowerCase().contains(ls_ExpectedVal.trim().toLowerCase()))
	    	{
	    		System.out.println("The -  Actual Value: " + ls_ActualVal + "\n Matched with - Expected Value: \n" + ls_ExpectedVal);
	            blnFlag = true;    
	    	}  
		}
		else if(Label_Name.contains("equal")) // condition added by shanmugakumar for to check negative scenarios - 08 Feb 18
		{
			//String lc_firstchar=ls_ExpectedVal.substring(0,1); // first character 
			if(compulsory_flag.equalsIgnoreCase("Y"))
			{
				if (ls_ActualVal.trim().equals(ls_ExpectedVal.trim()))
		    	{
		    		System.out.println("The -  Actual Value: " + ls_ActualVal + "\n compulsory_flag match with - Expected Value: \n" + ls_ExpectedVal);
		            blnFlag = true;    
		    	}
			}else if(compulsory_flag.equalsIgnoreCase("N"))
			{
				if (ls_ActualVal.trim().equalsIgnoreCase(ls_ExpectedVal.trim()))
		    	{
		    		System.out.println("The -  Actual Value: " + ls_ActualVal + "\n no compulsory_flag match with - Expected Value: \n" + ls_ExpectedVal);
		            blnFlag = true;    
		    	}
			}
			else
			{
				if (ls_ActualVal.trim().contains(ls_ExpectedVal.trim()))
		    	{
		    		System.out.println("The -  Actual Value: " + ls_ActualVal + "\n contains with - Expected Value: \n" + ls_ExpectedVal);
		            blnFlag = true;    
		    	}
			}
			
			   
		}
		else
		{
			String lc_firstchar=ls_ExpectedVal.substring(0,1); // first character 
			if (lc_firstchar.equals("~"))
			{
				if (ls_ActualVal.contains(ls_ExpectedVal.substring(1)))
	        	{
					blnFlag = true;
					
	        	}
			}
			else if (ls_ActualVal.equals(ls_ExpectedVal))
	    	{
	    		//LOG.info("The -  Actual Value: " + ls_ActualVal + " is matched with - Expected Value: " + ls_ExpectedVal);
	            blnFlag = true;    
	    	}  
		}
     return blnFlag;                               
    }// Method Check-value

}//CLASS END 