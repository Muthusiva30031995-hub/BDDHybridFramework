package Core_Lib;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

//To click on Enter button in Genius application
public class DisplayProgramMessages_Close
{
	public static void DiplayProgram()
	{
		//LOGGER
		Logger LOG = Logger.getLogger(ScreenDriver.class.getName());
		
		//Detail Reporting
		 GenericLibrary obj_Generic = new GenericLibrary();
		 String report_file = Harness.report_testcase;
		 List<String> report_data = new ArrayList<String>();
		 String report_type=Harness.ls_ReportingType;
		 String ls_Functionname="DiplayProgram";
		 String ls_Msg=null;
		 String ls_status=null;
		 
		 WebDriver driver = ScreenDriver.scr_driver;
		 WebElement enter_btn = null;
		
		try
		{
			enter_btn = driver.findElement(By.xpath("//input[@value='Enter']"));
			if(!(enter_btn==null))
			{
				enter_btn.click();
				ls_Msg="Expected Field Clicked";
				ls_status="Pass";
			}else
			{
				ls_Msg="Enter button is not available";
				ls_status="Fail";
				LOG.error("Enter button is not available");
			}
		}catch(Exception e )
		{
			LOG.info("EXCEPTION OF FINDING ENTER BUTTON");
			ls_Msg="EXCEPTION OF FINDING ENTER BUTTON";
			ls_status="Fail";
		}//catch
		//reporting
		if(report_type.equals("DETAIL"))
		{
			//for Excl DETAIL reporting
			report_data.add(ls_Functionname);
			report_data.add("Enter Button");
			report_data.add("");
			report_data.add("");
			report_data.add(ls_Msg);
			report_data.add(ls_status);
			obj_Generic.Report(report_file,report_data );
		}//if of report
	}
}
