package Core_Lib;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

public class Document_Validation
{
	
	//LOGGER
			Logger LOG = Logger.getLogger(File_Exists.class.getName());
			//Detail Reporting
			 GenericLibrary obj_Generic = new GenericLibrary();
			 String report_file = Harness.report_testcase;
			 List<String> report_data = new ArrayList<String>();
			 String report_type=Harness.ls_ReportingType;
			 String ls_Functionname="FILE_EXISTS";
			  String ls_Msg=null;
			 String ls_status=null;

	public  void DOCUMENT_VALIDATION()
	
	{
		Harness obj_harness = new Harness();
		boolean exists=false;
		
		String ls_data_path = obj_harness.gs_data_path;
		String filepath=ls_data_path+"/CMS_UploadFile.xlsx";
		File ls_file = new File(filepath);
		//boolean ls_file = obj_file.FILE_EXISTS("C:\\BAU_SELENIUM_AUTOMATION\\Automation_Project\\src\\ODM_CMS\\Data_Lib\\CMS_EXCEL_STORE.vbs");
		
		   try 
		   {
		      Runtime.getRuntime().exec( "wscript.exe C:\\BAU_SELENIUM_AUTOMATION\\Automation_Project\\src\\ODM_CMS\\Data_Lib\\Runner.vbs");
		   }
		   catch( Exception e ) 
		   {
		    
		   }

		
		   try
			{
				// check if file exists
				exists = ls_file.exists(); 
				if (!exists) 
				  {
					ls_Msg="THE FILE DOES NOT EXISTS ";
					ls_status="Warning";
					//LOG.error("THE FILE DOES NOT EXISTS" +ls_FileName);
					
					
				  } // if end
				else
				{
					ls_Msg="THE FILE  EXISTS ";
					ls_status="Pass";
				}
				
			}catch(Exception e)
			{
				ls_Msg="File not found exception";
				ls_status="Warning";
				LOG.error("File not found excepton in File Exist class");
				
			}//END OF CATCH
			
			
				// check file existence
				if(report_type.equals("DETAIL"))
				{
					//for Excl DETAIL reporting
					report_data.add(ls_Functionname);
					report_data.add("");
					report_data.add("");
					report_data.add(filepath);
					report_data.add(ls_Msg);
					report_data.add(ls_status);
					obj_Generic.Report(report_file,report_data );
					
				}//if of report
			
		
		/*//check the file will be saved in the particular location
		File_Exists obj_file = new File_Exists();
		obj_file.FILE_EXISTS(filepath);
		*/
		
	}

}
