package Core_Lib;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;


public class Wait_For 
{
	static WebDriver wait_driver = Browser_Invoke_Url.driver;
	
	public void wait_for(String  li_value,String optional_error_flag )
	{
		//LOGGER
		Logger LOG = Logger.getLogger(Wait_For.class.getName());
		
		//Reporting
		GenericLibrary obj_Generic = new GenericLibrary();
		String report_file = Harness.report_testcase;
		List<String> report_data = new ArrayList<String>();
		String report_type=Harness.ls_ReportingType;
		
		String ls_Msg,ls_FunctionName="WAIT_FOR",ls_Status;	
		
		int li_Value=Integer.parseInt(li_value);
			//wait_driver.manage().timeouts().implicitlyWait(li_Value, TimeUnit.SECONDS);
				////Muthu-Thread.sleep(3000);
				
				ls_Msg = "Wait Time in Seconds";
	    		LOG.info(ls_Msg);
	    		ls_Status = "Done";	
		
		/*if(report_type.equals("DETAIL"))
		{
			//for Excel detail reporting
			report_data.add(ls_FunctionName);//Function Name
			report_data.add("");//object name
			report_data.add(li_value);//Expected
			report_data.add("");//Actual
			report_data.add(ls_Msg);//Detail
			report_data.add(ls_Status);//Status
			GenericLibrary.Report(report_file,report_data );
		}*/
  }//method end

}//class
