package Core_Lib;

import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import Core_Lib.GenericLibrary;

public class PDF_ON_IE_VALIDATION 
{
	   Map<String, String> variablevalues = new LinkedHashMap<String, String>();//This map is used to store values from text file

   public void PDF_ON_IE_VALIDATION(	WebDriver PDF_driver,String ls_Objname,String ls_optionflag) 
   {
	   
	   String ls_currenturl = null;
	   String ls_str = null;
	   String ls_Objvalue;
 	   boolean lb_validate=false;
	   ls_Objvalue =ls_Objname;
	 
	  try
	  {
		  try
		  {
			  ls_currenturl= PDF_driver.getCurrentUrl();
		  }catch(Exception e)
		  {
			  
 
		  }//end of catch stmt
		  
	      if(ls_currenturl.contains(ls_Objvalue))
	      {
	    	  try
	    	  {
	    		  ls_str =PDF_driver.getPageSource();
	    	  }catch(Exception e)
	    	  {
				  

	    	  }//end of catch stmt
	    	  if(ls_str.contains(ls_Objvalue))
	    	  {
	    		  lb_validate=true;
	    		  
	    		  try
	    		  {
	    			  PDF_driver.close();
	    			  
	    		  }catch(Exception e)
	    		  {
	    			  
  
	    		  }//end of catch stmt
	    		  try
	    		  {
	    			  GenericLibrary.shiftContrlToParentWindow(ScreenDriver.scr_driver);
	    			  
	    		  }catch(Exception e)
	    		  {
	    			  

	    		  }
	    		  PDF_driver = null;
	    		 
	    	  }/* else
	    	  	{
	    		  PDF_driver.close();
	    		  GenericLibrary.shiftContrlToParentWindow(obj_screen.scr_driver);
	    		  PDF_driver = null;
	    		 
	    	  }//if of ls_str
*/	    		  
	       }//else of ls_currenturl
	      else
	      {	  
	    	  try
	    	  {
	    		  ls_str =PDF_driver.getPageSource();
	    	  }catch(Exception e)
	    	  {
	    		  

	    	  }//end of catch stmt
    	      if(ls_str.contains(ls_Objvalue))
    	       {
    	    	  lb_validate= true;
    	    	  try
	    		  {
	    			  PDF_driver.close();
	    		  }catch(Exception e)
	    		  {
	    			  
  
	    		  }//end of catch stmt
	    		  try
	    		  {
	    			  GenericLibrary.shiftContrlToParentWindow(ScreenDriver.scr_driver);
	    			  
	    		  }catch(Exception e)
	    		  {
	    			  

	    		  }
    		      PDF_driver = null;
    		      ScreenDriver.popup_driver=null;
    		 
    	       }//if of ls_str
    	       else
    	      {
    	    	   try
 	    		  {
 	    			  PDF_driver.close();
 	    		  }catch(Exception e)
 	    		  {
 	    			 
   
 	    		  }//end of catch stmt
 	    		  try
 	    		  {
 	    			  GenericLibrary.shiftContrlToParentWindow(ScreenDriver.scr_driver);
 	    			  
 	    		  }catch(Exception e)
 	    		  {
 	    			 

 	    		  }
    		     PDF_driver = null;
    		     ScreenDriver.popup_driver=null;
    	      }//if of ls_str
	      }// else of URL containing the substring
	      if(lb_validate)
	      {
	    	  
	      }else
	      {
	    	  
	      }
	  }catch(Exception e)
	   {
		  
	   }
	   
	   
   }
	
}
