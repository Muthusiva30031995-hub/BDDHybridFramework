package Core_Lib;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import Core_Lib.Browser_Close;
import Core_Lib.Browser_Invoke_Url;
import Core_Lib.TestController;
import config.defs;
//import Mas_Lib.QBoard;
import Core_Lib.File_Exists;
import Core_Lib.Store_Value_Variable;
//import Mas_Lib.*;

public class Harness
{   
	Logger LOG = Logger.getLogger(Harness.class.getName());

	//EXCL Reporting
	public static int rowindex1=2;
	public static boolean lb_file=false;
	public static boolean lb_status=false;
	public static boolean lb_insertrow=false;
	public static int li_insertrow=1;
	public static String report_testcase=null;
	GenericLibrary obj_Generic = new GenericLibrary();
	public static long time;
	public static String ls_ReportingType;
	
	public static boolean reportstatus_update=false; // need to check
	
	
	public static  String gi_DATASOURCE;
	public static int li_rowno=0;
	public boolean  gb_browserpopup_exists=false;//to optimize pop-up identification
	public String  gs_TEST_RESULT = "PASS";
	public String gs_product;
	public static boolean selection_menu=true;
	
	public static String gs_case_path;
	public static String gs_data_path; 
	public static String gs_bin_path;
	public static String gs_root_path ;
	public static String gs_core_lib_path;
	public static String gs_browser_path;
	 
	 public static String gs_url,gs_iPortalGenius_Url,gs_ODM_Url,gs_KCenter_url,SYMBILITY_URL,HIMARLEY_URL,LMS_URL;
	 public static String ls_TestdatasheetPath;
	 public static String[] gs_EXCLInputFieldname;
	 public static String[]  gs_EXCLOutputFieldname;
	 public static  String[] gs_EXCLInputvalue;
	 public static String[] gs_EXCLOutputvalue;
	 public static String[] gs_Output_Object_Value;
	 public static String[] gs_Output_Object;
	 public static String[]  gs_InputParameter_Value;
	 public static String[] gs_InputParameter;
	 public static String ls_Testcaseid;
	 public static String gs_Browser;
	 public static int gs_EXCL_INPUTcurrentstart;
	 public static int gs_EXCL_OUTPUTcurrentstart;
	 String start_time=null;
	 
	 public static String genius_selection_option;
	 public static String upload_FilePath;
	 public static String download_FilePath;
	 public static String AutoIT_FilePath;
	 public static String gs_ExecutionSheet;
	 public static String gs_Screenshot;
	 public boolean gs_Excel;
	 boolean file_exists = false;
	 
	 public static String sheetname =null;
	 
	 public static boolean lb_script_Continue = true; // added by shan
	 
	 //Property to read from INI file
	 Properties INIFILE = new Properties(); 					// Variable to read from INI file
	 Browser_Invoke_Url obj_browser = new Browser_Invoke_Url();	//creating object for browser invoke method
	 Browser_Close obj_close = new Browser_Close();				//creating object for browser close method 
	 TestController obj_controller = new TestController();		//creating object for TestController method
	 public static boolean createfile = false;
	 public static String masterReportFolder="";
	 public static String reportExcelFolder="";	
	 public static String reportExcelFailFolder="";
	 public static String reportExcelScreenShotFolder="";
		
	 public void read_INIFile_new(String ls_testcase,String filepath,String report_path,String source,String gs_Driver,String ExecutionSheet,String ScreenShot,String ls_applicationName, String executionType) 
		{
			try
			{
					gs_Browser = gs_Driver;
					gs_ExecutionSheet=ExecutionSheet;
					gs_Screenshot=ScreenShot;
		           //Adding .xlsx to the testcase name
		            String ls_test_case="/"+ls_testcase+".xlsx";
	 
		            
		            //Reporting file creation
		            List<String> report_data = new ArrayList<String>();
		            String ls_date= new SimpleDateFormat("dd/MM/YYYY/HH-mm-ss").format(Calendar.getInstance().getTime()) ;
					ls_date =ls_date.replaceAll("/","-");
					sheetname =ls_testcase;
					
					//To create  new sheet for reporting
					 if(!createfile)
					{
						if(gs_ExecutionSheet.equalsIgnoreCase("Yes")) //the testcase will update as sheet wise (Group of testcase from execution sheet)
						{
							masterReportFolder=report_path;
							//reportExcelFolder=masterReportFolder+"/" +ls_testcase+ "_" +ls_date;
							new File(masterReportFolder).mkdirs();
							//new File(reportExcelFolder).mkdirs();
							//report_testcase=report_path+"Report/"+ls_applicationName+ls_date+".xlsx";
							report_testcase=masterReportFolder + "//"+ "TestReport_"+ ls_applicationName+ls_date+".xlsx";
						}
						else 
						{
							masterReportFolder=report_path;
							//reportExcelFolder=masterReportFolder+"/" +ls_testcase+ "_" +ls_date;
							new File(masterReportFolder).mkdirs();
							//new File(reportExcelFolder).mkdirs();
							//report_testcase=report_path+"Report/"+ls_applicationName+ls_date+".xlsx";
							report_testcase=masterReportFolder + "//" + "TestReport_" + ls_testcase+"_"+ls_date+".xlsx";//The  report will create for each testcase	
						} 
					createfile=true;
					}
					 	
					 	reportExcelFolder=masterReportFolder+"//" +ls_testcase+ "_" +ls_date;
						reportExcelFailFolder=reportExcelFolder+ "/Failure";
						reportExcelScreenShotFolder=reportExcelFolder;
						new File(reportExcelFolder).mkdirs();
						new File(reportExcelFailFolder).mkdirs();
						new File(reportExcelScreenShotFolder).mkdirs();
						
						
					//Variable to assign source of data CTDRSOURCE/EXCLSOURCE/TESTCASEXL
					gi_DATASOURCE=source;	//TESTCASEXL  or  EXCLSOURCE 
					
					//to get Detail EXCL Report
					ls_ReportingType="DETAIL";//GENERAL/DETAIL
		           
					//To check the file Exixts or not
					String ls_path =filepath;
					File_Exists obj_file = new File_Exists();
					file_exists=obj_file.FILE_EXISTS(ls_path);
					
					
					//To update the report if ini file is not exist
					if(!file_exists)
					{
						if(ls_ReportingType.equals("DETAIL"))
						{
							//for Excl detail reporting
							report_data.add("Harness");
							report_data.add(ls_path);
							report_data.add("");
							report_data.add("The INI File Not Found");
							report_data.add("Fail");
							
							obj_Generic.Report(report_testcase,report_data );
						}//if of report
						//Assertion
					}
					
					//Reading INI file
				    File ls_envfile = new File(ls_path);
					INIFILE.load(new FileInputStream(ls_envfile));
				
					String currDir = System.getProperty("user.dir");
					
				    gs_root_path = currDir + "\\";					
				    gs_core_lib_path = gs_root_path + INIFILE.getProperty("WTM_CORE_LIB");
				    gs_data_path = gs_root_path + INIFILE.getProperty("WTM_DATA_LIB") + "\\" + ls_applicationName;
				    gs_bin_path = gs_root_path +INIFILE.getProperty("WTM_BIN"); 					
				    gs_case_path = gs_root_path + INIFILE.getProperty("WTM_CASE_LIB")+ "\\" + ls_applicationName;
				    gs_browser_path =gs_root_path +INIFILE.getProperty("WTM_BROWSER");
				    //AutoIT_FilePath = INIFILE.getProperty("WTM_AutoIT_FILE");
				    // genius_selection_option=INIFILE.getProperty("WTM_INPUT_GEN_ENVI");//only for genius application
				    
				    //get the url from ini
				    gs_url=INIFILE.getProperty("WTM_APP_URL"); 
				    gs_iPortalGenius_Url = INIFILE.getProperty("WTM_GENIUS_URL");
				    gs_ODM_Url = INIFILE.getProperty("WTM_ODM_URL");
				    gs_KCenter_url = INIFILE.getProperty("WTM_KCenter_URL");
				    SYMBILITY_URL = INIFILE.getProperty("SYMBILITY_URL");
				    HIMARLEY_URL = INIFILE.getProperty("HIMARLEY_URL");
				    LMS_URL = INIFILE.getProperty("LMS_URL");
				    // Added test data path to read the datasheet from data lib  
				    ls_TestdatasheetPath=gs_data_path + "/Datasheet.xlsx";		
				    
				    //to get the Number of Iteration from the Data Sheet
				    IterationFlagCheck obj_FlagChk = new IterationFlagCheck();
				    List<String> TestId= new ArrayList<>();
				    
				    lb_file=false;
		            
				    if(gi_DATASOURCE.equalsIgnoreCase("EXCLSOURCE"))
				    {
				    	TestId = obj_FlagChk.gfn_GetIteartionCount(ls_TestdatasheetPath, ls_testcase);
				    }else if(gi_DATASOURCE.equalsIgnoreCase("TESTCASEXL"))
				    {
				    	//Changed by Ambika to avoid / in the  excl report on 11/01/2018
				    	TestId.add(ls_testcase);
				    }//if gi_DATASOURCE

				    String ls_ExpVal = TestId.get(0);
				    
				   //To Record starting time for execution sheet
				    Date startTime = new  Date();
				    System.out.println("Start time"+startTime);
				    
				    if(ls_ExpVal.contains("Test flag doesn't set correctly")||(ls_ExpVal.contains("Test case was not avaialable")))
			        {
				    	 //Inserting Teatcase name for status in Excl Report
					    List<String> summaryreport_data = new ArrayList<String>();
					    summaryreport_data.add("Insert");
					    summaryreport_data.add(ls_testcase);
					    obj_Generic.Report(report_testcase,summaryreport_data);

						//reporting Inserting Teatcase name 
						List<String> report_data1 = new ArrayList<String>();
						report_data1.add(ls_testcase);
						obj_Generic.Report(report_testcase,report_data1 );
					
						//Insert Heading  in Excl Report
						List<String> report_data_Heading = new ArrayList<String>();
						if(ls_ReportingType.equalsIgnoreCase("DETAIL"))
						{
						report_data_Heading.add("Function Name");
						report_data_Heading.add("Field-Name/Window Name/Automation Files");
						report_data_Heading.add("Expected-Value");
						report_data_Heading.add("Actual-Value");
						report_data_Heading.add("Details");
						report_data_Heading.add("Status");
						obj_Generic.Report(report_testcase,report_data_Heading );
						}else if(ls_ReportingType.equalsIgnoreCase("GENERAL"))
						{
							report_data_Heading.add("Function Name");
							report_data_Heading.add("Field-Name");
							report_data_Heading.add("Expected-Value");
							report_data_Heading.add("Actual-Value");
							report_data_Heading.add("Status");
							obj_Generic.Report(report_testcase,report_data_Heading );
						}//else of ls_ReportingType
					        	
					    //Inserting Teatcase name for status in Excl Report
						  List<String> summaryreport_data1 = new ArrayList<String>();
						  summaryreport_data1.add("Harness");
						  summaryreport_data1.add("");
					      summaryreport_data1.add("");
	             	      summaryreport_data1.add(ls_ExpVal+"  for "+ls_testcase);
	             	      summaryreport_data1.add("");
						  summaryreport_data1.add("Fail");
					      obj_Generic.Report(report_testcase,summaryreport_data1);
						 					  
						 Date endTime =  new Date();
						 /* time =endTime.getTime() - startTime.getTime(); 
						  lb_status=true;
						  reportstatus_update=false;
						  
						  ls_Testcaseid=ls_testcase;
						  List<String> status_update = new ArrayList<String>();
						  status_update.add("Status");
						  obj_Generic.Report(report_testcase,status_update );
						  reportstatus_update=true;*/
						  
						  //need to change
						  Assert.assertTrue(false, ls_ExpVal);

						  
			        }else
			        {
			        	// testcase iterations performed from the datasheet
					    for(String ls_TestCaseid:TestId)
						 {			
					    	ls_Testcaseid=ls_TestCaseid;
					    	//ls_Testcaseid=ls_TestCaseid.substring(ls_Testcaseid.indexOf("_", 1)+1,ls_TestCaseid.length());
						    LOG.info(" ************************************************************ls_Testcaseid"+ ls_Testcaseid+"***************************");
						  
				            //Inserting Teatcase name for status in Excl Report
						    List<String> summaryreport_data = new ArrayList<String>();
						    summaryreport_data.add("Insert");
						    summaryreport_data.add(ls_Testcaseid);
						    obj_Generic.Report(report_testcase,summaryreport_data);

							//reporting Inserting Teatcase name 
							List<String> report_data1 = new ArrayList<String>();
							report_data1.add(ls_Testcaseid);
							obj_Generic.Report(report_testcase,report_data1 );
						
							//Insert Heading  in Excl Report
							List<String> report_data_Heading = new ArrayList<String>();
							if(ls_ReportingType.equalsIgnoreCase("DETAIL"))
							{
							report_data_Heading.add("Function Name");
							report_data_Heading.add("Field-Name/Window Name/Automation Files");
							report_data_Heading.add("Expected-Value");
							report_data_Heading.add("Actual-Value");
							report_data_Heading.add("Details");
							report_data_Heading.add("Status");
							obj_Generic.Report(report_testcase,report_data_Heading );
							}else if(ls_ReportingType.equalsIgnoreCase("GENERAL"))
							{
								report_data_Heading.add("Function Name");
								report_data_Heading.add("Field-Name");
								report_data_Heading.add("Expected-Value");
								report_data_Heading.add("Actual-Value");
								report_data_Heading.add("Status");
								obj_Generic.Report(report_testcase,report_data_Heading );
							}//else of ls_ReportingType
							
							
							try 
					    	{
					    		li_rowno++;
					    		int iteration=defs.siteReachableCount;
					    		//Need to add the site reachable check
					    		do{
					    		//boolean siteReachable=true;
					    		boolean siteReachable=pingURL(gs_url, defs.siteReachableTimeout);
					    		if(siteReachable)
					    		{
								obj_browser.BROWSER_INVOKEURL(gs_Driver,gs_url); 
								//obj_browser.BROWSER_INVOKEURL(gs_Driver,"http://cc-test.myqbe.com/CC/ClaimCenter.do?ts=25867802");
								
								break;
					    		}
					    		else
					    		{
					    			//Trigger Email
					    			//Site Down or Not Reachable
					    			// Wait for 15 mind
					    			System.out.println("Waiting for the Site Reachable");
					    			//Muthu-Thread.sleep(defs.pageLoadTimeout);					    			
					    		}
					    		
					    		if(iteration < 1){
									break;
								}
					    		iteration--;
					    		
					    		
					    		}while(1<2);
								////Muthu-Thread.sleep(2000);
							} catch (Exception e1)
					    	{
								LOG.error("Not able to invoke the browser in Harness");
							}

							//calling Test Controller
					    	obj_controller.TEST_CONTROLLER(gs_case_path, ls_test_case,ls_applicationName,executionType);
					    	gs_EXCLOutputFieldname=null;
							gs_EXCLOutputvalue=null;
							gs_EXCLInputFieldname=null;
							gs_EXCLInputvalue=null;
							String test="";
							//closing the browser 
							//WebDriver driver = Browser_Invoke_Url.driver;
							/*try 
							{
								////Muthu-Thread.sleep(3000);
								//obj_close.BROWSER_CLOSE("");
								try {
								    Runtime.getRuntime().exec("taskkill /F /IM IEDriverServer.exe");
								    Runtime.getRuntime().exec("taskkill /F /IM iexplore.exe");
								} catch (IOException e) {
								    //e.printStackTrace();
								}
							} catch (Exception e1) {
								LOG.error("Not able to Close the browser in Harness");
							}*///end of catch
							//obj_browser.getDriver().close();
							
							 Date endTime =  new Date();
							time =endTime.getTime() - startTime.getTime(); 
							System.out.println("endTime"+time);	
							lb_status=true;
							reportstatus_update=false;
							List<String> status_update = new ArrayList<String>();
							status_update.add("Status");
							obj_Generic.Report(report_testcase,status_update );
							reportstatus_update=true;
							
					    	}//FOR li_loop
						
			        }//else of ls_Exp_val
				    lb_file=false; // need changes
				  	//lb_file=true;
				    
				    } catch (IOException e) 
				    {
						LOG.error("Exception in loading the INIFILE");	
						LOG.error(e.getStackTrace());
					}catch (Exception e) 
					{
				LOG.error("Exception in loading the INIFILE");	
				LOG.error(e.getStackTrace());
				
					}
			// end of catch stmt
				    
		}  
	 
	public void read_INIFile(String ls_testcase,String filepath,String report_path,String source,String gs_Driver,String ExecutionSheet,String ScreenShot,String ls_applicationName,String executionType) 
	{
		try
		{
				gs_Browser = gs_Driver;
				gs_ExecutionSheet=ExecutionSheet;
				gs_Screenshot=ScreenShot;
	           //Adding .xlsx to the testcase name
	            String ls_test_case="/"+ls_testcase+".xlsx";
 
	            //Reporting file creation
	            List<String> report_data = new ArrayList<String>();
	            String ls_date= new SimpleDateFormat("dd/MM/YYYY HH-mm-ss").format(Calendar.getInstance().getTime()) ;
				ls_date =ls_date.replaceAll("/","-");
				sheetname =ls_testcase;
				
				//To create  new sheet for reporting
				 if(!createfile)
				{
					if(gs_ExecutionSheet.equalsIgnoreCase("Yes")) //the testcase will update as sheet wise (Group of testcase from execution sheet)
					{
						report_testcase=report_path+"Report/"+ls_applicationName+ls_date+".xlsx";
					}
					else 
					{
						
						report_testcase=report_path+"Report/"+ls_testcase+"_"+ls_date+".xlsx";//The  report will create for each testcase
					} 
				createfile=true;
				}
	            
	            
				//Variable to assign source of data CTDRSOURCE/EXCLSOURCE/TESTCASEXL
				gi_DATASOURCE=source;	//TESTCASEXL  or  EXCLSOURCE 
				
				//to get Detail EXCL Report
				ls_ReportingType="DETAIL";//GENERAL/DETAIL
	           
				//To check the file Exixts or not
				String ls_path =filepath;
				File_Exists obj_file = new File_Exists();
				file_exists=obj_file.FILE_EXISTS(ls_path);
				
				
				//To update the report if ini file is not exist
				if(!file_exists)
				{
					if(ls_ReportingType.equals("DETAIL"))
					{
						//for Excl detail reporting
						report_data.add("Harness");
						report_data.add(ls_path);
						report_data.add("");
						report_data.add("The INI File Not Found");
						report_data.add("Fail");
						
						obj_Generic.Report(report_testcase,report_data );
					}//if of report
					//Assertion
				}
				
				//Reading INI file
			    File ls_envfile = new File(ls_path);
				INIFILE.load(new FileInputStream(ls_envfile));
			
				
				//path  - C:\Selenium_Workspace\QBE\src\ which the framework uses- is stored
			    gs_root_path = INIFILE.getProperty("WTM_ROOT");							
			    gs_core_lib_path = gs_root_path + INIFILE.getProperty("WTM_CORE_LIB");
			    gs_data_path = gs_root_path + INIFILE.getProperty("WTM_DATA_LIB");
			    gs_bin_path = gs_root_path +INIFILE.getProperty("WTM_BIN"); 					
			    gs_case_path = gs_root_path + INIFILE.getProperty("WTM_CASE_LIB");
			    gs_browser_path =gs_root_path +INIFILE.getProperty("WTM_BROWSER");
			    AutoIT_FilePath = INIFILE.getProperty("WTM_AutoIT_FILE");
			    // genius_selection_option=INIFILE.getProperty("WTM_INPUT_GEN_ENVI");//only for genius application
			    
			    //get the url from ini
			    gs_url=INIFILE.getProperty("WTM_APP_URL"); 
			    gs_iPortalGenius_Url = INIFILE.getProperty("WTM_GENIUS_URL");
			    gs_ODM_Url = INIFILE.getProperty("WTM_ODM_URL");
			    gs_KCenter_url = INIFILE.getProperty("WTM_KCenter_URL");
			    
			    // Added test data path to read the datasheet from data lib  
			    ls_TestdatasheetPath=gs_data_path + "/Datasheet.xlsx";		
			    
			    //to get the Number of Iteration from the Data Sheet
			    IterationFlagCheck obj_FlagChk = new IterationFlagCheck();
			    List<String> TestId= new ArrayList<>();
			    
			    lb_file=false;
	            
			    if(gi_DATASOURCE.equalsIgnoreCase("EXCLSOURCE"))
			    {
			    	TestId = obj_FlagChk.gfn_GetIteartionCount(ls_TestdatasheetPath, ls_testcase);
			    }else if(gi_DATASOURCE.equalsIgnoreCase("TESTCASEXL"))
			    {
			    	//Changed by Ambika to avoid / in the  excl report on 11/01/2018
			    	TestId.add(ls_testcase);
			    }//if gi_DATASOURCE

			    String ls_ExpVal = TestId.get(0);
			    
			   //To Record starting time for execution sheet
			    Date startTime = new  Date();
			    System.out.println("Start time"+startTime);
			    
			    if(ls_ExpVal.contains("Test flag doesn't set correctly")||(ls_ExpVal.contains("Test case was not avaialable")))
		        {
			    	 //Inserting Teatcase name for status in Excl Report
				    List<String> summaryreport_data = new ArrayList<String>();
				    summaryreport_data.add("Insert");
				    summaryreport_data.add(ls_testcase);
				    obj_Generic.Report(report_testcase,summaryreport_data);

					//reporting Inserting Teatcase name 
					List<String> report_data1 = new ArrayList<String>();
					report_data1.add(ls_testcase);
					obj_Generic.Report(report_testcase,report_data1 );
				
					//Insert Heading  in Excl Report
					List<String> report_data_Heading = new ArrayList<String>();
					if(ls_ReportingType.equalsIgnoreCase("DETAIL"))
					{
					report_data_Heading.add("Function Name");
					report_data_Heading.add("Field-Name/Window Name/Automation Files");
					report_data_Heading.add("Expected-Value");
					report_data_Heading.add("Actual-Value");
					report_data_Heading.add("Details");
					report_data_Heading.add("Status");
					obj_Generic.Report(report_testcase,report_data_Heading );
					}else if(ls_ReportingType.equalsIgnoreCase("GENERAL"))
					{
						report_data_Heading.add("Function Name");
						report_data_Heading.add("Field-Name");
						report_data_Heading.add("Expected-Value");
						report_data_Heading.add("Actual-Value");
						report_data_Heading.add("Status");
						obj_Generic.Report(report_testcase,report_data_Heading );
					}//else of ls_ReportingType
				        	
				    //Inserting Teatcase name for status in Excl Report
					  List<String> summaryreport_data1 = new ArrayList<String>();
					  summaryreport_data1.add("Harness");
					  summaryreport_data1.add("");
				      summaryreport_data1.add("");
             	      summaryreport_data1.add(ls_ExpVal+"  for "+ls_testcase);
             	      summaryreport_data1.add("");
					  summaryreport_data1.add("Fail");
				      obj_Generic.Report(report_testcase,summaryreport_data1);
					 					  
					 Date endTime =  new Date();
					 /* time =endTime.getTime() - startTime.getTime(); 
					  lb_status=true;
					  reportstatus_update=false;
					  
					  ls_Testcaseid=ls_testcase;
					  List<String> status_update = new ArrayList<String>();
					  status_update.add("Status");
					  obj_Generic.Report(report_testcase,status_update );
					  reportstatus_update=true;*/
					  
					  //need to change
					  Assert.assertTrue(false, ls_ExpVal);

					  
		        }else
		        {
		        	// testcase iterations performed from the datasheet
				    for(String ls_TestCaseid:TestId)
					 {			
				    	ls_Testcaseid=ls_TestCaseid;
					    LOG.info(" ************************************************************ls_Testcaseid"+ ls_Testcaseid+"***************************");
					  
			            //Inserting Teatcase name for status in Excl Report
					    List<String> summaryreport_data = new ArrayList<String>();
					    summaryreport_data.add("Insert");
					    summaryreport_data.add(ls_Testcaseid);
					    obj_Generic.Report(report_testcase,summaryreport_data);

						//reporting Inserting Teatcase name 
						List<String> report_data1 = new ArrayList<String>();
						report_data1.add(ls_Testcaseid);
						obj_Generic.Report(report_testcase,report_data1 );
					
						//Insert Heading  in Excl Report
						List<String> report_data_Heading = new ArrayList<String>();
						if(ls_ReportingType.equalsIgnoreCase("DETAIL"))
						{
						report_data_Heading.add("Function Name");
						report_data_Heading.add("Field-Name/Window Name/Automation Files");
						report_data_Heading.add("Expected-Value");
						report_data_Heading.add("Actual-Value");
						report_data_Heading.add("Details");
						report_data_Heading.add("Status");
						obj_Generic.Report(report_testcase,report_data_Heading );
						}else if(ls_ReportingType.equalsIgnoreCase("GENERAL"))
						{
							report_data_Heading.add("Function Name");
							report_data_Heading.add("Field-Name");
							report_data_Heading.add("Expected-Value");
							report_data_Heading.add("Actual-Value");
							report_data_Heading.add("Status");
							obj_Generic.Report(report_testcase,report_data_Heading );
						}//else of ls_ReportingType
						
						
						try 
				    	{
				    		li_rowno++;
							obj_browser.BROWSER_INVOKEURL(gs_Driver,gs_url); 
							//Muthu-Thread.sleep(2000);
						} catch (Exception e1)
				    	{
							LOG.error("Not able to invoke the browser in Harness");
						}

						//calling Test Controller
				    	obj_controller.TEST_CONTROLLER(gs_case_path, ls_test_case,ls_applicationName,executionType);
				    	gs_EXCLOutputFieldname=null;
						gs_EXCLOutputvalue=null;
						gs_EXCLInputFieldname=null;
						gs_EXCLInputvalue=null;
						
						//closing the browser 
						WebDriver driver = Browser_Invoke_Url.driver;
						try 
						{
							//Muthu-Thread.sleep(3000);
							//obj_close.BROWSER_CLOSE("");
							try {
							    Runtime.getRuntime().exec("taskkill /F /IM IEDriverServer.exe");
							} catch (IOException e) {
							    //e.printStackTrace();
							}
						} catch (Exception e1) {
							LOG.error("Not able to Close the browser in Harness");
						}//end of catch
						
						 Date endTime =  new Date();
						time =endTime.getTime() - startTime.getTime(); 
						System.out.println("endTime"+time);	
						lb_status=true;
						reportstatus_update=false;
						List<String> status_update = new ArrayList<String>();
						status_update.add("Status");
						obj_Generic.Report(report_testcase,status_update );
						reportstatus_update=true;
						
				    	}//FOR li_loop
					
		        }//else of ls_Exp_val
			    lb_file=false; // need changes
			  	//lb_file=true;
			    
			    } catch (IOException e) 
			    {
					LOG.error("Exception in loading the INIFILE");			
				}// end of catch stmt
			    
	}//read ini file method
	
	
	public static boolean pingHost(String host, int port, int timeout) {
	    try (Socket socket = new Socket()) {
	        socket.connect(new InetSocketAddress(host, port), timeout);
	        return true;
	    } catch (IOException e) {
	        return false; // Either timeout or unreachable or failed DNS lookup.
	    }
	}
	
	/**
	 * Pings a HTTP URL. This effectively sends a HEAD request and returns <code>true</code> if the response code is in 
	 * the 200-399 range.
	 * @param url The HTTP URL to be pinged.
	 * @param timeout The timeout in millis for both the connection timeout and the response read timeout. Note that
	 * the total timeout is effectively two times the given timeout.
	 * @return <code>true</code> if the given HTTP URL has returned response code 200-399 on a HEAD request within the
	 * given timeout, otherwise <code>false</code>.
	 */
	public static boolean pingURL(String url, int timeout) {
	    url = url.replaceFirst("^https", "http"); // Otherwise an exception may be thrown on invalid SSL certificates.

	    try {
	        HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
	        connection.setConnectTimeout(timeout);
	        connection.setReadTimeout(timeout);
	        connection.setRequestMethod("HEAD");
	        int responseCode = connection.getResponseCode();
	        return (200 <= responseCode && responseCode <= 399);
	    } catch (IOException exception) {
	        return false;
	    }
	}
	
}//end of class