package Core_Lib;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

//import com.gargoylesoftware.htmlunit.ElementNotFoundException;

//This function gets the property value for an object whose property is specified.
//This function also calls the GET_OBJECT_IDENTIFIER function in order to create the object on the fly.

public class Get_Property_Value 
{
	public String  GET_PROPERTY_VALUE(WebDriver driver,String  ls_ObjectName,String  ls_Property, String ls_Var, String optional_ERR_FLAG)
	{
		//LOGGER
		Logger LOG = Logger.getLogger(Get_Property_Value.class.getName());
		
		//Detail Reporting
		 GenericLibrary obj_Generic = new GenericLibrary();
		 String report_file = Harness.report_testcase;
		 List<String> report_data = new ArrayList<String>();
		 String report_type=Harness.ls_ReportingType;
		 String ls_Functionname="GET_PROPERTY_VALUE";
		 String ls_Msg=null;
		 String ls_status=null;
		
	    String Get_Prop = null;
	   
	  	//This variable holds the WebElement from webpage
	    WebElement ele_Object = null;
	    
	    WebDriver Property_driver = Browser_Invoke_Url.driver;
	    try
		{
	    //function call for GET_OBJECT_IDENTIFIER to get the property value for particular object
	    Get_Object_Identifier object_identifier = new Get_Object_Identifier();
	   // //Muthu-Thread.sleep(4000);
	    ele_Object =object_identifier.GET_OBJECT_IDENTIFIER(Property_driver, ls_ObjectName,ls_Property, optional_ERR_FLAG);
			 
	    if(ele_Object!=null) // added by shan to stop script when object not identified
		{
		
			switch(ls_Property)
			{
				case "innertext":
					Get_Prop =ele_Object.getText() ;
					break;
				case "value":
					Get_Prop =ele_Object.getAttribute("value");
					break;
				case "Title":
					//Muthu-Thread.sleep(1000);
					Get_Prop =ele_Object.getAttribute("title");
					//System.out.println(Get_Prop+"$$$$$$$$$$$$$$$");
					break;
				default:
					Get_Prop =ele_Object.getText() ;
					break;
					
			}
		
			if(!Get_Prop.equals(null))
			{
				ls_Msg="The Property value is captured Successfully";
				ls_status="Pass";
				LOG.error("The Value of "+ls_ObjectName+" is null in GetPropertyValue");
		   	}
			else
		   	{
		   		ls_Msg="Unable to get the value of particular property";
				ls_status="Fail";
				Get_Prop = "Null Value"; // object not identified
		   	}//else
	    

		 } // End If  added by shan to stop script when object not identified
	    else
	    {
	    	Get_Prop = "Obj Issue"; // object not identified
	    }
	    
		} // End try
	    catch(Exception e)
		 {
			 ls_Msg="Unable to get the value of particular property";
			 ls_status="Fail";
		 }
		return Get_Prop;

	}//end of GET_PROPERTY_VALUE
	
}//class end
