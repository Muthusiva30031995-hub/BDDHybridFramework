package Core_Lib;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ODM_ADD_DOWNLOAD_BASKET // added by shan - 04/07/18
{	
	//Detail Reporting
	static List<String> methodreport_data= new ArrayList<String>();
	GenericLibrary obj_Generic = new GenericLibrary();
	static String report_file = Harness.report_testcase;
	List<String> report_data = new ArrayList<String>();
	static String report_type=Harness.ls_ReportingType;
	String ls_Functionname="ODM_ADD_DOWNLOAD_BASKET";
	String ls_Msg=null;
	String ls_status=null;
	
	// below function used to add specified documents in to Download Basket in ODM Application
	public void ODM_AddDocToBasket(WebDriver driver,String ls_window, String ls_ObjectName, String ls_Objvalue, String ls_optional_flag) throws InterruptedException
	{	
		String [] ls_Doc = ls_Objvalue.split("\\|");
		String ls_DocView = ls_Doc[0];
		String ls_DocCount = ls_Doc[1].replace("D", "");
		String ls_TotDocMaxSize = ls_Doc[2].replace("MB", "");
		
		int li_DocCount = Integer.parseInt(ls_DocCount);
		int li_ExpectedDocument = li_DocCount;
		int li_TotDocMaxSize = Integer.parseInt(ls_TotDocMaxSize);
		li_TotDocMaxSize = li_TotDocMaxSize*1000;
		
		boolean bl_Start = true;
		String selecteddocumentsize = null;
		int k=1;
		int j=1;
				
		while(bl_Start)
		{
			int iDocStart = 0;
			int idocumentsCount = 0;
						
			boolean bl_DocCheck = false;
			String documentsCount = driver.findElement(By.id("DOCSV:SRSV:qp:pglStart")).getText();
			String ducumentstart;
			
			String CheckBox_id= null, CheckAlias_xpath = null;
			
			// To get no of documents present in the Page
			if(documentsCount.contains("to"))	
			{
				String[] val = documentsCount.split(" ");
				ducumentstart = val[0];
				documentsCount = val[2];
				idocumentsCount = Integer.parseInt(documentsCount);
				iDocStart = Integer.parseInt(ducumentstart);
				idocumentsCount = idocumentsCount - iDocStart+1;
			}
			else
			{
				String[] val = documentsCount.split(" ");
				documentsCount = val[0];
				idocumentsCount = Integer.parseInt(documentsCount);
			}
			
			// To scroll up the browser
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollTo(0, -document.body.scrollHeight);");
			
			// calculate how many documents left to add
			if(idocumentsCount <= li_DocCount)
			{
				try
				{
					WebElement element_object = driver.findElement(By.xpath("//td/a[text()='Select']"));
					element_object.click();
					//Muthu-Thread.sleep(1000);
					driver.findElement(By.xpath("//td[text()='All']")).click();
					bl_DocCheck = true;
				}
				catch(Exception e)
				{
					System.out.println(e.toString());
				}
			}
			
			else if(idocumentsCount > li_DocCount)
			{
				int li_CountChkbox = 0,li_itreationStrt = 0;
					
				for(int i=li_itreationStrt;i<idocumentsCount;i++)
				{
					String getImage = null;
					try
					{
						if(ls_DocView.equalsIgnoreCase("ListView"))
						{
							CheckBox_id 	 = "DOCSV:SRSV:qp:qpc:i1:"+i+":sbc1::content";
//							CheckImage_xpath = "//img[contains(@id,'DOCSV:SRSV:qp:qpc:i1:"+i+":cdi') or contains(@id,'DOCSV:SRSV:qp:qpc:i1:"+i+":id')]";
							CheckAlias_xpath = "//table[contains(@id,'DOCSV:SRSV:qp:qpc:i1:"+i+":pg')]//span[@class='WccLargeFontBold']";
							getImage = driver.findElement(By.xpath(CheckAlias_xpath)).getText();
						}
						else if(ls_DocView.equalsIgnoreCase("TableView"))
						{
							CheckBox_id 	 = "DOCSV:SRSV:qp:qpc:table1:"+i+":sbc2::content"; 
							CheckAlias_xpath = "//td[contains(@id,'DOCSV:SRSV:qp:qpc:table1:"+i+":c')]//span[@class='WccLargeFontBold']";
							getImage = driver.findElement(By.xpath(CheckAlias_xpath)).getText();
						}
					}
					catch(Exception e)
					{
						getImage = "No Value";
					}
					
					// To click checkbox if its not alias document
					if(!getImage.contains("alias")) 
					{
						driver.findElement(By.id(CheckBox_id)).click();
						li_CountChkbox = li_CountChkbox + 1;
		//				System.out.println("Step :="+ i);
						bl_DocCheck = true;
					}	
					
					// if expected document has selected then exit for loop
					if(li_CountChkbox == li_DocCount)
					{
						break;
					}
				} // End For Loop
			}
			
			//Muthu-Thread.sleep(5000);
			
			// documents added to basket
			if(bl_DocCheck)
			{
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//img[@alt='Add to Download Basket']")).click();
				//Muthu-Thread.sleep(5000);
				selecteddocumentsize = driver.findElement(By.id("DOCSV:SRSV:qp:qpc:cdctb1::icon")).getAttribute("alt");
//				System.out.println(selecteddocumentsize);
			}
				
			// To get Added document count
			String [] ls_str = selecteddocumentsize.split("/");
			String [] ls_str1 = ls_str[0].trim().split(" ");
			String ls_DocumentAdded = ls_str1[4].trim();
			int li_DocumentAdded = Integer.parseInt(ls_DocumentAdded);
			
			// To get added document size
			String [] ls_str2 = ls_str[1].trim().split("-");
			String ls_DocumentSize = ls_str2[1].trim();
			ls_DocumentSize = ls_DocumentSize.replace("MB", "").trim();
			
			int li_DocumentSize1;
			int iPosi = ls_DocumentSize.indexOf(".");
			
			if (iPosi > 0)
			{			
				double li_DocumentSize = Double.parseDouble(ls_DocumentSize);
				li_DocumentSize1 = (int) (li_DocumentSize * 1000);
			}
			else
			{
				int li_DocumentSize = Integer.parseInt(ls_DocumentSize);
				li_DocumentSize1 = li_DocumentSize * 1000;
			}
			
			if (li_DocumentSize1 <= li_TotDocMaxSize)
			{
				if (li_DocumentAdded == li_ExpectedDocument )
				{
					double li_Size = li_DocumentSize1/1000;
					bl_Start = false;	
					ls_Msg = "Expected Documents : "+li_DocumentAdded+" added Successfully into the Basket with Size : "+ li_Size + "MB";
					ls_status = "Pass";
				}
				else
				{
					driver.findElement(By.id("DOCSV:SRSV:qp:clNext")).click();	
					li_DocCount = li_ExpectedDocument - li_DocumentAdded;
				}
			}
			else
			{
				ls_Msg = "Documents : "+li_DocumentAdded+" added Successfully into the Basket but basket size greater than 300 MB";
				ls_status = "Fail";
				bl_Start = false;
			}
			k++;	
		}

		if(report_type.equals("DETAIL"))
		{
			//for Excl DETAIL reporting
			report_data.add(ls_Functionname);
			report_data.add(ls_ObjectName);
			report_data.add(ls_Objvalue);
			report_data.add("");
			report_data.add(ls_Msg);
			report_data.add(ls_status);
			obj_Generic.Report(report_file,report_data );
			
		}//if of report
	}
}
