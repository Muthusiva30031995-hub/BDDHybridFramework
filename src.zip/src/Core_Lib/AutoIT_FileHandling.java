package Core_Lib;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.testng.Assert;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;

//This class is used to upload/download a file to/from application using AutoIT Tool
//Added by Ambika on 10/01/2018 

//Function customized by shan - 06/07/18

public class AutoIT_FileHandling 
{
	//Detail Reporting
	static List<String> methodreport_data= new ArrayList<String>();
	GenericLibrary obj_Generic = new GenericLibrary();
	static String report_file = Harness.report_testcase;
	List<String> report_data = new ArrayList<String>();
	static String report_type=Harness.ls_ReportingType;
	String ls_Functionname;
	String ls_FilenamePath;
	String ls_Msg=null;
	String ls_status=null;
	
	// getting the file path from ini file through Harness class
	String ls_filepath=Harness.AutoIT_FilePath;
	String ls_Browser = Harness.gs_Browser;
	String ls_ClassName = "AutoIT_FileHandling";
	
	public void AutoIT_FileUpload(String FileName)
	{
		//Adding the file name to the path
		String filepath=ls_filepath+"/"+ls_Browser+"/Upload.exe";
		System.out.println(filepath);
		String ls_UploadFolPath = ls_filepath+"/UploadFile";
		ls_Functionname = "AutoIT_FileUpload";
		ls_FilenamePath = ls_UploadFolPath+"/"+FileName;
		
		try 
		{
			 CheckFile(ls_FilenamePath); // To Check upload file is exists
			 
			//Executing the Auto exe file to upload the file
			Runtime.getRuntime().exec(filepath);
			
			//Reporting
			ls_Msg="File Uploaded successfully ";
			ls_status="Pass";	
		} 
		catch (IOException e) 
		{
			ls_Msg="Exception in file Uploading Function";
			ls_status="Warning";
		}
		if(report_type.equals("DETAIL"))
		{
			//for Excl DETAIL reporting
			report_data.add(ls_ClassName);
			report_data.add(ls_Functionname);
			report_data.add("");
			report_data.add("");
			report_data.add(ls_Msg);
			report_data.add(ls_status);
			obj_Generic.Report(report_file,report_data );
			
		}//if of report
	}
	
	public void AutoIT_FileDownload(String DownloadFileName) throws Exception
	{
		//Adding the file name to the path
		String filepath=ls_filepath+"/"+ls_Browser+"/Download.exe";
		String ls_DownloadFolPath = ls_filepath+"/DownloadFile";
		
		CheckFolder(ls_DownloadFolPath); // To Check download folder is exists
		
		System.out.println(filepath);
		ls_Functionname ="AutoIT_FileDownload";
		boolean fileexists = false;
		String[] ls_splitVal = null;
		File oFile = null;
		
		try
	    {
			//Executing the Auto exe file to download the file
			Runtime.getRuntime().exec(filepath);
	
			//wait for 10 sec
			//Muthu-thread.sleep(10000);
			
			if(DownloadFileName.contains("&")) // To check randomly downloaded files
			{
				ls_splitVal = DownloadFileName.split("&");
				
				for(int i = 0; i<ls_splitVal.length;i++)
				{
					DownloadFileName = ls_splitVal[i];
					
					ls_FilenamePath = ls_DownloadFolPath+"/"+DownloadFileName;
					
					oFile = new File(ls_FilenamePath);
					
					if (oFile.exists())
			        {
						fileexists = true;
						break;
			        } 
				}
			}

			else
			{
				ls_FilenamePath = ls_DownloadFolPath+"/"+DownloadFileName;
				
				oFile = new File(ls_FilenamePath);
				
				if (oFile.exists())
		        {
					fileexists = true;
		        } 
			}
			
			if (fileexists)
	        {
				ls_Msg="File Downloaded successfully ";
				ls_status="Pass";	
	        } 
			else
			{
				ls_Msg="Not able to  Download the file ";
				ls_status="Warning";
			}
		}
		catch (Exception e) 
		{
			ls_Msg="Exception in Download the file ";
			ls_status="Fail";
		}
		if(report_type.equals("DETAIL"))
		{
			//for Excl DETAIL reporting
			report_data.add(ls_ClassName);
			report_data.add(ls_Functionname);
			report_data.add("");
			report_data.add("");
			report_data.add(ls_Msg);
			report_data.add(ls_status);
			obj_Generic.Report(report_file,report_data );
			
		}//if of report

	}

	public void CheckFolder(String ls_FolderPath) throws IOException
	{
		File folder = new File(ls_FolderPath);
		
		File[] listOfFiles = folder.listFiles();
		
		if(folder.exists())
		{
			for (int ifile = 0; ifile < listOfFiles.length; ifile++)
			{
				listOfFiles[ifile].delete();
			}
		}
		else
		{
			folder.mkdir();
		}
	}
	
	public void CheckFile(String ls_FilePath) throws IOException
	{
		File oFile = new File(ls_FilePath);
		
		if(!oFile.exists())
		{
			oFile.createNewFile();
		}

	}
	
}
