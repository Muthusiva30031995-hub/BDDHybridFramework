package Core_Lib;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class ODM_TABLE
{
	//Detail Reporting
	 GenericLibrary obj_Generic = new GenericLibrary();
	 String report_file = Harness.report_testcase;
	 List<String> report_data = new ArrayList<String>();
	 String report_type=Harness.ls_ReportingType;
	 String ls_Functionname="ODM_WORKPLAN_TABLE";
	 String ls_Msg=null;
	 String ls_status=null;

	public void lfn_ODM_TABLE(WebDriver driver,String objectName,String ls_rownum,String ls_columnum,String ls_tag)
	{
		
		WebElement page_ddl = null;
		
		try
		{
		//Identify the WebList
			page_ddl =driver.findElement(By.id("ClaimWorkplan:ClaimWorkplanScreen:WorkplanLV:_ListPaging"));
		//Get the all the values from the List
		if(page_ddl != null)
		{
			//Muthu-Thread.sleep(3000); // added by shan
			List<WebElement> ls_ddlOptions = new ArrayList<WebElement>();
			Select select_object = new Select(page_ddl);
			ls_ddlOptions.addAll(select_object.getOptions());
			
		//get last value from the list
			int li_ddlSize= ls_ddlOptions.size();		//need to check the size
			WebElement last_value = ls_ddlOptions.get(li_ddlSize-1);
			
		//select the last value from the drop down list
			last_value.click();
		}
		
		}
		catch(Exception e)
		{
			ls_Msg="The Page Drop down list is not available";
		}
		
		Get_Object_Identifier ls_obj = new Get_Object_Identifier();
		WebElement webtable = ls_obj.GET_OBJECT_IDENTIFIER(driver, objectName, "", "");
		
		
		//identify the table and no of row 
			List<WebElement> rows	= webtable.findElements(By.xpath("./tbody/tr"));
			//List<WebElement> rows = driver.findElements(By.xpath("//table[@id='ClaimWorkplan:ClaimWorkplanScreen:WorkplanLV']/tbody/tr"));
		
		//navigate to last row
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);  // added by shan 13-02-18
			int lastRowNo=rows.size();
			try
			{
				//click on the link of particular document
				String xpath="./tbody/tr["+lastRowNo+"]/td["+ls_columnum+"]/"+ls_tag;
					//String ls_Xpath="//table[@id='ClaimWorkplan:ClaimWorkplanScreen:WorkplanLV']/tbody/tr["+lastRowNo+"]/td[8]/a";
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);  // added by shan 13-02-18
					WebElement ls_element = webtable.findElement(By.xpath(xpath));
					ls_element.click();
					ls_status="Pass";
					ls_Msg="Link has clicked Successfully";
			}catch(Exception e)
			{
				ls_status="Fail";
				ls_Msg="Exception in ODM_WORKPLAN_TABLE Function";
			}

			if(report_type.equals("DETAIL"))
			{
				//for Excl DETAIL reporting
				report_data.add(ls_Functionname);
				report_data.add(objectName);
				report_data.add("");
				report_data.add("");
				report_data.add(ls_Msg);
				report_data.add(ls_status);
				obj_Generic.Report(report_file,report_data );
				if(ls_status.equalsIgnoreCase("Fail"))
				{
					Assert.assertTrue(false, ls_Msg);
				}
			}//if of report
	}//end of method

}//end of class
