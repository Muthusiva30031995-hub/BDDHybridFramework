package Core_Lib;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import Core_Lib.GenericLibrary;
//The function was writen to close the popup Browser Session, 
public class Pop_Up_Close 
{
	public void POPUP_CLOSE (String optional_ERR_FLAG)
	{
		//LOGGER
		Logger LOG = Logger.getLogger(Get_Property_Value.class.getName());
	   
		WebDriver popup_driver=ScreenDriver.popup_driver;
		//Reporting
		GenericLibrary obj_Generic = new GenericLibrary();
		String report_file = Harness.report_testcase;
		List<String> report_data = new ArrayList<String>();
		String report_type=Harness.ls_ReportingType;
		
		String ls_Msg,ls_FunctionName="POPUP_CLOSE",ls_Status;
		
	// To close any open popup dialog
	/*try
	{*/
	  	if (popup_driver!=null)
	   	{			    
			try
			{
				popup_driver.close();
	  			ls_Msg = "The Popup browser closed successfully";
	    		LOG.info(ls_Msg);
	    		ls_Status = "Pass";   
			}
			catch(Exception e)
    		{
				ls_Msg = "Unable to close the Popup in POPUP_CLOSE Function";
	    		LOG.error(ls_Msg);
	    		ls_Status = "Fail";
			}//end of catch
			
			// To call shiftContrlToParentWindow method
			GenericLibrary.shiftContrlToParentWindow(popup_driver);

		}
	  	else
		{
			ls_Msg = "The popup browser does not exist.";
    		LOG.error(ls_Msg);
    		ls_Status = "Fail";    		
		}//else of popup driver exist
	  	
//	}
	/*catch(Exception e)
	{
		ls_Msg = "Exception in POUP CLOSE";
		LOG.error(ls_Msg);
		ls_Status = "Fail";
	}//END OF CATCH
*/	
	if(report_type.equals("DETAIL"))
	{
		//for Excel detail reporting
		report_data.add(ls_FunctionName);//Function Name
		report_data.add("");//object name
		report_data.add("");//Expected
		report_data.add("");//Actual
		report_data.add(ls_Msg);//Detail
		report_data.add(ls_Status);//Status
		obj_Generic.Report(report_file,report_data );
	}//if of report	
	
	}//method end 

}//clsss end
