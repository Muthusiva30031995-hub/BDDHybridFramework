package Core_Lib;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.testng.Assert;

// This function compares the cell data in the webtable, with expected as defined in the harness template
// and reports match/mismatch. Also checks for the not null values in the webtable. This function calls the
//GET_TABLE_CELL_DATA to get the cell data which has to be checked with the value as defined in the HRANESS

public class CHECK_TABLE_VALUE
{
	 
	public void check_Table_Value(String myContext, String ls_ObjectName, String  Rowno,String Colno,String Exp_Value,String Label_Name,String  optional_ERR_FLAG)
	{                
		
		//LOGGER
		Logger LOG = Logger.getLogger(CHECK_TABLE_VALUE.class.getName());
		
		//Detail Reporting
		 GenericLibrary obj_Generic = new GenericLibrary();
		 String report_file = Harness.report_testcase;
		 List<String> report_data = new ArrayList<String>();
		 String report_type=Harness.ls_ReportingType;
		 String ls_Functionname="CHECK_TABLE_VALUE";
		 String ls_Msg=null;
		 String ls_status=null;
		
		 String Table_Value = null;
		 String ObjectName,Functional_Label;
		 boolean bln_check;
	    
		 int li_value;
		 int rowno;
		 int colno;
		 float li_table_value;
		 String ls_Expected = Exp_Value;
	   
		 bln_check = false;
		 ObjectName=ls_ObjectName;
		 Functional_Label = " :: "+ls_ObjectName;
	    
		 Get_Table_Cell_Data obj_get_cell_data = new Get_Table_Cell_Data(); 
		 Check_Value obj_chk_val = new Check_Value();
		 DecimalConversion obj_deci_val = new DecimalConversion();
		 GET_ExpectedValue obj_ExpVal = new GET_ExpectedValue();
		 RoundValue obj_RoundValue = new RoundValue();
	 
		 SimpleDateFormat obj_format = new SimpleDateFormat("dd/MM/yyyy");
		 Calendar obj_calender = Calendar.getInstance();
	     
		 if(!(Exp_Value==null))
		 {
			 // to Validate Date in the Expected Value
			 if (Exp_Value.substring(0, 2).equals("^^"))
			 {
				 Exp_Value=Exp_Value.substring(2, Exp_Value.length());
				 li_value = Integer.parseInt(Exp_Value);
				 obj_calender.setTime(new Date()); // Now use today date.
				 obj_calender.add(Calendar.DATE, li_value); // Adding  days to current date
				 Exp_Value = obj_format.format(obj_calender.getTime());
			 }//if for ^^
		
			//To remove01,02,...from object name
			int index = ls_ObjectName.length();
			String ls_substring = ls_ObjectName.substring(index-2);
			Pattern pattern = Pattern.compile("[0-9]+"); 
			Matcher matcher = pattern.matcher(ls_substring);
			if (matcher.matches())	
			{
				ls_ObjectName = ls_ObjectName.substring(0, index-2);
			}//if of matcher
			
		    //Get the data from the webtable for the Row and Column specified by using GET_TABLE_CELL_DATA function
			Table_Value=obj_get_cell_data.GET_TABLE_CELL_DATA(myContext, ls_ObjectName, Rowno, Colno, optional_ERR_FLAG);
		    
			// to compare the discount percentage from Mainframe with CChange   
		    if (ObjectName.equals("cChangePremiumBreakdown_DiscountRate_Table"))
		    {
		       Table_Value=Table_Value.substring(2, 6);
		       li_table_value=Integer.parseInt(Table_Value);
		       li_table_value=Math.round(li_table_value);
		        	
		    }//if of ObjectName
	
		    //Calling the CHECK_VALUE function to compare the data
		    	
		    	Exp_Value = Exp_Value.trim();
		   		Exp_Value = obj_ExpVal.ExpectedValue(Exp_Value); 
		   		
		   		Table_Value = obj_deci_val.lfn_Conversion(Table_Value);
		   		Exp_Value = obj_deci_val.lfn_Conversion(Exp_Value);
		   		
		   		if (Label_Name.contains("&R"))
	        	{
		   			Table_Value = obj_RoundValue.ROUND_VALUE(Table_Value);
		   			Exp_Value = obj_RoundValue.ROUND_VALUE(Exp_Value);
		   		}//if of &R
		   		
		   		String lc_firstchar =ls_Expected.substring(0);
				
				if (lc_firstchar.equals("~"))
				{
					Exp_Value = "~"+Exp_Value;
				}
		   		//calling Check_Value Function
		   		bln_check = obj_chk_val.CHECK_VALUE(Table_Value, Exp_Value,Label_Name,optional_ERR_FLAG);

		   		//Validation
		   		if(!Label_Name.contains("NagativeCheck")) // condition added by shanmugakumar for to check negative scenarios - 08 Feb 18
		   		{
		   			if(bln_check)
			   		{
			   			if (lc_firstchar.equals("~"))
			   			{
			   				ls_status="Pass";
			   				ls_Msg="Partially Compared";
			   				LOG.info(Functional_Label+" :-"+ Label_Name+" : Actual Value( "+Table_Value+ ") partially compared Sucessfully with Expected value ("+ Exp_Value+")");	
			   			}
			   			else
			   			{
			   				ls_status="Pass";
			   				ls_Msg="Compared";
					    	LOG.info(Functional_Label+" :-"+ Label_Name+" : Actual Value( "+Table_Value+ ") compared Sucessfully with Expected value ("+ Exp_Value+")");	
			   			}//else of ~
			   		}//if of bln check
			   		else
			   		{
			   			ls_status="Fail";
			   			ls_Msg="Mismatch";
			        	LOG.info(Functional_Label+" :-"+ Label_Name+" : Actual Value( "+Table_Value+ ") is mismatch  with Expected value ("+ Exp_Value+")");
			//        	Assert.assertTrue(bln_check, Functional_Label+" :-"+ Label_Name+" : Actual Value( "+Table_Value+ ") is mismatch  with Expected value ("+ Exp_Value+")");
			   		}//else of blnflag
		   		}
		   		else
		   		{
		   			if(bln_check)
			   		{
			   			if (lc_firstchar.equals("~"))
			   			{
			   				ls_status="Pass";
			   				ls_Msg="Partially Mismatch";
			   			}
			   			else
			   			{
			   				ls_status="Pass";
			   				ls_Msg="Mismatch";
			   			}//else of ~
			   		}//if of bln check
			   		else
			   		{
			   			ls_status="Fail";
			   			ls_Msg="Compared";
			//        	Assert.assertTrue(bln_check, Functional_Label+" :-"+ Label_Name+" : Actual Value( "+Table_Value+ ") is mismatch  with Expected value ("+ Exp_Value+")");
			   		}//else of blnflag
		   		}
		 }//if of Exp value not null
		 else
		 {
			 ls_status="Fail";
			
		 }//else of Exp value not null
		//reporting
		    if(report_type.equals("GENERAL"))
			{
				//reporting
				report_data.add(ls_Functionname);
				report_data.add(ls_ObjectName+"-"+Label_Name);
				report_data.add(Exp_Value);
				report_data.add(Table_Value);
				report_data.add(ls_status);
				obj_Generic.Report(report_file,report_data );
			}//if of reporting
		    else if(report_type.equals("DETAIL"))
		    {
		    	//reporting
				report_data.add(ls_Functionname);
				report_data.add(ls_ObjectName+"-"+Label_Name);
				report_data.add(Exp_Value);
				report_data.add(Table_Value);
				report_data.add(ls_Msg);
				report_data.add(ls_status);
				obj_Generic.Report(report_file,report_data );
		    }
		    	
	}//Method end

}//class End
