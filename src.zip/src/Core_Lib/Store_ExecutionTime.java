package Core_Lib;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import org.apache.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.testng.Assert;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import Core_Lib.GenericLibrary;

// This function reads the excel file and imports the data to datatable to a dictionary object
public class Store_ExecutionTime

{
	public static boolean case_status = true;
	
	public void Store_ExecutionTime(String ls_TestdatasheetPath,String ls_Testcaseid,String ls_sheetID,long mins , long seconds) 
	{
		//LOGGER
		Logger LOG = Logger.getLogger(Store_ExecutionTime.class.getName());
		
		//Detail Reporting
		 GenericLibrary obj_Generic = new GenericLibrary();
		 String report_file = Harness.report_testcase;
		 List<String> report_data = new ArrayList<String>();
		 String report_type=Harness.ls_ReportingType;
		 String ls_Functionname="GET_TESTDATA_DETAILS";
		 String ls_Msg=null;
		 String ls_status=null;
		
		
		String ls_TestcaseName=ls_Testcaseid;
		String   ls_paremeterprefix;
		String ls_sheetname = null;
		int  ls_datasheetid;
		int li_columnnumbertofetch;
		int li_rownumbertofetch;
		String ls_FoundCellObj = null;
		int li_inputvalueindex;
		int  li_valueindex;
		int  li_index = 0;
		int li_columincrement;
		int li_column_value = 0;
		String ls_Inputvalue = null;
		String ls_Fieldname = null;
		String ls_Value = null;
		String ls_Textvalue = null;
		String case_name = null;
		Sheet ls_excel_sheet = null;
		
		boolean lb_testcasefound;
		boolean ls_CheckFile = false;
		
		FileInputStream file_open = null;
		Workbook ls_excel_book = null;
		
		File_Exists gfn_FILE_EXISTS=new File_Exists();
		
		
			ls_CheckFile=gfn_FILE_EXISTS.FILE_EXISTS(ls_TestdatasheetPath);
		
		
		try 
		{
			file_open = new FileInputStream(ls_TestdatasheetPath);
			ls_excel_book = WorkbookFactory.create(file_open);
			
			/*
			 * //'this is the name of Sheet in Excel file "Datasheet.xlsx" where data needs
			 * to be entered if (ls_sheetID.trim().equalsIgnoreCase("I")) {
			 * //LOG.info("SHEET ID is I"); ls_sheetname="Input"; ls_datasheetid=1;
			 * ls_paremeterprefix="Input"; li_column_value=3;
			 * 
			 * } else if(ls_sheetID.equalsIgnoreCase("O")) { //LOG.info("SHEET ID is O");
			 * ls_sheetname="Expectedoutput"; ls_datasheetid=2; ls_paremeterprefix="Output";
			 * li_column_value=3; }//else
			 */
			
			 ls_excel_sheet = ls_excel_book.getSheet("Sheet1");
			li_rownumbertofetch= ls_excel_sheet.getLastRowNum();
			int rownum=0;
			for(int i =0;i<li_rownumbertofetch;i++) {
				
				if(ls_excel_sheet.getRow(i).getCell(0).toString().contains(ls_TestcaseName))
				{
					rownum = ls_excel_sheet.getRow(i).getRowNum();
					Row row = ls_excel_sheet.getRow(rownum);
					Cell cell = row.createCell(1);
					cell.setCellValue(mins+"."+seconds);
					break;
							
				}
				
			}
			FileOutputStream fileOut = new FileOutputStream(ls_TestdatasheetPath); 
			ls_excel_book.write(fileOut); 
		    fileOut.close(); 
		
		} catch (EncryptedDocumentException e) {
			LOG.error("EncryptedDocumentException in WorkbookFactory of GetTestDataDeatil Function");
		} catch (InvalidFormatException e)
		  {
			LOG.error("InvalidFormatException in WorkbookFactory of GetTestDataDeatil Function");
		  } catch (IOException e)
		{
			LOG.error("IOException in WorkbookFactory of GetTestDataDeatil Function");
		
		}//end of catch
		finally
		{
			if(file_open!=null)
				try {
						
						file_open.close();
						
					} catch (IOException e) 
			
						{
							LOG.error("EXCEPTION IN FILE CLOSING");
							
						}//CATCH OF FILE CLOSE
		}//finally
		
	}//End Function

}// end of class 

