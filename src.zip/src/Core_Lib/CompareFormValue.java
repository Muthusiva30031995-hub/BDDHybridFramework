package Core_Lib;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class CompareFormValue {
	
    public void CompareFormValue(ArrayList<String> arr_list, int arr_size,ArrayList<String> Form_Prem) throws IOException
    {
    	String DataSheetPath = "C:\\Users\\E00724E\\Desktop\\createworkbook.xlsx";
    	FileInputStream inputStream = new FileInputStream(new File(DataSheetPath));
		XSSFWorkbook workbook = new XSSFWorkbook(inputStream);

		XSSFSheet sheet = workbook.getSheet("EndorsmentValues");
		int rows; // No of rows
	    rows = sheet.getPhysicalNumberOfRows();
	    String[] cellvalue;
	    String[] cellvalue2;
        int i=0;
        Map< String,String> hm = new HashMap< String,String>(); 
        Map< String,String> hm1 = new HashMap< String,String>();
	    // Create a DataFormatter to format and get each cell's value as String
        DataFormatter dataFormatter = new DataFormatter();
        Iterator<Row> rowIterator = sheet.rowIterator();
        while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            
            // Now let's iterate over the columns of the current row
            Iterator<Cell> cellIterator = row.cellIterator();
            Cell cell = row.getCell(6);
            Cell cell2 = row.getCell(10);
            Cell cell3 = row.getCell(11);
            Cell cell4 = row.getCell(12);
            String cellValue = dataFormatter.formatCellValue(cell);
            String cellValue2 = dataFormatter.formatCellValue(cell2);
            String cellValue3 = dataFormatter.formatCellValue(cell3);
            String cellValue4 = dataFormatter.formatCellValue(cell4);
            System.out.print(cellValue + "\t");
            System.out.print(cellValue2 + "\n");
            
            hm.put(cellValue, cellValue2);
            hm1.put(cellValue3, cellValue4);
            
                        /*while (cellIterator.hasNext()) {
                Cell cell = cellIterator.next();
                String cellValue = dataFormatter.formatCellValue(cell);
                System.out.print(cellValue + "\t");
            }*/
            System.out.println();
        }
        
     // Returns Set view      
        Set< Map.Entry< String,String> > st = hm.entrySet();    
   
        for (Map.Entry< String,String> me:st) 
        { 
            System.out.print(me.getKey()+":"); 
            System.out.println(me.getValue()); 
        }
        
        Row row2 = sheet.getRow(1);
        Iterator<Row> rowIterator2 = sheet.rowIterator();
        while (rowIterator2.hasNext()) {
            Row row = rowIterator2.next();
            
            // Now let's iterate over the columns of the current row
            Iterator<Cell> cellIterator = row.cellIterator();
            Cell cell = row.getCell(6);
            Cell cell2 = row.getCell(10);
            Cell cell3 = row.getCell(11);
            Cell cell4 = row.getCell(12);
            String cellValue = dataFormatter.formatCellValue(cell);
            String cellValue2 = dataFormatter.formatCellValue(cell2);
            String cellValue3 = dataFormatter.formatCellValue(cell3);
            String cellValue4 = dataFormatter.formatCellValue(cell4);
            System.out.print(cellValue + "\t");
            System.out.print(cellValue2 + "\n");
            System.out.print(cellValue3 + "\t");
            System.out.print(cellValue4 + "\n");
            if(hm.get(cellValue).equalsIgnoreCase(hm1.get(cellValue)))
            {
            	System.out.println("For Coverage:"+cellValue+"::The Premium value in DB:"+hm.get(cellValue)+" MAtches with Value in PDF:"+hm1.get(cellValue));
            	row.createCell(13).setCellValue("Matches");
            	row.createCell(14).setCellValue("For Coverage:"+cellValue+"::The Premium value in DB:"+hm.get(cellValue)+" MAtches with Value in PDF:"+hm1.get(cellValue));
            }
            else
            {
            	System.out.println("For Coverage:"+cellValue+"::The Premium value in DB:"+hm.get(cellValue)+" Not MAtches with Value in PDF:"+hm1.get(cellValue));
            	row.createCell(13).setCellValue("NOT Matches");
            	row.createCell(14).setCellValue("For Coverage:"+cellValue+"::The Premium value in DB:"+hm.get(cellValue)+" Not MAtches with Value in PDF:"+hm1.get(cellValue));
            
            }
            
           /* while (cellIterator.hasNext()) {
                Cell cell = cellIterator.next();
                String cellValue = dataFormatter.formatCellValue(cell);
                System.out.print(cellValue + "\t");
            }*/
            System.out.println();
        }
        
        
        FileOutputStream outputStream = new FileOutputStream(DataSheetPath);
        workbook.write(outputStream);
        workbook.close();
        outputStream.close();
        
    }
    
 }
