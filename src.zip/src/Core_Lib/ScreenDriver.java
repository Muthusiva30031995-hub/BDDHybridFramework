package Core_Lib;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import java.sql.*;
import java.io.*;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
//import com.ibm.as400.*;
import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;
import org.apache.pdfbox.util.PDFTextStripperByArea;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.Augmentable;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
//import com.gargoylesoftware.htmlunit.javascript.host.html.Image;
import com.google.common.base.Predicate;
import com.mysql.cj.jdbc.DatabaseMetaData;
import com.mysql.cj.jdbc.result.ResultSetMetaData;
import com.thoughtworks.selenium.webdriven.commands.AlertOverride;

import Core_Lib.GenericLibrary;
import Core_Lib.Set_Property;
import config.defs;
import tests.BaseTest;
import base.runtimeRepo;

@Augmentable

public class ScreenDriver {
	public static WebDriver scr_driver = null; // Getting WebDriver Control to perform action
	public static WebDriver popup_driver = null;
	public static String ls_Objvalue = null; // This variable holds value of the GUI object from inputmap

	public static String li_row;
	public static String li_col;
	public static String li_tagName; // 08 Feb 18 - Shan

	static String file = Harness.gs_root_path;
	static DateFormat Date = new SimpleDateFormat("dd-MM-YYYY HH-mm-ss");
	static Date testcasedate = new Date();
	static String date = Date.format(testcasedate);
	String snapshotfolderName = Harness.reportExcelScreenShotFolder;
	//File screenShot = new File(file + "/resultFolder/Screenshot/" + Harness.ls_Testcaseid + "_" + date);
	File screenShot1 = new File(snapshotfolderName);
	File screenShotFailure1 = new File(snapshotfolderName + "/Failure/");
	public static String handle = null;
	Set<String> handles = null;
	public boolean SCREEN_DRIVER(String componentname, Map<String, String> inputmap, Map<String, String> outputmap,
	String ls_case_path, String applicationName) throws InterruptedException {
		// LOGGER
		Logger LOG = Logger.getLogger(ScreenDriver.class.getName());

		GenericLibrary obj_Generic = new GenericLibrary();
		String report_type = Harness.ls_ReportingType;
		String report_file = Harness.report_testcase;
		List<String> report_data = new ArrayList<String>();
		List<String> statusreport_data = new ArrayList<String>();
		String ls_Functionname = "SCREEN_DRIVER";
		String ls_Msg = null;
		String ls_statusMsg = null;
		String ls_status = null;
		String ls_status1 = null;

		boolean lb_script_Continue = Harness.lb_script_Continue; // added by shan

		Harness obj_harness = new Harness();
		File_Exists obj_file = new File_Exists();
		FileInputStream open_excel_file = null;
		Get_Object_Identifier ls_obj = new Get_Object_Identifier();
		Browser_Invoke_Url obj_browser = new Browser_Invoke_Url();
		WebElement ele_objectname = null;

		List<String> input_key_lst = new ArrayList<String>(); // This list holds the GUI objects of the screen component
		List<String> input_value_lst = new ArrayList<String>(); // This list holds the values to be provided GUI object
																// of the screen component
		List<String> output_key_lst = new ArrayList<String>(); // This list holds the GUI objects of the screen
																// component
		List<String> output_value_lst = new ArrayList<String>(); // This list holds the values to be provided GUI object
																	// of the screen component
		List<WebElement> tableRows = new ArrayList<WebElement>();
		List<WebElement> tablecolumns = new ArrayList<WebElement>();

		String currDir = System.getProperty("user.dir");

		String filepath = currDir + "\\Components\\" + applicationName + "\\" + componentname.trim() + ".xlsx"; // adding
																												// component
																												// name
																												// with
																												// case
																												// path
																												// to
																												// get
																												// the
																												// file
																												// path
		// LOG.info("FILE PATH OF SCREEN COMPONENT = "+filepath);
		String sheetname = "Sheet1"; // This variable holds the sheet name of excel

		String ls_data_path = Harness.gs_data_path;
		String TimpStamp_filepath = ls_data_path + "/TimeStamp.xlsx";
		
		String rootpath = Harness.gs_root_path;
		String CasePath = Harness.gs_case_path;
		String testcaseID = Harness.ls_Testcaseid;
		String tetcaseName = Harness.report_testcase;
		String DBValidationSheetName = CasePath+"\\"+tetcaseName+"_DB.xlsx";
		
		String Policynumber = "QHP9827949";
		//String Policynumber = "PHP9827812";
		//String DECtextFile = CasePath+"\\"+Policynumber+".txt";
		String policynumbertxt;
		
		String DECtextFile = CasePath+"\\"+tetcaseName+".txt";
		
		int rowno = 0;
		int columnNo = 0;

		String ls_Parameter = null; // This variable holds name of the GUI object from inputmap
		// String ls_Objvalue = null; //This variable holds value of the GUI object from
		// inputmap
		String ls_cmd = null; // holds the cmd value from excel
		String ls_window = null; // holds the window name from datatable
		String ls_select = null;

		String ls_OutParameter; // holds the output parameter
		String ls_OutParameterValues; // holds the output parameter value
		String ls_Seq_heading = null; // holds the value from SEQ column from screen component excel sheet
		String gs_url = null;
		String ls_TC1value = null;
		String ls_objectname = null; // holds the parsed object name
		String ls_windowObj = null; // holds the Object name from excel sheet
		String[] ls_arrObjvalue;

		String ls_row;
		String ls_col;

		String[] ls_errorarray = null;
		String ls_optionflag = null;
		String ls_readystate;
		String ls_TRUE;
		String ls_property = null;
		String ls_var = null;
		String ls_errbutton;
		String ls_errorcode;
		String ls_dayvalue;
		String[] ls_array;
		String ls_Complete;
		String ls_value = null;
		String ls_value1 = null;
		String[] ls_Valuesarray;
		String ls_Name;
		String ls_ValueToValidate;
		String ls_applnid;

		String ls_strtocheck;
		String gs_product = null;
		String url = null;
		String gs_TEST_RESULT;
		String ls_component;
		String optional_ERR_FLAG = null;
		String ls_ObjectClassname = null;
		String ls_SelectedColumn = null;
		String ls_ExpectedGrossAmount;
		String ls_ExpectedPaymentCode;
		String ls_command;
		String ls_Return = null;
		String[] arrObjectDefinition;
		String ls_nextwindow = null;
		String ls_time_out;
		String li_itemnum;
		String ls_Parameter1;
		String ls_ExpectedValue;
		String ls_doc_name = null;
		String ls_category = null;

		int li_ComponentRowCount = 0; // holds the number of rows in the current screen component datafile
		int li_inputparamvalue, li_outputparamvalue; // holds the upperbound of input and output parameters/values
		int li_output = 0; // counter to count output value is initialized
		int li_tempoutputcount;
		int lb_nextscreen_index = -1;
		int check = 0;
		int li_columntocheck;
		int ls_rowcount;
		int rowsize = 0;
		int columnsize = 0;

		boolean lb_popupcheck = false;
		boolean lb_currentcommandexecuted = false;
		boolean lb_inputvaluescompleted = false; // to exhaust all the input items
		boolean lb_outputvaluescompleted = false; // to exhaust all the output items
		boolean lb_status = false;
		boolean lb_file = false;
		boolean obj_found = false;

		Workbook ls_excel_book = null;
		String excel_objname = null;
		File ls_gui_object_file;

		// retriving component name
		ls_component = componentname;
		runtimeRepo run = new runtimeRepo();

		if (componentname.equals("GWCCPartiesInvolved")) {
			System.out.println("Debugging");
		}
		Browser_Invoke_Url driverCache = new Browser_Invoke_Url();
		scr_driver = driverCache.getDriver();

		// Creating the object for Iterator to iterate the inputmap and outputmap
		Iterator<String> inputmapitr = inputmap.keySet().iterator();
		Iterator<String> outputmapitr = outputmap.keySet().iterator();

		Map<String, String> variablevalues = new LinkedHashMap<String, String>();// This map is used to store values
																					// from text file

		// This loop is storing the object values in list from inputmap
		for (String key : inputmap.keySet()) {
			// adding all the inputmap values into list object
			input_value_lst.add(inputmap.get(key));

		} // for loop of input object values

		while (inputmapitr.hasNext()) {
			input_key_lst.add(inputmapitr.next());

		} // while loop of input objects

		while (outputmapitr.hasNext()) {

			output_key_lst.add(outputmapitr.next());
		} // while loop of output objects

		// This loop is storing the object values in list from outputmap
		for (String key : outputmap.keySet()) {
			// adding all the outputmap values into list object
			output_value_lst.add(outputmap.get(key));
		} // for loop of output object values

		li_tempoutputcount = output_key_lst.size() - 1;
		li_outputparamvalue = output_key_lst.size() - 1;// This variable holds the size of output parameter
		li_inputparamvalue = input_key_lst.size() - 1;// This variable holds the size of input parameter

		System.out.println("Input value" + li_inputparamvalue);

		// to identify the presence of Next screen and streamline output parameters
		for (int li_loopoutputparamvalue = 0; li_loopoutputparamvalue <= li_tempoutputcount; li_loopoutputparamvalue++) {
			if (!lb_script_Continue) // added by shan
			{
				break;
			}

			ls_OutParameter = output_key_lst.get(li_loopoutputparamvalue);

			if (ls_OutParameter.trim().equalsIgnoreCase("NEXT_SCREEN".trim())) {
				ls_OutParameterValues = output_value_lst.get(li_loopoutputparamvalue);
				lb_nextscreen_index = li_loopoutputparamvalue;
				li_output = li_output + 1;
				break;

			} // 'if nextwindow

		} // for of output parameter

		if ((li_output == 1) && (lb_nextscreen_index != -1))
			lb_outputvaluescompleted = true;

		if (lb_nextscreen_index == -1) {
			LOG.error("NEXT_SCREEN parameter is not found");

		} // if of lb_nextscreen_index

		try {
			int li_input = 0;
			ls_gui_object_file = new File(filepath);

			// Checkinf the file is exists or not
			lb_file = obj_file.FILE_EXISTS(filepath);

			/*
			 * //Assertion to make sure the file is exists otherwise fail the TC
			 * Assert.assertTrue(lb_file,
			 * "The screen component associated with the test  case has not been located. Full path name is: "
			 * + filepath);
			 */

			open_excel_file = new FileInputStream(ls_gui_object_file);
			ls_excel_book = WorkbookFactory.create(open_excel_file);

			Sheet ls_excel_sheet = ls_excel_book.getSheet(sheetname);
			int rowcount = ls_excel_sheet.getLastRowNum();// counter to count input value is initialized.

			li_ComponentRowCount = rowcount; // Reading the Last row number to identify how many rows available
			li_ComponentRowCount = li_ComponentRowCount + 2;

			System.out.println("Componenet File path - " + filepath);
			System.out.println("Componenet Row Count - " + li_ComponentRowCount);

			// Executing the rows in the screen component
			for (int excel_loop = 1; excel_loop <= li_ComponentRowCount; excel_loop++) {
				// need to add condition
				if (!lb_script_Continue) // added by shan
				{
					break;
				}

				ls_windowObj = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 2);// storing the the
																									// object name from
																									// excel of screen
																									// component

				if (ls_windowObj != null) // Check if window object(Object name) is null
				{
					ls_windowObj = ls_windowObj.replaceAll("\n", "").trim();
				} else
					// Validation
					// Assert.assertNotNull(ls_windowObj, "The window obj is null in SCREEN DRIVER
					// Function");
					LOG.error("ls_windowObj " + ls_windowObj);

				ls_cmd = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 3);// storing the equivalen
																								// command like
																								// setproperty/check
																								// object exist/checkapp
																								// message for
																								// particular object
				if (ls_cmd != null) // Check if window object is null
				{
					ls_cmd = ls_cmd.trim();
				}

				if ((lb_inputvaluescompleted == true) && ((ls_cmd.equalsIgnoreCase("CHECK_APP_MESSAGE"))
						|| (ls_cmd.equalsIgnoreCase("DOCUMENT_VALIDATION"))
						|| (ls_cmd.equalsIgnoreCase("CHECK_OBJECT_EXIST"))
						|| (ls_cmd.equalsIgnoreCase("DOCUMENT_VALIDATION"))
						|| (ls_cmd.equalsIgnoreCase("SELECT_DATE_PICKER"))
						|| (ls_cmd.equalsIgnoreCase("GET_POPUP_OBJECTS"))
						|| (ls_cmd.equalsIgnoreCase("Popup_Browser_Close")
								|| (ls_cmd.equalsIgnoreCase("SWITCH_TO_IFRAME"))
								|| (ls_cmd.equalsIgnoreCase("CHECK_PROPERTY_VALUE"))
								|| (ls_cmd.equalsIgnoreCase("CHECK_NEGATIVE_CONDITION"))
								|| (ls_cmd.equalsIgnoreCase("STORE_PROPERTY_VALUE"))
								|| (ls_cmd.equalsIgnoreCase("ISENABLED"))))) {
					lb_popupcheck = false;
				} else if ((lb_inputvaluescompleted == true) || (ls_cmd == null)) {
					lb_popupcheck = true;
				} // end of else if of lb_inputvaluescompleted

				// Executing the commands found in the screen component by comparing input
				// parameter and object in the screen
				switch (ls_cmd)
				{
				
				
				//Merge Code Arun
				case "HANDLE_STALE_EXCEPTION":
					
					StaleElementException stale = new StaleElementException();
					ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5).trim();
					//stale.handleStaleElement(elementName);
					
				case "READPDF_WRITETXT":
					String pdf_read = ls_data_path+"/"+GenericLibrary.pdf_filename+".pdf";
					
					try (PDDocument document = PDDocument.load(new File(pdf_read)))
					{
						document.getClass();
						PDFTextStripperByArea stripper = new PDFTextStripperByArea();
		                stripper.setSortByPosition(true);

		                PDFTextStripper tStripper = new PDFTextStripper();

		                String pdfFileInText = tStripper.getText(document);
		                System.out.println("Text:" + pdfFileInText);

						try {
		                    //create a buffered reader that connects to the console, we use it so we can read lines
		                	

		                	    BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

		                	    BufferedWriter out = new BufferedWriter(new FileWriter(DECtextFile));
		                	    try {
		                	        String inputLine = null;
		                	        /*do {*/
		                	            //inputLine=in.readLine();
		                	            out.write(pdfFileInText);
		                	            out.newLine();
		                	        /*} while (!pdfFileInText.equalsIgnoreCase("eof"));*/
		                	        System.out.print("Write Successful");
		                	    } catch(IOException e1) {
		                	        System.out.println("Error during reading/writing");
		                	    } finally {
		                	        out.close();
		                	        in.close();
		                	    }
		                	
		                 }
		                    catch(IOException e1) {
		                      System.out.println("Error during reading/writing");
		                    }
					}
					break;
				case "SWITCH_TO_OLD_WINDOW":
					
					if (li_input <=  li_inputparamvalue)   
					{ 
						try
						{
						for (int li_loopinputparamvalue= 0;li_loopinputparamvalue<=li_inputparamvalue;li_loopinputparamvalue++)
							{       

								ls_Parameter= input_key_lst.get(li_loopinputparamvalue);
								ls_Objvalue =input_value_lst.get(li_loopinputparamvalue);

								if ( ls_windowObj.trim().equalsIgnoreCase(ls_Parameter.trim()))
								{

									try
									{
										ls_Seq_heading = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 4);
									}catch(Exception e)
									{
										LOG.error("EXCEPTION OF GETTING SEQUENCE HEADING IN STORE PROPERTY VALUE  CASE STATMENT");
									}//END OF CATCH
									try
									{
										ls_window=GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 1);
									}catch(Exception e)
									{
										LOG.error("EXCEPTION OF GETTING WINDOW IN STORE PROPERTY VALUE  CASE STATMENT");
									}//END OF CATCH

									/*try{
										Set_Property  set_pro_object = new Set_Property();
										set_pro_object.SET_PROPERTY(scr_driver, ls_Parameter, ls_Objvalue, ls_Seq_heading);
									}
									catch(Exception e)
									{
										LOG.error("EXCEPTION in calling set property function");
									}*/
									
									try
									{
										//sleep remove
										////Muthu-Thread.sleep(1000);
										ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5).trim();
									}catch(Exception e)
									{
										LOG.error("EXCEPTION OF GETTING TC1 IN STORE PROPERTY VALUE  CASE STATMENT");
									}

									ls_errorarray = ls_TC1value.split("\\|");
									ls_property = ls_errorarray[0];
									ls_optionflag = ls_errorarray[1];

									
									try
									{
										//calling Generic library function to switch to new window
										GenericLibrary.shiftContrlToParentWindow(scr_driver, ls_property);

									}catch(Exception e)
									{
										LOG.error("EXCEPTION OF CALLING GENERIC LIBRARY class FUNCTION");
									}
								}
							}
							
						}catch(Exception e)
					{
							LOG.error("Exception Setproperty case statement in ScreenDriver Function");
						}

					}//if of li_input 
					else
					{
						lb_inputvaluescompleted = true;
					}

					

					break;  // SWITCH_TO_OLD_WINDOW

				case "SWITCH_TO_NEW_WINDOW":
					
					if (li_input <=  li_inputparamvalue)   
					{ 
						try
						{
						for (int li_loopinputparamvalue= 0;li_loopinputparamvalue<=li_inputparamvalue;li_loopinputparamvalue++)
							{       

								ls_Parameter= input_key_lst.get(li_loopinputparamvalue);
								ls_Objvalue =input_value_lst.get(li_loopinputparamvalue);

								if ( ls_windowObj.trim().equalsIgnoreCase(ls_Parameter.trim()))
								{

									try
									{
										ls_Seq_heading = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 4);
									}catch(Exception e)
									{
										LOG.error("EXCEPTION OF GETTING SEQUENCE HEADING IN STORE PROPERTY VALUE  CASE STATMENT");
									}//END OF CATCH
									try
									{
										ls_window=GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 1);
									}catch(Exception e)
									{
										LOG.error("EXCEPTION OF GETTING WINDOW IN STORE PROPERTY VALUE  CASE STATMENT");
									}//END OF CATCH

									/*try{
										Set_Property  set_pro_object = new Set_Property();
										set_pro_object.SET_PROPERTY(scr_driver, ls_Parameter, ls_Objvalue, ls_Seq_heading);
									}
									catch(Exception e)
									{
										LOG.error("EXCEPTION in calling set property function");
									}*/
									
									try
									{
										ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5).trim();
									}catch(Exception e)
									{
										LOG.error("EXCEPTION OF GETTING TC1 IN STORE PROPERTY VALUE  CASE STATMENT");
									}

									ls_errorarray = ls_TC1value.split("\\|");
									ls_property = ls_errorarray[0];
									ls_optionflag = ls_errorarray[1];

									
									try
									{
										//calling Generic library function to switch to new window
										//sleep remove
										////Muthu-Thread.sleep(3000);
										GenericLibrary.shiftContrlToChildWindow(scr_driver,ls_property);

									}catch(Exception e)
									{
										LOG.error("EXCEPTION OF CALLING GENERIC LIBRARY class FUNCTION");
									}//END OF CATCH
								}
							}
							
						}catch(Exception e)
					{
							LOG.error("Exception Setproperty case statement in ScreenDriver Function");
						}

					}//if of li_input 
					else
					{
						lb_inputvaluescompleted = true;
					}

					break;  // SET_PROPERTY
					
				
					//added by Abhijit
					
				case "SWITCH_TO_PDFNEW_WINDOW":
					if (li_input <=  li_inputparamvalue)   
					{ 
						try
						{
						for (int li_loopinputparamvalue= 0;li_loopinputparamvalue<=li_inputparamvalue;li_loopinputparamvalue++)
							{       

								ls_Parameter= input_key_lst.get(li_loopinputparamvalue);
								ls_Objvalue =input_value_lst.get(li_loopinputparamvalue);

								if ( ls_windowObj.trim().equalsIgnoreCase(ls_Parameter.trim()))
								{

									try
									{
										ls_Seq_heading = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 4);
									}catch(Exception e)
									{
										LOG.error("EXCEPTION OF GETTING SEQUENCE HEADING IN STORE PROPERTY VALUE  CASE STATMENT");
									}//END OF CATCH
									try
									{
										ls_window=GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 1);
									}catch(Exception e)
									{
										LOG.error("EXCEPTION OF GETTING WINDOW IN STORE PROPERTY VALUE  CASE STATMENT");
									}//END OF CATCH

									/*try{
										Set_Property  set_pro_object = new Set_Property();
										set_pro_object.SET_PROPERTY(scr_driver, ls_Parameter, ls_Objvalue, ls_Seq_heading);
									}
									catch(Exception e)
									{
										LOG.error("EXCEPTION in calling set property function");
									}*/
									
									try
									{
										ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5).trim();
									}catch(Exception e)
									{
										LOG.error("EXCEPTION OF GETTING TC1 IN STORE PROPERTY VALUE  CASE STATMENT");
									}

									ls_errorarray = ls_TC1value.split("\\|");
									ls_property = ls_errorarray[0];
									ls_optionflag = ls_errorarray[1];

									
									try
									{
										//calling Generic library function to switch to new window
										if(ls_windowObj.contains("Save"))
										{
											GenericLibrary.savePdfWindow(scr_driver,ls_property);
										}
										else
										{
											GenericLibrary.shiftContrlToPdfWindow(scr_driver,ls_property);
										}

									}catch(Exception e)
									{
										LOG.error("EXCEPTION OF CALLING GENERIC LIBRARY class FUNCTION");
									}//END OF CATCH
								}
							}
							
						}catch(Exception e)
						{
							LOG.error("Exception Setproperty case statement in ScreenDriver Function");
						}

					}//if of li_input 
					else
					{
						lb_inputvaluescompleted = true;
					}

					break;  // SET_PROPERTY
					
					
				case "SWITCH_TO_PDF_WINDOW":
					if (li_input <=  li_inputparamvalue)   
					{ 
						try
						{
						for (int li_loopinputparamvalue= 0;li_loopinputparamvalue<=li_inputparamvalue;li_loopinputparamvalue++)
							{       

								ls_Parameter= input_key_lst.get(li_loopinputparamvalue);
								ls_Objvalue =input_value_lst.get(li_loopinputparamvalue);

								if ( ls_windowObj.trim().equalsIgnoreCase(ls_Parameter.trim()))
								{

									try
									{
										ls_Seq_heading = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 4);
									}catch(Exception e)
									{
										LOG.error("EXCEPTION OF GETTING SEQUENCE HEADING IN STORE PROPERTY VALUE  CASE STATMENT");
									}//END OF CATCH
									try
									{
										ls_window=GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 1);
									}catch(Exception e)
									{
										LOG.error("EXCEPTION OF GETTING WINDOW IN STORE PROPERTY VALUE  CASE STATMENT");
									}//END OF CATCH

									/*try{
										Set_Property  set_pro_object = new Set_Property();
										set_pro_object.SET_PROPERTY(scr_driver, ls_Parameter, ls_Objvalue, ls_Seq_heading);
									}
									catch(Exception e)
									{
										LOG.error("EXCEPTION in calling set property function");
									}*/
									
									try
									{
										ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5).trim();
									}catch(Exception e)
									{
										LOG.error("EXCEPTION OF GETTING TC1 IN STORE PROPERTY VALUE  CASE STATMENT");
									}

									ls_errorarray = ls_TC1value.split("\\|");
									ls_property = ls_errorarray[0];
									ls_optionflag = ls_errorarray[1];

									
									try
									{
										//calling Generic library function to switch to new window
										GenericLibrary.shiftContrlToPdfCurrentWindow(scr_driver,ls_property);

									}catch(Exception e)
									{
										LOG.error("EXCEPTION OF CALLING GENERIC LIBRARY class FUNCTION");
									}//END OF CATCH
								}
							}
							
						}catch(Exception e)
						{
							LOG.error("Exception Setproperty case statement in ScreenDriver Function");
						}

					}//if of li_input 
					else
					{
						lb_inputvaluescompleted = true;
					}

					break;  // SET_PROPERTY

				//added by Yathish	
				/*case "SWITCH_TO_OLD_WINDOW":
					GenericLibrary.shiftContrlToParentWindow(scr_driver);
					LOG.info("Control shifted to Parent window");
					break;
					
					LOG.info("SWITCH_TO_OLD_WINDOW");
					
					;
					if (li_input <=  li_inputparamvalue)   
					{ 
						try
						{
							for (int li_loopinputparamvalue= 0;li_loopinputparamvalue<=li_inputparamvalue;li_loopinputparamvalue++)
							{       

								ls_Parameter= input_key_lst.get(li_loopinputparamvalue);
								ls_Objvalue =input_value_lst.get(li_loopinputparamvalue);

								if ( ls_windowObj.trim().equalsIgnoreCase(ls_Parameter.trim()))
								{

									try
									{
										ls_Seq_heading = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 4);
									}catch(Exception e)
									{
										LOG.error("EXCEPTION OF GETTING SEQUENCE HEADING IN STORE PROPERTY VALUE  CASE STATMENT");
									}//END OF CATCH
									try
									{
										ls_window=GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 1);
									}catch(Exception e)
									{
										LOG.error("EXCEPTION OF GETTING WINDOW IN STORE PROPERTY VALUE  CASE STATMENT");
									}//END OF CATCH

									try{
										Set_Property  set_pro_object = new Set_Property();
										set_pro_object.SET_PROPERTY(scr_driver, ls_Parameter, ls_Objvalue, ls_Seq_heading);
									}
									catch(Exception e)
									{
										LOG.error("EXCEPTION in calling set property function");
									}
									
									try
									{
										ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5).trim();
									}catch(Exception e)
									{
										LOG.error("EXCEPTION OF GETTING TC1 IN STORE PROPERTY VALUE  CASE STATMENT");
									}

									ls_errorarray = ls_TC1value.split("\\|");
									ls_property = ls_errorarray[0];
									ls_optionflag = ls_errorarray[1];

									
									try
									{
										//calling Generic library function to switch to new window
										GenericLibrary.shiftContrlToParentWindow(scr_driver, ls_property);

									}catch(Exception e)
									{
										LOG.error("EXCEPTION OF CALLING GENERIC LIBRARY class FUNCTION");
									}//END OF CATCH
								}
							}
							
						}catch(Exception e)
						{
							LOG.error("Exception Setproperty case statement in ScreenDriver Function");
						}

					}//if of li_input 
					else
					{
						lb_inputvaluescompleted = true;
					}

					break;  // SET_PROPERTY
*/
//					
//				case "MOUSE_HOVER":
//					
//					WebElement Claim = scr_driver.findElement(By.)
//					
//					break;
//					
					
							
				case "SWITCH_TO_FRAME":
					
					
					try
					{
						ls_cmd = GenericLibrary.getExcelData(filepath, ls_excel_sheet,excel_loop, 5);//storing the equivalen command like setproperty/check object exist/checkapp message for particular object
					}catch(Exception e)
					{
						LOG.error("the valuae of command is null ");
					}//end of catch stmt

					
					
					ls_errorarray = ls_cmd.split("\\|");
					ls_property = ls_errorarray[0];
					ls_optionflag = ls_errorarray[1];
					
					try
					{
									SwitchToForm frame = new SwitchToForm();

									frame.SwitchForm(scr_driver,ls_property );

					}catch(Exception e)
					{
						LOG.error("the valuae of command is null ");
					}//end of catch stmt		



				/*	scr_driver.switchTo().defaultContent();
					WebElement ele = scr_driver.findElement(By.id("top_frame"));
					scr_driver.switchTo().frame(ele);*/
					

					break;
					
				case "SWITCH_TO_IFRAME":
					ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5).trim();
					WebElement frame;
					String ls_ElementLocator, ls_ElementVal;
					try {
						ls_errorarray = ls_TC1value.split("\\|");
						ls_ElementVal = ls_errorarray[0];
						ls_ElementLocator = ls_errorarray[1];
					} catch (Exception e) {
						ls_ElementVal = ls_TC1value;
						ls_ElementLocator = "id";
					} // end of catch
					try {
						// Below switch stmt added by shanmugakumar N - 09 Feb 18
						switch (ls_ElementLocator) {
						case "id":
							frame = scr_driver.findElement(By.xpath("//*[contains(@id,'" + ls_ElementVal + "')]"));
							break;
						case "name":
							frame = scr_driver.findElement(By.name(ls_ElementVal));
							break;
						case "xpath":
							frame = scr_driver.findElement(By.xpath(ls_ElementVal));
							break;
						case "classname":
							frame = scr_driver.findElement(By.className(ls_ElementVal));
							break;
						case "linktext":
							frame = scr_driver.findElement(By.linkText(ls_ElementVal));
							break;
						default:
							frame = scr_driver.findElement(By.id(ls_ElementVal));
							break;
						}// end of switch

						scr_driver.switchTo().frame(frame);
						//sleep remove
						////Muthu-Thread.sleep(500);
						ls_Msg = "The control has been shifted  to IFrame  Successfully";
						ls_status = "Pass";
						LOG.info("The driver control is Successfully switched to IFrame");
					} catch (Exception e1) {
						ls_Msg = "Unable to Shift the control  to IFrame ";
						ls_status = "Fail";
					} // catch
					break;
					
				case "SWITCH_TO_DEFAULT":
					try {
						scr_driver.switchTo().defaultContent();
						ls_Msg = "The control is shifted to Default Content Successfully";
						ls_status = "Pass";
					} catch (Exception e) {
						ls_Msg = "Unable to Shift the control  to Default Content ";
						ls_status = "Fail";
					} // end of catch
					break;
				case"SWITCH_TO_IFRAMEI":
					/*System.out.println("Switching to i frame");
					WebElement frame = scr_driver.findElement(By.id("ileft"));
					//scr_driver.switchTo().defaultContent();
					scr_driver.switchTo().frame(frame);
					//scr_driver.switchTo().frame("addDocument0");
					System.out.println("Switch to i frame");*/
					scr_driver.switchTo().defaultContent();
					scr_driver.switchTo().frame(0);
					break;
					
				case "SWITCH_TO_CHILDWINDOW":
					
					try
					{
						handle = scr_driver.getWindowHandle();	//Getting the Parent window handle
					}catch(Exception e)
					{
						LOG.error("Not able to get the handle of the window in Generic library function");		
					}//END OF CATCH STMT
					
					try
					{
						handles = scr_driver.getWindowHandles();// To get both parent and child window handle
					}catch(Exception e)
					{
						LOG.error("Not able to get the multiple  window Handle in Generic library function");		
					}//END OF CATCH
					
					Iterator<String> windowIterator = handles.iterator();
					
					 while(windowIterator.hasNext()) 
					 { 
					    String windowHandle = windowIterator.next(); 
					    		   
					    if (!windowHandle.equals(handle))
					    {
					    	try
					    	{
					    		ScreenDriver.popup_driver = scr_driver.switchTo().window(windowHandle);
					    		scr_driver.manage().window().maximize();
					    	}catch(Exception e)
					    	{
					    		LOG.error("UNABLE TO SHIFT THE CONTROL CHILD WINDOW IN GENERIC LIBRARY FUNCTION");
					    	}
							 break;
					    }//IF OF WINDOW HANDLE
					  
					  }//WHILE STMT		
				
				
				break;
				
				
			case "SWITCH_TO_MAINWINDOW":
				try
				{
					handle = scr_driver.getWindowHandle();
					scr_driver = ScreenDriver.popup_driver.switchTo().window(handle);
				}catch(Exception e)
				{
					LOG.error("UNABLE TO SHIFT THE CONTROL PARENT WINDOE IN GENERIC LIBRARY FUNCTION");
				}
				break;
				 
		

			case "SWITCH_TO_WINDOWNAME":
					
					ls_errorarray = ls_TC1value.split("\\|");
					ls_property = ls_errorarray[0];
					ls_optionflag = ls_errorarray[1];
					//sleep remove
					////Muthu-Thread.sleep(2000);
					/*scr_driver.get("www.google.com");
					//Muthu-Thread.sleep(2000);
					scr_driver.get("www.yahoo.com");*/
					// Store the current window handle- the parent one
					String winHandleBefore = scr_driver.getWindowHandle();
					// store all the windows 
					Set<String> handle= scr_driver.getWindowHandles();
					System.out.println("Count of windows:"+handle.size());
					//String titlewin;
					// iterate over window handles
					
					for(String mywindows : handle){
					// store window title
					 
						//titlewin = scr_driver.switchTo().window(mywindows).getTitle();
					 // now apply the condition - moving to the window with blank title
					  if(scr_driver.switchTo().window(mywindows).getTitle().contains("Producer")){
					  // perform some action - as here m openning a new url
						scr_driver.switchTo().window(mywindows);
						break;
					}
					}
					break;
				case "SWITCH_TO_WINDOWNotif":
					
					ls_errorarray = ls_TC1value.split("\\|");
					ls_property = ls_errorarray[0];
					ls_optionflag = ls_errorarray[1];
					//sleep remove
					////Muthu-Thread.sleep(2000);
					/*scr_driver.get("www.google.com");
					//Muthu-Thread.sleep(2000);
					scr_driver.get("www.yahoo.com");*/
					// Store the current window handle- the parent one
					String winHandleBefore1 = scr_driver.getWindowHandle();
					// store all the windows 
					Set<String> handle1= scr_driver.getWindowHandles();
					System.out.println("Count of windows:"+handle1.size());
					//String titlewin;
					// iterate over window handles
					
					for(String mywindows : handle1){
					// store window title
					 
						//titlewin = scr_driver.switchTo().window(mywindows).getTitle();
					 // now apply the condition - moving to the window with blank title
					  if(scr_driver.switchTo().window(mywindows).getTitle().contains("Notif")){
					  // perform some action - as here m openning a new url
						scr_driver.switchTo().window(mywindows);
						break;
					}
					}
					break;
					
				case "DOCUMENT_VALIDATION":
					try {
						ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5).trim();
					} catch (Exception e) {
						ls_Msg = "EXCEPTION TO GET THE VALUE FROM SCREEN COMPONENT EXCL IN ISENABLED CASE STATMENT";
						ls_status = "Fail";
						LOG.error(ls_Msg);
					} // END OF CATCH
					ls_errorarray = ls_TC1value.split("\\|");
					ls_objectname = ls_errorarray[0];
					ls_optionflag = ls_errorarray[1];

					Document_Validation obj_doc = new Document_Validation();
					obj_doc.DOCUMENT_VALIDATION();
					break;

				case "ISENABLED":
					try {
						ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5).trim();
					} catch (Exception e) {
						ls_Msg = "EXCEPTION TO GET THE VALUE FROM SCREEN COMPONENT EXCL IN ISENABLED CASE STATMENT";
						ls_status = "Fail";
						LOG.error(ls_Msg);
					} // END OF CATCH
					ls_errorarray = ls_TC1value.split("\\|");
					ls_objectname = ls_errorarray[0];
					ls_optionflag = ls_errorarray[1];

					Check_Object_Enabled ls_check = new Check_Object_Enabled();
					ls_check.CHECK_OBJECT_ENABLED(ls_objectname);
					break;
				case "ISDISABLED":
					try {
						ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5).trim();
					} catch (Exception e) {
						ls_Msg = "EXCEPTION TO GET THE VALUE FROM SCREEN COMPONENT EXCL IN ISENABLED CASE STATMENT";
						ls_status = "Fail";
						LOG.error(ls_Msg);
					} // END OF CATCH
					ls_errorarray = ls_TC1value.split("\\|");
					ls_objectname = ls_errorarray[0];
					ls_optionflag = ls_errorarray[1];

					
					Get_Object_Identifier gui_object= new Get_Object_Identifier();
					
					//Getting WebDriver Control to perform action
					 WebDriver driver = Browser_Invoke_Url.driver;
					 
					 boolean lb_exist =false;
					 //String optional_ERR_FLAG=null;
					 WebElement element=null;
					
					//Identifying the object
					
						try {
							////Muthu-Thread.sleep(10000);
							element =	gui_object.GET_OBJECT_IDENTIFIER(driver, ls_objectname,null, optional_ERR_FLAG); 
							
						
						}
						catch(Exception qweqwe)
						{
							
						}
						
						if(!element.isEnabled())
						{
							lb_exist=true;
							ls_Msg="The Object is Not Enabled";
							ls_status="Pass";
						}
						else
						{
							
							ls_Msg="The Object is Enabled";
							ls_status="Failed";
						}
						
					break;
				// Added by Shan on 06/07/2018 t0 handle File upload
				case "AutoIT_FileHandling":
					/*
					 * try { ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet,
					 * excel_loop, 5).trim(); AutoIT_FileHandling objFileHandling = new
					 * AutoIT_FileHandling(); String FileAction,UploadFileName,DownloadFileName;
					 * if(ls_TC1value.contains("Upload")) { ls_errorarray =
					 * ls_TC1value.split("\\|"); FileAction = ls_errorarray[0]; UploadFileName =
					 * ls_errorarray[1]; ls_optionflag =ls_errorarray[2];
					 * objFileHandling.AutoIT_FileUpload(UploadFileName); } else
					 * if(ls_TC1value.contains("Download")) { ls_errorarray =
					 * ls_TC1value.split("\\|"); FileAction = ls_errorarray[0]; DownloadFileName =
					 * ls_errorarray[1]; ls_optionflag =ls_errorarray[2];
					 * objFileHandling.AutoIT_FileDownload(DownloadFileName); }//end of if
					 * }catch(Exception e) {
					 * ls_Msg="EXCEPTION IN AutoIT_FileHandling CASE STATMENT"; ls_status="Fail";
					 * LOG.error(ls_Msg); }//END OF CATCH
					 */ break;
				// Added by Shanmugakumar N - 06 Feb 18
				case "SWITCH_TO_PARENTWINDOW":
					try {
						ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5);
						// below statements added for to split optional flag and input action -
						// shanmugakumar - 06/02/18
						ls_errorarray = ls_TC1value.split("\\|");
						String ls_wait, ls_optional_flag;
						ls_wait = ls_errorarray[0];
						ls_optional_flag = ls_errorarray[1];

						int li_wait = Integer.parseInt(ls_wait);
						//Muthu-Thread.sleep(li_wait * 500);
						GenericLibrary.shiftContrlToParentWindow(popup_driver);
					} catch (Exception e) {
						ls_Msg = "Unable to Shift the control  to Parent Window ";
						ls_status = "Fail";
					} // catch
					break;

				// Added by Shanmugakumar N - 11 Apr 18
				case "QGLOBAL_LOGIN_RESET":
					try {
						String loginHeader = scr_driver.findElement(By.id("loginHeader")).getText();
						if (loginHeader.equals("Pick an account")) {
							scr_driver.findElement(By.xpath("//div[@class='table-cell tile-menu']/div/img")).click();
							scr_driver.findElement(By.id("forgetLink")).click();
						} // end of if
					} catch (Exception e) {
						ls_Msg = "Unable to perform ";
					} // catch
					break;

				// Added by Shanmugakumar N - 01 Jun 18
				case "PEGA_Attachment_Refresh":
					for (int i = 1; i < 30; i++) {
						try {
							scr_driver.findElement(By.xpath("//i[@class=' icons pi pi-refresh pi-link']")).click();
							//Muthu-Thread.sleep(1000);
							ele_objectname = scr_driver.findElement(By.xpath("//div/h2[text()='Pending Documents']"));
						} catch (Exception e) {
							break;
						} // catch
					} // end of for
					break;

				// Added by Shanmugakumar N - 05 Jun 18
				case "FireFox_PegaODM_Login":
					String browser = null;
					browser = Harness.gs_Browser;
					try {
						scr_driver.navigate().refresh();
						//Muthu-Thread.sleep(1000);
						if (browser.equalsIgnoreCase("FireFox")) {
							scr_driver.findElement(By.id("username::content")).sendKeys("DEIVAA");
							scr_driver.findElement(By.id("password::content")).sendKeys("Aswin@2204");
							scr_driver.findElement(By.xpath("//div[@id='loginButton']/a")).click();
						} // end of if
					} catch (Exception e) {
						System.out.println("unable to identified");
					} // catch
					break;

				case "MSDynamic_Close":
					try {
						WebElement frame1 = scr_driver.findElement(By.id("InlineDialog_Iframe"));
						scr_driver.switchTo().frame(frame1);
						String MSDynamic = scr_driver.findElement(By.xpath("//div[@class='navTourTitleText']"))
								.getText();
						if (MSDynamic.equals("Explore Dynamics 365")) {
							scr_driver.findElement(By.id("navTourCloseButtonImage")).click();
						} // end of if
						scr_driver.switchTo().defaultContent();
					} catch (Exception e) {
						ls_Msg = "Unable to perform ";
					} // catch
					break;
				
					
				
				case "ODM_TABLE":
					try {
						if (li_input <= li_inputparamvalue) {
							if ((li_input == li_inputparamvalue) && (Harness.gs_Screenshot.equalsIgnoreCase("Yes"))) {
								Screenshot(scr_driver, ls_window);
							}
							for (int li_loopinputparamvalue = 0; li_loopinputparamvalue <= li_inputparamvalue; li_loopinputparamvalue++) {
								ls_Parameter = input_key_lst.get(li_loopinputparamvalue);
								ls_Objvalue = input_value_lst.get(li_loopinputparamvalue);
								if (ls_windowObj.trim().equalsIgnoreCase(ls_Parameter.trim())) {
									obj_found = true;
									ls_Seq_heading = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop,
											4);
									ls_window = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 1);
									ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5);

									ls_errorarray = ls_TC1value.split("\\|");
									String ls_rownum = ls_errorarray[0];
									String ls_columnum = ls_errorarray[1];
									String ls_TagName = ls_errorarray[2];
									ODM_TABLE ls_tableobj = new ODM_TABLE();
									if (!ls_Objvalue.equalsIgnoreCase("None"))// Added by Ambika to skip the object
																				// having None value on 13/3/2017
									{
										if (popup_driver != null) {
											try {
												ls_tableobj.lfn_ODM_TABLE(popup_driver, ls_Parameter, ls_rownum,
														ls_columnum, ls_TagName);
											} catch (Exception e) {
												/*
												 * ls_Msg="Exception in calling Set property function with PopUp driver"
												 * ; ls_status="Fail";
												 */
											} // end of catch
										} else {
											try {
												ls_tableobj.lfn_ODM_TABLE(scr_driver, ls_Parameter, ls_rownum,
														ls_columnum, ls_TagName);
											} catch (Exception e) {/*
																	 * LOG.
																	 * error("Exception of calling setproperty function with ScreenDriver"
																	 * );
																	 * ls_Msg="Exception in calling Set property function with Screen driver"
																	 * ; ls_status="Fail";
																	 */
											} // end of catch statment

										} // else
									} // if of None
									li_input = li_input + 1;
									if (li_input > li_inputparamvalue) {
										lb_inputvaluescompleted = true;
										ls_cmd = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop + 1,
												3);
										if (ls_cmd == null)
											lb_popupcheck = true;
									} // if for lb_inputvaluescompleted
									break; // for input parameter exhaustion

								} // if for compare ls_windowObj and ls_Parameter
							} // for of input parameter
						} else {
							lb_inputvaluescompleted = true;
						} // end of else
					} catch (Exception e) {
						LOG.error("Exception Setproperty case statement in ScreenDriver Function");
						ls_Msg = "Exception Setproperty case statement in ScreenDriver Function";
						ls_status = "Fail";
					} // end of catch
					break;

				// Added by shan - To download files from ODM and store in zip format - 04-07-18
				case "ODM_ADD_DOWNLOAD_BASKET":
					try {
						if (li_input <= li_inputparamvalue) {
							if ((li_input == li_inputparamvalue) && (Harness.gs_Screenshot.equalsIgnoreCase("Yes"))) {
								Screenshot(scr_driver, ls_window);
							}
							for (int li_loopinputparamvalue = 0; li_loopinputparamvalue <= li_inputparamvalue; li_loopinputparamvalue++) {
								ls_Parameter = input_key_lst.get(li_loopinputparamvalue);
								ls_Objvalue = input_value_lst.get(li_loopinputparamvalue);
								if (ls_windowObj.trim().equalsIgnoreCase(ls_Parameter.trim())) {
									obj_found = true;
									ls_Seq_heading = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop,
											4);
									ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5);
									// below statements added for to split optional flag and input action -
									// shanmugakumar - 06/02/18
									ls_errorarray = ls_TC1value.split("\\|");
									String ls_input_action, ls_optional_flag;
									ls_input_action = ls_errorarray[0];
									ls_optional_flag = ls_errorarray[1];

									ls_window = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 1);
									ODM_ADD_DOWNLOAD_BASKET obj_DOWNLOAD_BASKET = new ODM_ADD_DOWNLOAD_BASKET();
									if (!ls_Objvalue.equalsIgnoreCase("None"))// Added by Ambika to skip the object
																				// having None value on 13/3/2017
									{
										if (popup_driver != null) {
											try {
												// new parameter(ls_input_action) added - shanmugakumar - 06/02/18
												obj_DOWNLOAD_BASKET.ODM_AddDocToBasket(popup_driver, ls_window,
														ls_Parameter, ls_Objvalue, ls_optional_flag);
											} catch (Exception e) {
												/*
												 * ls_Msg="Exception in calling Set property function with PopUp driver"
												 * ; ls_status="Fail";
												 */
											} // end of catch
										} else {
											try {
												obj_DOWNLOAD_BASKET.ODM_AddDocToBasket(scr_driver, ls_window,
														ls_Parameter, ls_Objvalue, ls_optional_flag);
											} catch (Exception e) {/*
																	 * LOG.
																	 * error("Exception of calling setproperty function with ScreenDriver"
																	 * );
																	 * ls_Msg="Exception in calling Set property function with Screen driver"
																	 * ; ls_status="Fail";
																	 */
											} // end of catch statment
										} // else
									} // if of None
									li_input = li_input + 1;
									if (li_input > li_inputparamvalue) {
										lb_inputvaluescompleted = true;
										ls_cmd = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop + 1,
												3);
										if (ls_cmd == null)
											lb_popupcheck = true;
									} // if for lb_inputvaluescompleted
									break; // for input parameter exhaustion
								} // if for compare ls_windowObj and ls_Parameter
							} // for of input parameter
						} else {
							lb_inputvaluescompleted = true;
						} // end of else
					} catch (Exception e) {
						LOG.error("Exception ODM_ADD_DOWNLOAD_BASKET case statement in ScreenDriver Function");
						ls_Msg = "Exception ODM_ADD_DOWNLOAD_BASKET case statement in ScreenDriver Function";
						ls_status = "Fail";
					} // end of catch
					break;
				case "STORE_RUNTIME_VALUE":
					if (ls_windowObj.equalsIgnoreCase("GWCCPartiesInvolved_textingContact_0_claimnumber_label")) {
						System.out.println(ls_windowObj);
					}

					try {
						if (li_input <= li_inputparamvalue) {
							if ((li_input == li_inputparamvalue) && (Harness.gs_Screenshot.equalsIgnoreCase("Yes"))) {
								Screenshot(scr_driver, componentname);
							}

							for (int li_loopinputparamvalue = 0; li_loopinputparamvalue <= li_inputparamvalue; li_loopinputparamvalue++) {

								ls_Parameter = input_key_lst.get(li_loopinputparamvalue);// Test Case input key list
								ls_Objvalue = input_value_lst.get(li_loopinputparamvalue);// Test case value list

								if (ls_windowObj.replaceAll("\n", "").trim().equalsIgnoreCase(ls_Parameter.trim())) {
									if (!ls_Objvalue.equalsIgnoreCase(defs.noActionvalue)) {
										obj_found = true;

										try {
											ls_Seq_heading = GenericLibrary.getExcelData(filepath, ls_excel_sheet,
													li_loopinputparamvalue, 4);
											ls_window = GenericLibrary.getExcelData(filepath, ls_excel_sheet,
													li_loopinputparamvalue, 1);
											ls_TC1value = GenericLibrary
													.getExcelData(filepath, ls_excel_sheet, excel_loop, 5).trim();

										} catch (Exception e) {
											ls_Msg = "Unable to Read the Excl in Check_Property VAlue";
											ls_status = "Fail";
											LOG.error("unable to read the Excel in Check_Property_Value ");
										}

										ls_errorarray = ls_TC1value.split("\\|");
										int li_check = ls_errorarray.length;
										ls_property = ls_errorarray[0];
										String ls_FieldName = ls_errorarray[1];
										String subObjecValue = ls_Objvalue.substring(0, 4);
										try {
											if (ls_Objvalue.substring(0, 4).equalsIgnoreCase("run_")
													&& run.initilized) {
												WebElement valueElement = ls_obj.GET_OBJECT_IDENTIFIER(scr_driver,
														ls_Parameter.replaceAll("\n", ""), null, optional_ERR_FLAG);
												String value = valueElement.getText();

												if (ls_Objvalue.contains("claim")) {
													value = value.replace("Claim (", "");
													value = value.replace(")", "");
													run.insertValue(ls_Objvalue, value);
													System.out.println(run.getTheMap());
												} else {
													run.insertValue(ls_Objvalue, value);
													System.out.println(run.getTheMap());
												}
												lb_script_Continue = true;
											}
										} catch (Exception e1) {
											// TODO Auto-generated catch block
											e1.printStackTrace();
											lb_script_Continue = false;
										}

										if (!lb_script_Continue) {
											break;
										}
									} // if of None
									else if (ls_Objvalue.equalsIgnoreCase(defs.noActionvalue)) {
										// li_input=li_input+1;
										// break;
									}

									li_input = li_input + 1;
									if (li_input > li_inputparamvalue) {
										lb_inputvaluescompleted = true;

										ls_cmd = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop + 1,
												3);
										if (ls_cmd == null)
											lb_popupcheck = true;
									} // if for lb_inputvaluescompleted
									break;

								}
							} // for input parameter exhaustion

						} else {
							lb_inputvaluescompleted = true;
						}
					} catch (Exception e) {
						LOG.error("Exception Setproperty case statement in ScreenDriver Function");
						ls_Msg = "Exception Setproperty case statement in ScreenDriver Function";
						ls_status = "Fail";
					}
					break;
				case "SET_PROPERTY":
					
					if(ls_windowObj.equalsIgnoreCase("GWCCPartiesInvolved_textingContact_0_table_name_label1"))
					{
						System.out.println("Debugging");
					}
					try {
						if (li_input <= li_inputparamvalue) {
							if ((li_input == li_inputparamvalue) && (Harness.gs_Screenshot.equalsIgnoreCase("Yes"))) {
								Screenshot(scr_driver, componentname);
							}

							for (int li_loopinputparamvalue = 0; li_loopinputparamvalue <= li_inputparamvalue; li_loopinputparamvalue++) {

								ls_Parameter = input_key_lst.get(li_loopinputparamvalue).replaceAll("\n", "");// Test Case input key list
								ls_Objvalue = input_value_lst.get(li_loopinputparamvalue).replaceAll("\n", "");// Test case value list

								if (ls_windowObj.trim().equalsIgnoreCase(ls_Parameter.trim())) {
									obj_found = true;

									
									try{
				  						if(ls_Objvalue.substring(0, 4).equalsIgnoreCase("run_") && run.initilized)
				  						{
				  							ls_Objvalue=run.getTheValue(ls_Objvalue);
				  						}
				  						else if(ls_Objvalue.substring(0,4).equalsIgnoreCase("get_") && run.initilized)
				  						{
				  							ls_Objvalue=ls_Objvalue.substring(ls_Objvalue.indexOf("_")+1, ls_Objvalue.length());
				  							ls_Objvalue=run.getTheValue(ls_Objvalue);
				  						}
				  						else
				  						{
				  							//ls_Objvalue=ls_Objvalue;
				  						}
			  						}catch(Exception exe)
			  						{
			  							System.out.println("Exception in Test data check for Run time validation");
			  							//ls_Objvalue=ls_Objvalue;
			  						}
			  						
									ls_Seq_heading = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop,
											4);
									ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5);
									// below statements added for to split optional flag and input action -
									// shanmugakumar - 06/02/18
									ls_errorarray = ls_TC1value.split("\\|"); // For ex Click|Y
									String ls_input_action, ls_optional_flag;
									ls_input_action = ls_errorarray[0]; // click
									ls_optional_flag = ls_errorarray[1]; // y

									ls_window = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 1);
									Set_Property set_pro_object = new Set_Property();
									if (!ls_Objvalue.equalsIgnoreCase("None"))// Added by Ambika to skip the object
																				// having None value on 13/3/2017
									{

										if (popup_driver != null) {
											try {
												// new parameter(ls_input_action) added - shanmugakumar - 06/02/18
												lb_script_Continue = set_pro_object.SET_PROPERTY(popup_driver,
														ls_window, ls_Parameter, ls_Objvalue, ls_input_action,
														ls_optional_flag);
											} catch (Exception e) {
												lb_script_Continue = false;
											}
										} else {
											try {
												lb_script_Continue = set_pro_object.SET_PROPERTY(scr_driver, ls_window,
														ls_Parameter, ls_Objvalue, ls_input_action, ls_optional_flag);
											} catch (Exception e) {
												System.out.println(e);
												lb_script_Continue = false;
											} // end of catch statment

										} // else
											// added by shan
										if (!lb_script_Continue) {
											break;
										}
									} // if of None

									li_input = li_input + 1;
									if (li_input > li_inputparamvalue) {
										lb_inputvaluescompleted = true;

										ls_cmd = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop + 1,
												3);
										if (ls_cmd == null)
											lb_popupcheck = true;
									} // if for lb_inputvaluescompleted
									break; // for input parameter exhaustion

								} // if for compare ls_windowObj and ls_Parameter

							} // for of input parameter

						} // if of li_input
						else {
							lb_inputvaluescompleted = true;
						}
					} catch (Exception e) {
						LOG.error("Exception Setproperty case statement in ScreenDriver Function");
						ls_Msg = "Exception Setproperty case statement in ScreenDriver Function";
						ls_status = "Fail";
					}
					break;

				/*
				 * case "SET_PROPERTY": try { if (li_input <= li_inputparamvalue) { if(
				 * (li_input ==
				 * li_inputparamvalue)&&(Harness.gs_Screenshot.equalsIgnoreCase("Yes"))) {
				 * Screenshot(scr_driver, componentname); }
				 * 
				 * for (int li_loopinputparamvalue=
				 * 0;li_loopinputparamvalue<=li_inputparamvalue;li_loopinputparamvalue++) {
				 * 
				 * ls_Parameter= input_key_lst.get(li_loopinputparamvalue).replaceAll("\n",
				 * "").trim();//Test Case input key list ls_Objvalue
				 * =input_value_lst.get(li_loopinputparamvalue).replaceAll("\n",
				 * "").trim();//Test case value list
				 * 
				 * if ( ls_windowObj.replaceAll("\n",
				 * "").trim().equalsIgnoreCase(ls_Parameter.trim())) {
				 * if(!ls_Objvalue.equalsIgnoreCase(defs.noActionvalue)) { obj_found=true;
				 * 
				 * try{ if(ls_Objvalue.substring(0, 4).equalsIgnoreCase("run_") &&
				 * run.initilized) { ls_Objvalue=run.getTheValue(ls_Objvalue); } else
				 * if(ls_Objvalue.substring(0,4).equalsIgnoreCase("get_") && run.initilized) {
				 * ls_Objvalue=ls_Objvalue.substring(ls_Objvalue.indexOf("_")+1,
				 * ls_Objvalue.length()); ls_Objvalue=run.getTheValue(ls_Objvalue); } else {
				 * //ls_Objvalue=ls_Objvalue; } }catch(Exception exe) {
				 * System.out.println("Exception in Test data check for Run time validation");
				 * //ls_Objvalue=ls_Objvalue; }
				 * 
				 * ls_Seq_heading = GenericLibrary.getExcelData(filepath, ls_excel_sheet,
				 * excel_loop, 4); ls_TC1value = GenericLibrary.getExcelData(filepath,
				 * ls_excel_sheet, excel_loop, 5); //below statements added for to split
				 * optional flag and input action - shanmugakumar - 06/02/18 ls_errorarray =
				 * ls_TC1value.split("\\|"); //For ex Click|Y String
				 * ls_input_action,ls_optional_flag; ls_input_action = ls_errorarray[0]; //click
				 * ls_optional_flag = ls_errorarray[1]; //y
				 * 
				 * ls_window=GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop,
				 * 1); Set_Property set_pro_object = new Set_Property();
				 * if(!ls_Objvalue.equalsIgnoreCase("None"))//Added by Ambika to skip the object
				 * having None value on 13/3/2017 { String checkss="mani";
				 * if(popup_driver!=null) { try { // new parameter(ls_input_action) added -
				 * shanmugakumar - 06/02/18 lb_script_Continue =
				 * set_pro_object.SET_PROPERTY(popup_driver,ls_window,
				 * ls_Parameter.replaceAll("\n", ""),ls_Objvalue.replaceAll("\n",
				 * ""),ls_input_action, ls_optional_flag); } catch(Exception e) {
				 * lb_script_Continue = false; } } else { try { lb_script_Continue =
				 * set_pro_object.SET_PROPERTY(scr_driver,ls_window,
				 * ls_Parameter.replaceAll("\n", ""),ls_Objvalue.replaceAll("\n",
				 * ""),ls_input_action,ls_optional_flag); String fileName = new
				 * SimpleDateFormat("yyyyMMddHHmm").format(new Date()); Screenshot(scr_driver,
				 * componentname + fileName); } catch(StaleElementReferenceException ee) {
				 * 
				 * lb_script_Continue = set_pro_object.SET_PROPERTY(scr_driver,ls_window,
				 * ls_Parameter.replaceAll("\n", ""),ls_Objvalue.replaceAll("\n",
				 * ""),ls_input_action,ls_optional_flag); String fileName = new
				 * SimpleDateFormat("yyyyMMddHHmm").format(new Date()); Screenshot(scr_driver,
				 * componentname + fileName); System.out.println(ee); ls_status="Warning"; }
				 * 
				 * catch(UnhandledAlertException un) { System.out.
				 * println("1XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXcatch(UnhandledAlertException un)"
				 * ); ls_status="Warning"; }
				 * 
				 * 
				 * 
				 * 
				 * catch(Exception e) { System.out.println(e); lb_script_Continue = false; }//
				 * end of catch statment
				 * 
				 * }//else // added by shan if(!lb_script_Continue) { break; }
				 * 
				 * }//if of None
				 * 
				 * 
				 * // for input parameter exhaustion } else
				 * if(ls_Objvalue.equalsIgnoreCase(defs.noActionvalue)) {
				 * 
				 * 
				 * }
				 * 
				 * li_input=li_input+1; if (li_input > li_inputparamvalue ) {
				 * lb_inputvaluescompleted = true;
				 * 
				 * ls_cmd = GenericLibrary.getExcelData(filepath, ls_excel_sheet,excel_loop+1,
				 * 3); if (ls_cmd==null) lb_popupcheck=true; } //if for lb_inputvaluescompleted
				 * 
				 * System.out.println("li_input - " + li_input);
				 * System.out.println("li_inputparamvalue - " + li_inputparamvalue);
				 * 
				 * break; }//if for compare ls_windowObj and ls_Parameter
				 * 
				 * 
				 * }//for of input parameter
				 * 
				 * 
				 * }//if of li_input else { lb_inputvaluescompleted = true; } }
				 * catch(UnhandledAlertException un) { System.out.
				 * println("1XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXcatch(UnhandledAlertException un)");
				 * ls_status="Warning"; } catch(Exception e) {
				 * LOG.error("Exception Setproperty case statement in ScreenDriver Function");
				 * ls_Msg="Exception Setproperty case statement in ScreenDriver Function";
				 * ls_status="Fail"; } break;
				 */
				case "ATTACH_FILE_PATH":
					if (ls_windowObj.equalsIgnoreCase("GWCCNewPerson")) {
						System.out.println(ls_windowObj);
					}
					try {
						if (li_input <= li_inputparamvalue) {
							if ((li_input == li_inputparamvalue) && (Harness.gs_Screenshot.equalsIgnoreCase("Yes"))) {
								Screenshot(scr_driver, componentname);
							}

							for (int li_loopinputparamvalue = 0; li_loopinputparamvalue <= li_inputparamvalue; li_loopinputparamvalue++) {

								ls_Parameter = input_key_lst.get(li_loopinputparamvalue).replaceAll("\n", "").trim();// Test
																														// Case
																														// input
																														// key
																														// list
								ls_Objvalue = input_value_lst.get(li_loopinputparamvalue).replaceAll("\n", "").trim();// Test
																														// case
																														// value
																														// list

								if (ls_windowObj.replaceAll("\n", "").trim().equalsIgnoreCase(ls_Parameter.trim())) {
									if (!ls_Objvalue.equalsIgnoreCase(defs.noActionvalue)) {
										obj_found = true;

										try {
											if (ls_Objvalue.substring(0, 4).equalsIgnoreCase("run_")
													&& run.initilized) {
												ls_Objvalue = run.getTheValue(ls_Objvalue);
											} else if (ls_Objvalue.substring(0, 4).equalsIgnoreCase("get_")
													&& run.initilized) {
												ls_Objvalue = ls_Objvalue.substring(ls_Objvalue.indexOf("_") + 1,
														ls_Objvalue.length());
												ls_Objvalue = run.getTheValue(ls_Objvalue);
											} else {
												// ls_Objvalue=ls_Objvalue;
											}
										} catch (Exception exe) {
											System.out.println("Exception in Test data check for Run time validation");
											// ls_Objvalue=ls_Objvalue;
										}

										ls_Seq_heading = GenericLibrary.getExcelData(filepath, ls_excel_sheet,
												excel_loop, 4);
										ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop,
												5);
										// below statements added for to split optional flag and input action -
										// shanmugakumar - 06/02/18
										ls_errorarray = ls_TC1value.split("\\|"); // For ex Click|Y
										String ls_input_action, ls_optional_flag;
										ls_input_action = ls_errorarray[0]; // click
										ls_optional_flag = ls_errorarray[1]; // y

										ls_window = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop,
												1);

										if (!ls_Objvalue.equalsIgnoreCase("None"))// Added by Ambika to skip the object
																					// having None value on 13/3/2017
										{
											// =============
											// D:\SeleniumWorksapce\Automation_Project\others\ChikkaAdhoc\Testing
											// document1.docx
											String defaultPath = System.getProperty("user.dir") + "\\others"
													+ ls_Objvalue;

											StringSelection stringSelection = new StringSelection(defaultPath);
											Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
											clipboard.setContents(stringSelection, stringSelection);

											// String finalPDFPath= defaultPath + "/GetPayment.pdf";
											try {

												//Muthu-Thread.sleep(2000);
												Robot r = new Robot();

												r.keyPress(KeyEvent.VK_CONTROL);
												r.keyPress(KeyEvent.VK_V);
												r.keyRelease(KeyEvent.VK_V);
												r.keyRelease(KeyEvent.VK_CONTROL);
												//Muthu-Thread.sleep(1000);

												StringSelection stringSelection1 = new StringSelection(defaultPath);
												Clipboard clipboard1 = Toolkit.getDefaultToolkit().getSystemClipboard();
												clipboard1.setContents(stringSelection1, stringSelection1);
												//Muthu-Thread.sleep(1000);

												// Paste the copied default ULR
												r.keyPress(KeyEvent.VK_ENTER);
												//Muthu-Thread.sleep(2000);

												lb_script_Continue = true;
											} catch (UnhandledAlertException un) {
												System.out.println(
														"1XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXcatch(UnhandledAlertException un)");
												ls_status = "Warning";
											} catch (Exception e) {
												lb_script_Continue = false;
											}

											// =========================================
										} // if of None

										// for input parameter exhaustion
									} else if (ls_Objvalue.equalsIgnoreCase(defs.noActionvalue)) {

									}

									li_input = li_input + 1;
									if (li_input > li_inputparamvalue) {
										lb_inputvaluescompleted = true;

										ls_cmd = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop + 1,
												3);
										if (ls_cmd == null)
											lb_popupcheck = true;
									} // if for lb_inputvaluescompleted

									System.out.println("li_input - " + li_input);
									System.out.println("li_inputparamvalue - " + li_inputparamvalue);

									break;
								} // if for compare ls_windowObj and ls_Parameter

							} // for of input parameter

						} // if of li_input
						else {
							lb_inputvaluescompleted = true;
						}
					} catch (UnhandledAlertException un) {
						System.out.println("2XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXcatch(UnhandledAlertException un)");
						ls_status = "Warning";
					} catch (Exception e) {
						LOG.error("Exception Setproperty case statement in ScreenDriver Function");
						ls_Msg = "Exception Setproperty case statement in ScreenDriver Function";
						ls_status = "Fail";
					}
					break;
				case "CHECK_DUPLICATE_ERROR":
					// GWCCQuickClaimAuto_Finish_Duplication_Error_WebElement Class
					// Name=WebElement;xpath=//div[contains(@id,'NewClaimDuplicatesWorksheet:NewClaimDuplicatesScreen:ttlBar')]
					// GWCCQuickClaimAuto_Finish_Validation_Error_WebElement Class
					// Name=WebElement;xpath=//div[contains(@id,'WebMessageWorksheet:WebMessageWorksheetScreen:ttlBar')]//span[contains(text(),'Validation
					// Results')]

					WebElement check_error = null, clickElement;
					try {
						if (li_input <= li_inputparamvalue) {
							if ((li_input == li_inputparamvalue) && (Harness.gs_Screenshot.equalsIgnoreCase("Yes"))) {
								Screenshot(scr_driver, componentname);
							}

							for (int li_loopinputparamvalue = 0; li_loopinputparamvalue <= li_inputparamvalue; li_loopinputparamvalue++) {
								ls_Parameter = input_key_lst.get(li_loopinputparamvalue);// Test Case input key list
								ls_Objvalue = input_value_lst.get(li_loopinputparamvalue);// Test case value list

								if (ls_windowObj.trim().equalsIgnoreCase(ls_Parameter.trim())) {

									obj_found = true;

									// ObjectName|Click
									// Check If exists and then click

									ls_Seq_heading = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop,
											4);
									ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5);
									// below statements added for to split optional flag and input action -
									// shanmugakumar - 06/02/18
									ls_errorarray = ls_TC1value.split("\\|"); // For ex Click|Y
									String ls_input_action, ls_optional_flag;
									ls_input_action = ls_errorarray[0]; // click
									ls_optional_flag = ls_errorarray[1]; // y

									if (!ls_optional_flag.equalsIgnoreCase("ignore")) {
										ls_window = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop,
												1);

										// check_error=ls_obj.GET_OBJECT_IDENTIFIER(scr_driver, ls_Parameter,null, "Y");
										boolean errorPresence = false;
										try {
											check_error = scr_driver.findElement(By.xpath(
													"//div[contains(@id,'NewClaimDuplicatesWorksheet:NewClaimDuplicatesScreen:ttlBar')]"));
											errorPresence = false;
										} catch (Exception e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
											errorPresence = true;
										}

										if (check_error.isDisplayed() && !errorPresence) {
											clickElement = ls_obj.GET_OBJECT_IDENTIFIER(scr_driver, ls_input_action,
													null, optional_ERR_FLAG);
											if (ls_optional_flag.equalsIgnoreCase("click")) {
												if (clickElement.isDisplayed()) {

													((JavascriptExecutor) scr_driver)
															.executeScript("arguments[0].click();", clickElement);
													// clickElement.click();
													System.out.println("Clicked by Javascript");
													// Mani_Check_Replace
													// //Muthu-Thread.sleep(defs.dropdownlistLoadingTime);
												} else {
													System.out.println("NOt able to click the button");
													// scr_driver.switchTo().defaultContent();
													// scr_driver.switchTo().frame("top_frame");
													// ((JavascriptExecutor)scr_driver).executeScript("arguments[0].click();",
													// clickElement);
													// clickElement.click();
													System.out.println("Not able to click the button");
												}
											} else {
												// Nothing;
											}
										}
									}

									li_input = li_input + 1;
									if (li_input > li_inputparamvalue) {
										lb_inputvaluescompleted = true;

										ls_cmd = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop + 1,
												3);
										if (ls_cmd == null)
											lb_popupcheck = true;
									} // if for lb_inputvaluescompleted
										// break; // for input parameter exhaustion

								} // if for compare ls_windowObj and ls_Parameter

							} // for of input parameter

						} // if of li_input
						else {
							lb_inputvaluescompleted = true;
						}
					} catch (Exception e) {
						LOG.error("Exception Check duplicate Error case statement in ScreenDriver Function");
						ls_Msg = "Exception Check duplicate Error case statement in ScreenDriver Function";
						ls_status = "Fail";
						System.out.println(e.getStackTrace());
					}
					break;

				case "CHECK_VALIDATION_ERROR":
					// GWCCQuickClaimAuto_Finish_Duplication_Error_WebElement Class
					// Name=WebElement;xpath=//div[contains(@id,'NewClaimDuplicatesWorksheet:NewClaimDuplicatesScreen:ttlBar')]
					// GWCCQuickClaimAuto_Finish_Validation_Error_WebElement Class
					// Name=WebElement;xpath=//div[contains(@id,'WebMessageWorksheet:WebMessageWorksheetScreen:ttlBar')]//span[contains(text(),'Validation
					// Results')]

					WebElement check_error1 = null, clickElement1 = null;
					try {
						if (li_input <= li_inputparamvalue) {
							if ((li_input == li_inputparamvalue) && (Harness.gs_Screenshot.equalsIgnoreCase("Yes"))) {
								Screenshot(scr_driver, componentname);
							}

							for (int li_loopinputparamvalue = 0; li_loopinputparamvalue <= li_inputparamvalue; li_loopinputparamvalue++) {
								ls_Parameter = input_key_lst.get(li_loopinputparamvalue);// Test Case input key list
								ls_Objvalue = input_value_lst.get(li_loopinputparamvalue);// Test case value list

								if (ls_windowObj.trim().equalsIgnoreCase(ls_Parameter.trim())) {

									obj_found = true;

									// ObjectName|Click
									// Check If exists and then click

									ls_Seq_heading = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop,
											4);
									ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5);
									// below statements added for to split optional flag and input action -
									// shanmugakumar - 06/02/18
									ls_errorarray = ls_TC1value.split("\\|"); // For ex Click|Y
									String ls_input_action, ls_optional_flag;
									ls_input_action = ls_errorarray[0]; // click
									ls_optional_flag = ls_errorarray[1]; // y

									if (!ls_optional_flag.equalsIgnoreCase("ignore")) {
										ls_window = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop,
												1);

										// check_error=ls_obj.GET_OBJECT_IDENTIFIER(scr_driver, ls_Parameter,null, "Y");
										boolean errorPresence = false;
										try {
											check_error1 = scr_driver.findElement(By.xpath(
													"//div[contains(@id,'WebMessageWorksheet:WebMessageWorksheetScreen:ttlBar')]//span[contains(text(),'Validation Results')]"));
											errorPresence = false;
										} catch (Exception e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
											errorPresence = true;
										}

										if (check_error1.isDisplayed() && !errorPresence) {
											clickElement = ls_obj.GET_OBJECT_IDENTIFIER(scr_driver, ls_input_action,
													null, optional_ERR_FLAG);
											if (ls_optional_flag.equalsIgnoreCase("click")) {
												if (clickElement1.isDisplayed()) {

													((JavascriptExecutor) scr_driver)
															.executeScript("arguments[0].click();", clickElement);
													// clickElement.click();
													System.out.println("Clicked by Javascript");
													// Mani_Check_Replace
													// //Muthu-Thread.sleep(defs.dropdownlistLoadingTime);
												} else {
													System.out.println("NOt able to click the button");
													// scr_driver.switchTo().defaultContent();
													// scr_driver.switchTo().frame("top_frame");
													// ((JavascriptExecutor)scr_driver).executeScript("arguments[0].click();",
													// clickElement);
													// clickElement.click();
													System.out.println("Not able to click the button");
												}
											} else {
												// Nothing;
											}
										}
									}

									li_input = li_input + 1;
									if (li_input > li_inputparamvalue) {
										lb_inputvaluescompleted = true;

										ls_cmd = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop + 1,
												3);
										if (ls_cmd == null)
											lb_popupcheck = true;
									} // if for lb_inputvaluescompleted
										// break; // for input parameter exhaustion

								} // if for compare ls_windowObj and ls_Parameter

							} // for of input parameter

						} // if of li_input
						else {
							lb_inputvaluescompleted = true;
						}
					} catch (Exception e) {
						LOG.error("Exception Check duplicate Error case statement in ScreenDriver Function");
						ls_Msg = "Exception Check duplicate Error case statement in ScreenDriver Function";
						ls_status = "Fail";
						System.out.println(e.getStackTrace());
					}
					break;

				case "POLICY_SEARCH_ISSUE":
					// div[span[contains(@class,'error_icon')]]//text()
					// div[span[contains(@class,'error_icon')]]
					// div[span[contains(@class,'error_icon')]]
					WebElement policy_search_error;
					try {
						if ((li_input == li_inputparamvalue) && (Harness.gs_Screenshot.equalsIgnoreCase("Yes"))) {
							Screenshot(scr_driver, componentname);
						}

						obj_found = true;

						// ObjectName|Click
						// Check If exists and then click

						// ls_Seq_heading = GenericLibrary.getExcelData(filepath, ls_excel_sheet,
						// excel_loop, 4);
						// ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet,
						// excel_loop, 5);
						// below statements added for to split optional flag and input action -
						// shanmugakumar - 06/02/18
						// ls_errorarray = ls_TC1value.split("\\|"); //For ex Click|Y
						// String ls_input_action,ls_optional_flag;
						// ls_input_action = ls_errorarray[0]; //click
						// ls_optional_flag = ls_errorarray[1]; //y

						// ls_window=GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop,
						// 1);

						WebElement newClaimLabel = null;
						boolean newClaimLabelLabel = false;
						try {
							newClaimLabel = scr_driver.findElement(By.xpath("//td[cotains(text(),'New Claim')"));

							if (newClaimLabel.isDisplayed()) {
								System.out.println("No error in policy search, So continue");
								// Nothing;
								newClaimLabelLabel = false;
							}
						} catch (Exception e) {
							// TODO Auto-generated catch block
							newClaimLabelLabel = true;
							e.printStackTrace();
						}

						if (newClaimLabelLabel) {
							System.out.println("Might be policy Search issue, will check the error object");
							policy_search_error = scr_driver
									.findElement(By.xpath("//div[span[contains(@class,'error_icon')]]"));

							if (policy_search_error.isDisplayed()) {
								// clickElement=ls_obj.GET_OBJECT_IDENTIFIER( scr_driver, ls_input_action,null,
								// optional_ERR_FLAG);
								// Mail needs to be triggered with snap
								System.out.println(
										"Error in policy search, Waiting for Millisecond" + defs.polcysearchWaittime);
								//Muthu-Thread.sleep(defs.polcysearchWaittime);
							} else {
								System.out.println("No error in policy search, So continue");
								// Nothing;
							}
							// if for compare ls_windowObj and ls_Parameter
						}
					} catch (NoSuchElementException e) {
						LOG.error(
								"NoSuchElementException Wait of policy search error case statement in ScreenDriver Function");
						ls_Msg = "NoSuchElementException wait of policy search error statement in ScreenDriver Function";
						// ls_status="Fail";
						System.out.println(e.getStackTrace());
					} catch (Exception e) {
						LOG.error("Exception Wait of policy search error case statement in ScreenDriver Function");
						ls_Msg = "Exception wait of policy search error statement in ScreenDriver Function";
						ls_status = "Fail";
						System.out.println(e.getStackTrace());
					}
					break;

				case "HIGHLIGHT_THE_ELEMENT":
					WebElement object_tobe_highlighted = null;
					try {

						for (int li_loopinputparamvalue = 0; li_loopinputparamvalue <= li_inputparamvalue; li_loopinputparamvalue++) {
							ls_Parameter = input_key_lst.get(li_loopinputparamvalue);// Test Case input key list
							ls_Objvalue = input_value_lst.get(li_loopinputparamvalue);// Test case value list

							if (ls_windowObj.trim().equalsIgnoreCase(ls_Parameter.trim())) {
								obj_found = true;

								// ObjectName|Click
								// Check If exists and then click

								ls_Seq_heading = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 4);
								ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5);
								// below statements added for to split optional flag and input action -
								// shanmugakumar - 06/02/18
								ls_errorarray = ls_TC1value.split("\\|"); // For ex Click|Y
								String ls_input_action, ls_optional_flag;
								ls_input_action = ls_errorarray[0]; // click
								ls_optional_flag = ls_errorarray[1]; // y

								ls_window = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 1);

								object_tobe_highlighted = ls_obj.GET_OBJECT_IDENTIFIER(scr_driver, ls_windowObj, null,
										"Y");

								if (object_tobe_highlighted.isDisplayed()) {
									// clickElement=ls_obj.GET_OBJECT_IDENTIFIER(scr_driver, ls_input_action,null,
									// optional_ERR_FLAG);
									JavascriptExecutor js = (JavascriptExecutor) scr_driver;
									// use executeScript() method and pass the arguments
									// Here i pass values based on css style. Yellow background color with solid red
									// color border.
									js.executeScript(
											"arguments[0].setAttribute('style', 'background: green; border: 2px solid red;');",
											object_tobe_highlighted);

									LOG.info(ls_Msg);
									// ls_status="Pass";
									Screenshot(scr_driver, componentname);
								}

							} else {
								lb_inputvaluescompleted = true;
							}
						}

					} // if of li_input

					catch (Exception e) {
						LOG.error("Exception Check check objec value case statement in ScreenDriver Function");
						ls_Msg = "Exception check objec value case statement in ScreenDriver Function";
						ls_status = "Fail";
						System.out.println(e.getStackTrace());
					}
					break;
				case "COMPARE_OBJECT_VALUE":
					WebElement object_tobe_compared = null;
					try {
						if (li_input <= li_inputparamvalue) {
							if ((li_input == li_inputparamvalue) && (Harness.gs_Screenshot.equalsIgnoreCase("Yes"))) {
								Screenshot(scr_driver, componentname);
							}

							for (int li_loopinputparamvalue = 0; li_loopinputparamvalue <= li_inputparamvalue; li_loopinputparamvalue++) {
								ls_Parameter = input_key_lst.get(li_loopinputparamvalue);// Test Case input key list
								ls_Objvalue = input_value_lst.get(li_loopinputparamvalue);// Test case value list

								if (ls_windowObj.trim().equalsIgnoreCase(ls_Parameter.trim())) {

									obj_found = true;

									// ObjectName|Click
									// Check If exists and then click

									ls_Seq_heading = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop,
											4);
									ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5);
									// below statements added for to split optional flag and input action -
									// shanmugakumar - 06/02/18
									ls_errorarray = ls_TC1value.split("\\|"); // For ex Click|Y
									String ls_input_action, ls_optional_flag;
									ls_input_action = ls_errorarray[0]; // click
									ls_optional_flag = ls_errorarray[1]; // y

									ls_window = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 1);

									object_tobe_compared = ls_obj.GET_OBJECT_IDENTIFIER(scr_driver, ls_windowObj, null,
											"Y");

									if (object_tobe_compared.isDisplayed()) {
										// clickElement=ls_obj.GET_OBJECT_IDENTIFIER(scr_driver, ls_input_action,null,
										// optional_ERR_FLAG);
										String valueCompare = object_tobe_compared.getText().trim();
										if (defs.automatedFlagCompare) {
											if (valueCompare.equalsIgnoreCase(ls_Objvalue.trim())) {
												ls_Msg = object_tobe_compared.getText() + " is matched " + ls_Objvalue;
												LOG.info(ls_Msg);
												ls_status = "Pass";
											} else {
												ls_Msg = object_tobe_compared.getText() + " is matched " + ls_Objvalue;
												LOG.info(ls_Msg);
												ls_status = "Fail";
											}
										} else {
											ls_Msg = object_tobe_compared.getText() + " is matched " + ls_Objvalue;
											LOG.info(ls_Msg);
											ls_status = "Pass";
										}
									}

									li_input = li_input + 1;
									if (li_input > li_inputparamvalue) {
										lb_inputvaluescompleted = true;

										ls_cmd = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop + 1,
												3);
										if (ls_cmd == null)
											lb_popupcheck = true;
									} // if for lb_inputvaluescompleted
										// break; // for input parameter exhaustion

								} // if for compare ls_windowObj and ls_Parameter

							} // for of input parameter

						} // if of li_input
						else {
							lb_inputvaluescompleted = true;
						}
					} catch (Exception e) {
						LOG.error("Exception Check check objec value case statement in ScreenDriver Function");
						ls_Msg = "Exception check objec value case statement in ScreenDriver Function";
						ls_status = "Fail";
						System.out.println(e.getStackTrace());
					}
					break;

				case "WAIT_FOR_PAGELOAD":
					WebDriverWait wait = new WebDriverWait(scr_driver, defs.pageLoadTimeout);

					try {
						ls_Msg = "Waiting for Page to be loaded - Wait time in second - " + defs.pageLoadTimeout;
						// ls_status="Fail";
						LOG.info(ls_Msg);
						wait.until(new Predicate<WebDriver>() {
							public boolean apply(WebDriver scr_driver) {
								return ((JavascriptExecutor) scr_driver).executeScript("return document.readyState")
										.equals("complete");
							}
						});
					} catch (Exception e) {
						ls_Msg = "Waiting for Page to be loaded is exceeded - Wait time in second - "
								+ defs.pageLoadTimeout;
						ls_status = "Fail";
						LOG.error(ls_Msg);
						LOG.error(e.toString());
					}

					break;

				// WebElement check_error,clickElement;

				// SET_PROPERTY

				// For CBRE Applications
				/*
				 * case "COLOR_CHANGE": String ls_check = ls_windowObj; Set_Property obj_setprop
				 * = new Set_Property(); try {
				 * ele_objectname=ls_obj.GET_OBJECT_IDENTIFIER(scr_driver, ls_windowObj,null,
				 * optional_ERR_FLAG); Set_Property.mouseOver(scr_driver, ele_objectname);
				 * //Muthu-Thread.sleep(1000); }catch(Exception e) {
				 * ls_Msg="Exception Color_Change case statement in ScreenDriver Function";
				 * ls_status="Fail";
				 * LOG.error("Exception in Color Change case statment in screenDriver"); }
				 * 
				 * //VALIDATION Assert.assertNotNull(ele_objectname,
				 * " The webelement is Null in colorchange case statment of ScreenDriver");
				 * 
				 * String color =ele_objectname.getCssValue("color");
				 * 
				 * if (ls_check.equalsIgnoreCase("About CBRE")) //VALIDATION
				 * Assert.assertEquals("rgba(105, 190, 40, 1)",color,
				 * "The text color is verified");
				 * 
				 * break;
				 * 
				 * case "SearchResults_Iteration":
				 * 
				 * if (li_input <= li_inputparamvalue) { if( (li_input ==
				 * li_inputparamvalue)&&(Harness.gs_Screenshot.equalsIgnoreCase("Yes"))) {
				 * Screenshot(scr_driver, ls_window); } for (int li_loopinputparamvalue=
				 * 0;li_loopinputparamvalue<=li_inputparamvalue;li_loopinputparamvalue++) {
				 * ls_Parameter= input_key_lst.get(li_loopinputparamvalue); ls_Objvalue
				 * =input_value_lst.get(li_loopinputparamvalue); if (
				 * ls_windowObj.trim().equalsIgnoreCase(ls_Parameter.trim())) { WebElement
				 * WebTable; WebElement Previous_Arrow; WebElement next_Arrow; for(int
				 * li_rowloop=1;li_rowloop<=1;li_rowloop++) { String url1 =
				 * scr_driver.getCurrentUrl(); String xpath; xpath
				 * ="//div["+li_rowloop+"]/div/div/div/div/h3/a";
				 * scr_driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS); try {
				 * WebTable = ls_obj.GET_OBJECT_IDENTIFIER(scr_driver, ls_windowObj, null,
				 * optional_ERR_FLAG) ; WebTable.findElement(By.xpath(xpath)).click();
				 * //Muthu-Thread.sleep(10000); }catch(Exception e) {
				 * ls_Msg="Exception SerachResults_Iteration case statement in ScreenDriver Function"
				 * ; ls_status="Fail";
				 * LOG.error("Not able to locate the Webtable in SearchResultsIterations"); }
				 * try { Previous_Arrow =
				 * scr_driver.findElement(By.xpath("//a[@class='prev']")); next_Arrow =
				 * scr_driver.findElement(By.xpath("//a[@class='next']")); }catch(Exception e) {
				 * LOG.info("Arrows are not visible"); }
				 * 
				 * try { scr_driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
				 * scr_driver.navigate().back(); //Muthu-Thread.sleep(2000);
				 * 
				 * }catch(Exception e) { LOG.info("Not able to navigate back"); }
				 * if(li_rowloop==12) {
				 * scr_driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
				 * scr_driver.navigate().back();
				 * scr_driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS); }
				 * //scr_driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS); }//for
				 * 
				 * li_input=li_input+1;
				 * 
				 * if (li_input > li_inputparamvalue ) { lb_inputvaluescompleted =true; try {
				 * ls_cmd = GenericLibrary.getExcelData(filepath, ls_excel_sheet,excel_loop+1,
				 * 3); }catch(Exception e) { LOG.
				 * error("Exception of reading excel to get Command in SearchResults_Iteration of ScreenDriver"
				 * ); }
				 * 
				 * if ( ls_cmd==null) lb_popupcheck=true; } //if for lb_inputvaluescompleted
				 * 
				 * break; // for input parameter exhaustion
				 * 
				 * }//if for compare ls_windowObj and ls_Parameter
				 * 
				 * 
				 * }//for of input parameter
				 * 
				 * }//if of li_input else { lb_inputvaluescompleted = true; }
				 * 
				 * break;
				 */
				case "ProgramMessagesClose":
					try {
						DisplayProgramMessages_Close.DiplayProgram();
					} catch (Exception e) {
						ls_Msg = "Exception Setproperty case statement in ScreenDriver Function";
						ls_status = "Fail";
						LOG.error("EXCEPTION IN CALLING CLOSE DISPLAY PROGRAM IN PROGRAM MESSAGE CLOSE CASE STATMENT");
					}
					break;

				case "GeniusSelectionMenu":
					for (int li_loopinputparamvalue = 0; li_loopinputparamvalue <= li_inputparamvalue; li_loopinputparamvalue++) {
						ls_Parameter = input_key_lst.get(li_loopinputparamvalue);
						if (ls_Parameter.equals("GEGeniusMainMenu_underwriting_link")) {
							GeniusSelectionMenu.GeniusSelection();
						} else {
							break;
						}

					} // for loop
					break;

					
				//Created by Arun   DB Connection PDF Comparision
					
					
case "DBVALIDATION":
				

			        

			        


					/*try
					{
						ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5).trim();
					}catch(Exception e)
					{
						LOG.error("EXCEPTION TO GET THE VALUE FROM SCREEN COMPONENT EXCL IN WAIT FOR CASE STATMENT");
					}//END OF CATCH

					ls_errorarray = ls_TC1value.split("\\|");
					
					Policynumber = ls_errorarray[0];
					ls_optionflag =ls_errorarray[1];
					
					*/
					policynumbertxt="";
					String linepolicyno;
					LineNumberReader readerpolicyno=  new LineNumberReader(new FileReader(DECtextFile));
					while ((linepolicyno = readerpolicyno.readLine()) != null) 
			          {
			        	  	
			        	  		if(readerpolicyno.getLineNumber()==1)
			        	  		{
			        	  			if(linepolicyno.contains("Policy Number:"))
			        	  			{
			        	  				int policypos = linepolicyno.indexOf("Policy Number:");
			        	  				policypos=policypos+"Policy Number:".length();
			        	  				int policyposend = linepolicyno.indexOf("Page");
			        	  				String policynum = linepolicyno.substring(policypos, policyposend);
			        	  				policynumbertxt = policynum.trim();
			        	  			}
			        	  		}
			          }
					
					Connection connection   = null;
					Connection conn = null;
					PreparedStatement pstmt = null;
					ResultSet rset=null;
					boolean found=false;
					
					PreparedStatement pstmt1 = null;
					ResultSet rset1=null;
					
					try {
					
					// Load the IBM Toolbox for Java JDBC driver.
					DriverManager.registerDriver(new com.ibm.as400.access.AS400JDBCDriver());
					
					// Get a connection to the database.  Since we do not
					// provide a user id or password, a prompt will appear.
					//connection = DriverManager.getConnection ("jdbc:as400://" + "APOLLOMODEL.NFUIC.COM");
					
					// Connect to system 'mySys2'. The
					// default SQL schema 'myschema' is specified.
					//Connection c2 = DriverManager.getConnection("jdbc:as400://APOLLOMODEL.NFUIC.COM");
					
					Connection c = DriverManager.getConnection("jdbc:as400://APOLLOMODEL.NFUIC.COM;naming=sql;errors=full","TJOSHI","TJOSHI333");
					//Connection c = DriverManager.getConnection("jdbc:as400://APOLLOMODEL.NFUIC.COM;naming=sql;errors=full","APRASADH","Feb@2019");
					// 
					// con is a Connection object
					java.sql.DatabaseMetaData dbmd = c.getMetaData();
					String a = dbmd.getUserName();
					//System.out.println(dbmd.gettab);
					System.out.println("arun");
					String b = dbmd.getDatabaseProductVersion();
					
					
					//String QUOTE_ID = "PHO9827765";
					//String QUOTE_ID = "QHP9822063";
					//String QUOTE_ID = "PHO9827765";
					//String QUOTE_ID = "PHO9827870";
					//String QUOTE_ID = "PHP9827812";
					//String QUOTE_ID = "PHP9828063";
					//String QUOTE_ID = "QHP9827944";
					//String QUOTE_ID = "QHP9827949";
					//String QUOTE_ID = "QHP9828017";
					//String QUOTE_ID = "QHP9828022";
					//String QUOTE_ID = "QHP9828052";
					String DataSheetPath = DBValidationSheetName;
					//pstmt=c.prepareStatement("select * from ODYSSEYMOD.QUOTEANDPO q LIMIT 3");
					//pstmt=c.prepareStatement("SELECT * FROM INFORMATION_SCHEMA.tables LIMIT 100");
					//pstmt=c.prepareStatement("SELECT * FROM ODYSSEYMOD.POLICY_CLAIM LIMIT 30");
					//pstmt=c.prepareStatement("SELECT * FROM ODYSSEYMOD.CLAIM_DETAIL LIMIT 30");
					//pstmt=c.prepareStatement("SELECT * FROM ODYSSEYMOD.COVERAGE_LIMIT_FACTOR LIMIT 30");
					//pstmt=c.prepareStatement("SELECT * FROM ODYSSEYMOD.QUOTE_AND_POLICY LIMIT 30");
					//pstmt=c.prepareStatement("SELECT * FROM ODYSSEYMOD.CLAIM_DETAIL LIMIT 30");
					//pstmt=c.prepareStatement("SELECT * FROM ODYSSEYMOD.COVERAGE_DESCRIPTION LIMIT 30");
					//pstmt=c.prepareStatement("SELECT * FROM ODYSSEYMOD.ENDORSEMENT where ENDORSEMENT_NUMBER='HO0490'");
					//pstmt=c.prepareStatement("SELECT   q.SEQUENCE_ID,q.QUOTE_AND_POLICY_NUMBER,q.COMPANY_CODE,q.LINE_OF_BUSINESS,q.CONVERSION_INDICATOR,q.RISK_STATE,e.ENDORSEMENT_NUMBER,e.EDITION_DATE,j.TITLE,e.LIMIT_1,e.PREMIUM_AMOUNT,e.COVERAGE_CODE FROM     ODYSSEYMOD.ENDORSEMENT e,ODYSSEYMOD.QUOTEANDPO q,ODYSSEYMOD.DEFAULT_FORM j WHERE    e.SEQUENCE_ID=q.SEQUENCE_ID AND      e.ENDORSEMENT_NUMBER=j.FORM_CODE AND      e.EDITION_DATE=j.EDITION_DATE AND      j.EFFECTIVE_DATE <= q.EFFECTIVE_DATE AND      j.EXPIRATION_DATE >=q.EXPIRATION_DATE AND      j.STATE_CODE=q.RISK_STATE AND      j.COMPANY_CODE=q.COMPANY_CODE AND      j.LINE_OF_BUSINESS=q.LINE_OF_BUSINESS AND      j.PROGRAM_CODE=q.CONVERSION_INDICATOR AND      q.SEQUENCE_ID in (select max(SEQUENCE_ID) from ODYSSEYMOD.QUOTEANDPO d where d.quote_and_policy_number='PHO9827765')");
					pstmt=c.prepareStatement("SELECT   qnp.SEQUENCE_ID,qnp.QUOTE_AND_POLICY_NUMBER,qnp.COMPANY_CODE,qnp.LINE_OF_BUSINESS,qnp.CONVERSION_INDICATOR,qnp.RISK_STATE,cov.COVERAGE_NUMBER,D.COVERAGE_DESCRIPTION,cov.LIMIT_1,cov.PREMIUM FROM     ODYSSEYMOD.COVERAGE cov,ODYSSEYMOD.QUOTEANDPO qnp,ODYSSEYMOD.COVERAGE_DESCRIPTION D WHERE    cov.SEQUENCE_ID=qnp.SEQUENCE_ID AND      cov.COVERAGE_NUMBER=d.COVERAGE_NUMBER AND      qnp.SEQUENCE_ID in (select max(SEQUENCE_ID) from ODYSSEYMOD.QUOTEANDPO d where d.quote_and_policy_number='"+policynumbertxt+"')");
					
					
					
					rset=pstmt.executeQuery();
					
					java.sql.ResultSetMetaData rsmd = rset.getMetaData();
					System.out.println(rsmd.getTableName(1));
					
					
					
					FileInputStream inputStream = new FileInputStream(new File(DataSheetPath));
					XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
					
					XSSFSheet sheet = workbook.getSheet("CoveragValues");
					/*for (int index = sheet.getLastRowNum(); index >= sheet.getFirstRowNum(); index--) {
					sheet.removeRow( sheet.getRow(index));
					}*/
					
					int columnsNumber = rsmd.getColumnCount();
					int ii = 0;
					while (rset.next()) {
						//XSSFRow row = sheet.getRow(ii);
					XSSFRow row = sheet.createRow((short) ii);
					if(ii==0)
					{
						int j=0;
						for (int i = 1; i <= columnsNumber; i++) {
							
					        if (i > 1) System.out.print(",  ");
					        
					        String columnValue = rset.getString(i);
					        
					        //row.createCell(i).setCellValue(columnValue);
					        
					        System.out.print(columnValue + " " + rsmd.getColumnName(i));
					        
					        row.createCell(j).setCellValue(rsmd.getColumnName(i));
					        j++;
					    }
						ii++;
						int j2=0;
						row = sheet.createRow((short) ii);
						for (int i = 1; i <= columnsNumber; i++) {
					        if (i > 1) System.out.print(",  ");
					        
					        String columnValue = rset.getString(i).trim();
					        String str = columnValue.trim(); 
					        if(rsmd.getColumnName(i).trim().equalsIgnoreCase("COVERAGE_DESCRIPTION"))
					        {
					            if(columnValue.equalsIgnoreCase("Tapes and other Media") ||columnValue.equalsIgnoreCase("Firearms and Equipment")||columnValue.equalsIgnoreCase("Silverware and Goldware")||columnValue.equalsIgnoreCase("Electronic Apparatus and Accessories in Motor Vehicles")||columnValue.equalsIgnoreCase("Business Electronic Apparatus and Accessories   "))
					            {
					            	if(columnValue.equalsIgnoreCase("Tapes and other Media"))
					            	{
					            		columnValue= "Electronic Media";
					            		row.createCell(j2).setCellValue(columnValue);
					            	}
					            	else
					            	{
					            	columnValue= columnValue.replace("and", "&");
					        		row.createCell(j2).setCellValue(columnValue);
					            	}
					            }
					            else if(columnValue.contains(", and"))
					        	{
					        		columnValue= columnValue.replace(", and", ",");
					        		row.createCell(j2).setCellValue(columnValue);
					        	}
					        	else
					        	{
					        		if(columnValue.equalsIgnoreCase("Jewelry, Watches, Furs"))
					        			{
					        			columnValue= "Jewelry, Watches and Furs";
					        				row.createCell(j2).setCellValue(columnValue);
					        			}
					        		else if(columnValue.equalsIgnoreCase("Trailers"))
					    			{
					    			columnValue= "Trailers (non-watercraft)";
					    				row.createCell(j2).setCellValue(columnValue);
					    			}
					        		else if(columnValue.equalsIgnoreCase("Cov L - Fire Department Service Charge"))
					    			{
					    			columnValue= "Fire Department Service Charge";
					    				row.createCell(j2).setCellValue(columnValue);
					    			}
					        		else if(columnValue.equalsIgnoreCase("Loss Assessment - Residence Premises"))
					    			{
					    			columnValue= "Loss Assessment - Residence Premises (Liability and Property)";
					    				row.createCell(j2).setCellValue(columnValue);
					    			}
					        		else if(columnValue.equalsIgnoreCase("Land Stabilization"))
					    			{
					    			columnValue= "Land Stabilization (greater of limit shown or 5% of covered loss)";
					    				row.createCell(j2).setCellValue(columnValue);
					    			}
					        		else if(columnValue.equalsIgnoreCase("Limited Fungi, Wet or Dry Rot, or Bacteria Coverage - Property"))
					    			{
					    			columnValue= "Limited Fungi Wet or Dry Rot or Bacteria Coverage - Property";
					    				row.createCell(j2).setCellValue(columnValue);
					    			}
					        		else if(columnValue.equalsIgnoreCase("Watercraft with Trailers"))
					    			{
					    			columnValue= "Watercraft & Equipment";
					    				row.createCell(j2).setCellValue(columnValue);
					    			}
					        		else
					        		row.createCell(j2).setCellValue(columnValue);
					        	}
					        }
					        else{
					        	/*if(columnValue.contains(".")&&(rsmd.getColumnName(i).equalsIgnoreCase("PREMIUM")||rsmd.getColumnName(i).equalsIgnoreCase("PREMIUM_AMOUNT")) )
					        	{
					        		columnValue=columnValue.split(".")[0];
					        	}*/
					        if((columnValue.equals("0") || columnValue.equals("0.00"))&&(rsmd.getColumnName(i).equalsIgnoreCase("PREMIUM")||rsmd.getColumnName(i).equalsIgnoreCase("PREMIUM_AMOUNT") ))
					        {
					        	columnValue = "INCL";
					        	row.createCell(j2).setCellValue(columnValue);
					        }else
					        {
					        	row.createCell(j2).setCellValue(columnValue);
					        }
					        }
					        /*if(columnValue.contains("Tapes and other Media"))
					        {	
					        	columnValue = "Tapes & other Media";
					        	row.createCell(j2).setCellValue(columnValue);
					        }
					        else
					        {
					        	row.createCell(j2).setCellValue(columnValue);
					        }*/
					        
					        //System.out.print(columnValue + " " + rsmd.getColumnName(i));
					        
					        //row.createCell(i).setCellValue(rsmd.getColumnName(i));
					        j2++;
					    }
						//ii++;
						
					    
					}
					else
					{
						int j = 0;
					//row = spreadsheet.createRow((short) ii);
					for (int i = 1; i <= columnsNumber; i++) {
					    if (i > 1) System.out.print(",  ");
					    
					    String columnValue = rset.getString(i).trim();
					    String str = columnValue.trim(); 
					    if(rsmd.getColumnName(i).trim().equalsIgnoreCase("COVERAGE_DESCRIPTION"))
					    {
					        if(columnValue.equalsIgnoreCase("Tapes and other Media") ||columnValue.equalsIgnoreCase("Firearms and Equipment")||columnValue.equalsIgnoreCase("Silverware and Goldware")||columnValue.equalsIgnoreCase("Electronic Apparatus and Accessories in Motor Vehicles")||columnValue.equalsIgnoreCase("Business Electronic Apparatus and Accessories"))
					        {
					        	if(columnValue.equalsIgnoreCase("Tapes and other Media"))
					        	{
					        		columnValue= "Electronic Media";
					        		row.createCell(j).setCellValue(columnValue);
					        	}
					        	else
					        	{
					        	columnValue= columnValue.replace("and", "&");
					    		row.createCell(j).setCellValue(columnValue);
					        	}
					        }
					        else if(columnValue.contains(", and"))
					    	{
					    		columnValue= columnValue.replace(", and", ",");
					    		row.createCell(j).setCellValue(columnValue);
					    	}
					    	else
					    	{
					    		if(columnValue.contains("Jewelry, Watches, Furs"))
					    			{
					    			columnValue= "Jewelry, Watches and Furs";
					    				row.createCell(j).setCellValue(columnValue);
					    			}
					    		else if(columnValue.equalsIgnoreCase("Trailers"))
								{
								columnValue= "Trailers (non-watercraft)";
									row.createCell(j).setCellValue(columnValue);
								}
					    		else if(columnValue.equalsIgnoreCase("Cov L - Fire Department Service Charge"))
								{
								columnValue= "Fire Department Service Charge";
									row.createCell(j).setCellValue(columnValue);
								}
					    		else if(columnValue.equalsIgnoreCase("Loss Assessment - Residence Premises"))
								{
								columnValue= "Loss Assessment - Residence Premises (Liability and Property)";
									row.createCell(j).setCellValue(columnValue);
								}
					    		else if(columnValue.equalsIgnoreCase("Land Stabilization"))
								{
								columnValue= "Land Stabilization (greater of limit shown or 5% of covered loss)";
									row.createCell(j).setCellValue(columnValue);
								}
					    		else if(columnValue.equalsIgnoreCase("Limited Fungi, Wet or Dry Rot, or Bacteria Coverage - Property"))
								{
								columnValue= "Limited Fungi Wet or Dry Rot or Bacteria Coverage - Property";
									row.createCell(j).setCellValue(columnValue);
								}
					    		else if(columnValue.equalsIgnoreCase("Watercraft with Trailers"))
								{
								columnValue= "Watercraft & Equipment";
									row.createCell(j).setCellValue(columnValue);
								}
					    		else
					    		row.createCell(j).setCellValue(columnValue);
					    	}
					    }
					    else{
					    	//if(columnValue.equals("0") || columnValue.equals("0.00"))
					    	/*if(columnValue.contains(".")&&(rsmd.getColumnName(i).equalsIgnoreCase("PREMIUM")||rsmd.getColumnName(i).equalsIgnoreCase("PREMIUM_AMOUNT")))
					    	{
					    		columnValue=columnValue.split(".")[0];
					    	}*/
					    	if((columnValue.equals("0") || columnValue.equals("0.00"))&&(rsmd.getColumnName(i).equalsIgnoreCase("PREMIUM")||rsmd.getColumnName(i).equalsIgnoreCase("PREMIUM_AMOUNT") ))
					        {
					        	columnValue = "INCL";
					        	row.createCell(j).setCellValue(columnValue);
					        }else
					        {
					        	row.createCell(j).setCellValue(columnValue);
					        }
					    }
					    System.out.print(columnValue + " " + rsmd.getColumnName(i));
					    //row.createCell(i+1).setCellValue(rsmd.getColumnName(i));
					    j++;
					}
					}
					System.out.println("");
					ii++;
					}
					//////////////////////////////////////////////////////Query2//////////////////////////////////////
					//XSSFSheet sheet = workbook.getSheet("CoveragValues");
					XSSFSheet sheet1 = workbook.getSheet("EndorsmentValues");
					int rowCount = sheet1.getLastRowNum();
					pstmt1=c.prepareStatement("SELECT   q.SEQUENCE_ID,q.QUOTE_AND_POLICY_NUMBER,q.COMPANY_CODE,q.LINE_OF_BUSINESS,q.CONVERSION_INDICATOR,q.RISK_STATE,e.ENDORSEMENT_NUMBER,e.EDITION_DATE,j.TITLE,e.LIMIT_1,e.PREMIUM_AMOUNT,e.COVERAGE_CODE FROM     ODYSSEYMOD.ENDORSEMENT e,ODYSSEYMOD.QUOTEANDPO q,ODYSSEYMOD.DEFAULT_FORM j WHERE    e.SEQUENCE_ID=q.SEQUENCE_ID AND      e.ENDORSEMENT_NUMBER=j.FORM_CODE AND      e.EDITION_DATE=j.EDITION_DATE AND      j.EFFECTIVE_DATE <= q.EFFECTIVE_DATE AND      j.EXPIRATION_DATE >=q.EXPIRATION_DATE AND      j.STATE_CODE=q.RISK_STATE AND      j.COMPANY_CODE=q.COMPANY_CODE AND      j.LINE_OF_BUSINESS=q.LINE_OF_BUSINESS AND      j.PROGRAM_CODE=q.CONVERSION_INDICATOR AND      q.SEQUENCE_ID in (select max(SEQUENCE_ID) from ODYSSEYMOD.QUOTEANDPO d where d.quote_and_policy_number='"+policynumbertxt+"')");
					rset1=pstmt1.executeQuery();
					rsmd = rset1.getMetaData();
					columnsNumber = rsmd.getColumnCount();
					
					/*for (int index = sheet1.getLastRowNum(); index >= sheet1.getFirstRowNum(); index--) {
					sheet1.removeRow( sheet1.getRow(index));
					}*/
					//int columnsNumber = rsmd.getColumnCount();
					
					//ii = rowCount;
					ii=0;
					while (rset1.next()) {
					
						//XSSFRow row = sheet1.getRow(ii);
					XSSFRow row = sheet1.createRow((short) ii);
					if(ii==0)
					{
						int j=0;
						for (int i = 1; i <= columnsNumber; i++) {
							
					        if (i > 1) System.out.print(",  ");
					        
					        String columnValue = rset1.getString(i);
					        
					        //row.createCell(i).setCellValue(columnValue);
					        
					        System.out.print(columnValue + " " + rsmd.getColumnName(i));
					        
					        row.createCell(j).setCellValue(rsmd.getColumnName(i));
					        j++;
					    }
						ii++;
						int j2=0;
						row = sheet1.createRow((short) ii);
						for (int i = 1; i <= columnsNumber; i++) {
					        if (i > 1) System.out.print(",  ");
					        
					        String columnValue = rset1.getString(i).trim();
					        String str = columnValue.trim(); 
					        if(rsmd.getColumnName(i).trim().equalsIgnoreCase("COVERAGE_DESCRIPTION"))
					        {
					            if(columnValue.equalsIgnoreCase("Tapes and other Media") ||columnValue.equalsIgnoreCase("Firearms and Equipment")||columnValue.equalsIgnoreCase("Silverware and Goldware")||columnValue.equalsIgnoreCase("Electronic Apparatus and Accessories in Motor Vehicles")||columnValue.equalsIgnoreCase("Business Electronic Apparatus and Accessories   "))
					            {
					            	columnValue= columnValue.replace("and", "&");
					        		row.createCell(j2).setCellValue(columnValue);
					            }
					            else if(columnValue.contains(", and"))
					        	{
					        		columnValue= columnValue.replace(", and", ",");
					        		row.createCell(j2).setCellValue(columnValue);
					        	}
					        	else
					        	{
					        		row.createCell(j2).setCellValue(columnValue);
					        	}
					        }
					        else{
					        if((columnValue.equals("0") || columnValue.equals("0.00"))&&(rsmd.getColumnName(i).equalsIgnoreCase("PREMIUM")||rsmd.getColumnName(i).equalsIgnoreCase("PREMIUM_AMOUNT") ))
					        {
					        	columnValue = "INCL";
					        	row.createCell(j2).setCellValue(columnValue);
					        }else
					        {
					        	row.createCell(j2).setCellValue(columnValue);
					        }
					        }
					        /*if(columnValue.contains("Tapes and other Media"))
					        {	
					        	columnValue = "Tapes & other Media";
					        	row.createCell(j2).setCellValue(columnValue);
					        }
					        else
					        {
					        	row.createCell(j2).setCellValue(columnValue);
					        }*/
					        
					        //System.out.print(columnValue + " " + rsmd.getColumnName(i));
					        
					        //row.createCell(i).setCellValue(rsmd.getColumnName(i));
					        j2++;
					    }
						//ii++;
						
					    
					}
					else
					{
						int j = 0;
					//row = spreadsheet.createRow((short) ii);
					for (int i = 1; i <= columnsNumber; i++) {
					    if (i > 1) System.out.print(",  ");
					    
					    String columnValue = rset1.getString(i).trim();
					    String str = columnValue.trim(); 
					    if(rsmd.getColumnName(i).trim().equalsIgnoreCase("COVERAGE_DESCRIPTION"))
					    {
					        if(columnValue.equalsIgnoreCase("Tapes and other Media") ||columnValue.equalsIgnoreCase("Firearms and Equipment")||columnValue.equalsIgnoreCase("Silverware and Goldware")||columnValue.equalsIgnoreCase("Electronic Apparatus and Accessories in Motor Vehicles")||columnValue.equalsIgnoreCase("Business Electronic Apparatus and Accessories"))
					        {
					        	columnValue= columnValue.replace("and", "&");
					    		row.createCell(j).setCellValue(columnValue);
					        }
					        else if(columnValue.contains(", and"))
					    	{
					    		columnValue= columnValue.replace(", and", ",");
					    		row.createCell(j).setCellValue(columnValue);
					    	}
					    	else
					    	{
					    		row.createCell(j).setCellValue(columnValue);
					    	}
					    }
					    else{
					    	if((columnValue.equals("0") || columnValue.equals("0.00"))&&(rsmd.getColumnName(i).equalsIgnoreCase("PREMIUM")||rsmd.getColumnName(i).equalsIgnoreCase("PREMIUM_AMOUNT") ))
					        {
					        	columnValue = "INCL";
					        	row.createCell(j).setCellValue(columnValue);
					        }else
					        {
					        	row.createCell(j).setCellValue(columnValue);
					        }
					    }
					    System.out.print(columnValue + " " + rsmd.getColumnName(i));
					    //row.createCell(i+1).setCellValue(rsmd.getColumnName(i));
					    j++;
					}
					}
					System.out.println("");
					ii++;
					}
					
					inputStream.close();
					
					FileOutputStream outputStream = new FileOutputStream(DataSheetPath);
					workbook.write(outputStream);
					workbook.close();
					outputStream.close();
					System.out.println("createworkbook.xlsx written successfully");
					
					/*   // Execute the query.
					Statement select = connection.createStatement ();
					ResultSet rs = select.executeQuery (
					"SELECT * FROM " + "ODYSSEYMOD" + dmd.getCatalogSeparator() + "");
					
					// Get information about the result set.  Set the column
					// width to whichever is longer: the length of the label
					// or the length of the data.
					ResultSetMetaData rsmd = rs.getMetaData ();
					int columnCount = rsmd.getColumnCount ();
					String[] columnLabels = new String[columnCount];
					int[] columnWidths = new int[columnCount];
					for (int i = 1; i <= columnCount; ++i) {
					columnLabels[i-1] = rsmd.getColumnLabel (i);
					columnWidths[i-1] = Math.max (columnLabels[i-1].length(), rsmd.getColumnDisplaySize (i));
					}
					
					// Output the column headings.
					for (int i = 1; i <= columnCount; ++i) {
					System.out.print (format (rsmd.getColumnLabel(i), columnWidths[i-1]));
					System.out.print (" ");
					}
					System.out.println ();
					
					// Output a dashed line.
					StringBuffer dashedLine;
					for (int i = 1; i <= columnCount; ++i) {
					for (int j = 1; j <= columnWidths[i-1]; ++j)
					    System.out.print ("-");
					System.out.print (" ");
					}
					System.out.println ();
					
					// Iterate throught the rows in the result set and output
					// the columns for each row.
					while (rs.next ()) {
					for (int i = 1; i <= columnCount; ++i) {
					    String value = rs.getString (i);
					    if (rs.wasNull ())
					        value = "<null>";
					    System.out.print (format (value, columnWidths[i-1]));
					    System.out.print (" ");
					}
					System.out.println ();
					}*/
					
					}
					
					catch (Exception e) {
					System.out.println ();
					System.out.println ("ERROR: " + e.getMessage());
					}
					
					finally {
					
					// Clean up.
					try {
					if (connection != null)
					    connection.close ();
					}
					catch (SQLException e) {
					// Ignore.
					}
					}


					
					
					break;
				case "PREMIUM_EXTRACT_FROM_TEXT":

			    	String DataSheetPath = DBValidationSheetName;
			       // BufferedReader br = new BufferedReader(new FileReader("ModellerOutput.txt"));
			      LineNumberReader reader=  new LineNumberReader(new FileReader(DECtextFile));
			      LineNumberReader reader1=  new LineNumberReader(new FileReader(DECtextFile));
			      
			      FileInputStream inputStream = new FileInputStream(new File(DataSheetPath));
			      XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
			      DataFormatter dataFormatter = new DataFormatter();
			      ArrayList<String> CoveragePremium=new ArrayList<String>();
			      ArrayList<String> CoverageName=new ArrayList<String>();
			      XSSFSheet sheet = workbook.getSheet("CoveragValues");
			      Iterator<Row> rowIterator = sheet.rowIterator();
			      int i=0;
			      while (rowIterator.hasNext()) {
			          Row row = rowIterator.next();
			          if(i!=0)
			          {
			          // Now let's iterate over the columns of the current row
			          Iterator<Cell> cellIterator = row.cellIterator();
			          Cell cell = row.getCell(7);
			          Cell cell2 = row.getCell(9);
			          Cell cell3 = row.getCell(10);
			          Cell cell4 = row.getCell(11);
			          String cellValue = dataFormatter.formatCellValue(cell);
			          String cellValue2 = dataFormatter.formatCellValue(cell2);
			          String cellValue3 = dataFormatter.formatCellValue(cell3);
			          String cellValue4 = dataFormatter.formatCellValue(cell4);
			          System.out.print(cellValue + "\t");
			          System.out.print(cellValue2 + "\n");
			          if(cellValue!="")
			          CoverageName.add(cellValue);
			          
			      	}
			         i++;
			      }
			          
			      //LineNumberReader lnr = new LineNumberReader(fr);
				    
				    int linenumber = 0;
				    
			          while (reader1.readLine() != null){
			        	  
			      	linenumber++;
			          }

			          System.out.println("Total number of lines : " + linenumber);

			          reader1.close();
			          
			          String line;
			          int i2=0;
			     for(int a=0;a<CoverageName.size();a++)
			     {
			    	 int found1 = 0;
			          while ((line = reader.readLine()) != null) 
			          {
			        	  	
			        	  		if(reader.getLineNumber()==1)
			        	  			reader.mark(10000);
			        	  		
						      System.out.println(reader.getLineNumber());
						      System.out.println(line);
						      //String Lines = reader.readLine(); 
						      String str = CoverageName.get(a)+" ";
							      if(line.toLowerCase().contains(str.toLowerCase()))
							      {
							      	/*System.out.println(line.indexOf(str));
							      	int first = line.indexOf(str)+str.length()-1;
							      	int second = line.indexOf(" ",first+1);
							      	int thrid = line.indexOf(" ",second+1);
							      	String SubStr = line.substring(thrid, line.length());
							      	System.out.println(SubStr.trim());*/
							      	//String test =  "This is a sentence";
							      	String lastWord = line.substring(line.lastIndexOf(" ")+1);
							      	//Arun to check if the last word is premium , if not proceed next
							      	if(!(lastWord.contains("$")||lastWord.contains("INCL")))
							      		continue;
							      	CoveragePremium.add(lastWord);
							      	System.out.println(lastWord);
							      	
							      
							       
							       //reader.setLineNumber(0);
							      	//reader.reset();
							      		//reader.mark(0); // mark at the 0th position
									   // process first pass: repeated calls to readline() until EOF

									      reader.reset();
									      i2++;
									      found1++;
							      	//reader.markSupported();
							      	break;
							      	
							      }
							      if(reader.getLineNumber()==linenumber& found1==0)
							      {
							    	  CoveragePremium.add("Value Not Avaialble in PDF");
							    	  reader.reset();
							    	  
							    	  break;
							      }
						  }
			     }  
			      for (int x=0; x<CoveragePremium.size(); x++)
			    	    System.out.println(CoveragePremium.get(x));
			      
			      Row headerRow1 = sheet.getRow(0);
			      headerRow1.createCell(11).setCellValue("PREMIUM_PDF");
			      headerRow1.createCell(10).setCellValue("COVERAGE_DESCRIPTION_PDF");
			      
			      XSSFSheet sheet2 = workbook.getSheet("EndorsmentValues");
			      Row headerRow2 = sheet2.getRow(0);
			      headerRow2.createCell(13).setCellValue("PREMIUM_PDF");
			      headerRow2.createCell(12).setCellValue("ENDORSEMENT_NUMBER_PDF");
			      
			      String conv;
			      for (int x=0; x<CoveragePremium.size(); x++)
			      {
			    	  Row headerRow = sheet.getRow(x+1);
			    	  if(CoveragePremium.get(x).contains("$")){
			    	  conv = CoveragePremium.get(x);
			    	  conv = conv.replace("$","");
			    	  conv = conv.replace(",","");
			    	  conv = conv.trim();
			    	  if(conv.contains("."))
			    	  {
			    	  
			    		  headerRow.createCell(11).setCellValue(conv);
			    	  }
			    	  else
			    	  {
			    		  conv = conv+".00";
			    		  headerRow.createCell(11).setCellValue(conv);
			    	  }
			    	  }
			    	  else
			    	  {
			          
			          headerRow.createCell(11).setCellValue(CoveragePremium.get(x));
			    	  }
			    	  headerRow.createCell(10).setCellValue(CoverageName.get(x));
			  	    System.out.println(CoveragePremium.get(x));
			      }
			      FileOutputStream outputStream = new FileOutputStream(DataSheetPath);
			      workbook.write(outputStream);
			      workbook.close();
			      outputStream.close();
			  	
			  	//ii++;
			  	
			      

			    
					break;
				case "PDF_TO_DB_COLUMNCOMPARISON":
					
					String DataSheetPath1 = DBValidationSheetName;
					FileInputStream inputStream1 = new FileInputStream(new File(DataSheetPath1));
					XSSFWorkbook workbook1 = new XSSFWorkbook(inputStream1);

					XSSFSheet sheet1 = workbook1.getSheet("CoveragValues");
					int rows; // No of rows
				    rows = sheet1.getPhysicalNumberOfRows();
				    String[] cellvalue;
				    String[] cellvalue2;
				    // Create a DataFormatter to format and get each cell's value as String
			        DataFormatter dataFormatter1 = new DataFormatter();
			        int i1=0;
			        Map< String,String> hm = new HashMap< String,String>(); 
			        Map< String,String> hm1 = new HashMap< String,String>();
			        // 1. You can obtain a rowIterator and columnIterator and iterate over them
			        System.out.println("\n\nIterating over Rows and Columns using Iterator\n");
			        Iterator<Row> rowIterator1 = sheet1.rowIterator();
			        while (rowIterator1.hasNext()) {
			            Row row = rowIterator1.next();
			            
			            // Now let's iterate over the columns of the current row
			            Iterator<Cell> cellIterator = row.cellIterator();
			            Cell cell = row.getCell(7);
			            Cell cell2 = row.getCell(9);
			            Cell cell3 = row.getCell(10);
			            Cell cell4 = row.getCell(11);
			            String cellValue = dataFormatter1.formatCellValue(cell);
			            String cellValue2 = dataFormatter1.formatCellValue(cell2);
			            String cellValue3 = dataFormatter1.formatCellValue(cell3);
			            String cellValue4 = dataFormatter1.formatCellValue(cell4);
			            System.out.print(cellValue + "\t");
			            System.out.print(cellValue2 + "\n");
			            
			            
			            hm.put(cellValue, cellValue2);
			            hm1.put(cellValue3, cellValue4);
			           /* while (cellIterator.hasNext()) {
			                Cell cell = cellIterator.next();
			                String cellValue = dataFormatter.formatCellValue(cell);
			                System.out.print(cellValue + "\t");
			            }*/
			            System.out.println();
			        }
			        
			     // Returns Set view      
			        Set< Map.Entry< String,String> > st = hm.entrySet();    
			   
			        for (Map.Entry< String,String> me:st) 
			        { 
			            System.out.print(me.getKey()+":"); 
			            System.out.println(me.getValue()); 
			        } 
			        
			        Row row2 = sheet1.getRow(1);
			        Iterator<Row> rowIterator2 = sheet1.rowIterator();
			        while (rowIterator2.hasNext()) {
			            Row row = rowIterator2.next();
			            
			            // Now let's iterate over the columns of the current row
			            Iterator<Cell> cellIterator = row.cellIterator();
			            Cell cell = row.getCell(7);
			            Cell cell2 = row.getCell(9);
			            Cell cell3 = row.getCell(10);
			            Cell cell4 = row.getCell(11);
			            String cellValue = dataFormatter1.formatCellValue(cell);
			            String cellValue2 = dataFormatter1.formatCellValue(cell2);
			            String cellValue3 = dataFormatter1.formatCellValue(cell3);
			            String cellValue4 = dataFormatter1.formatCellValue(cell4);
			            System.out.print(cellValue + "\t");
			            System.out.print(cellValue2 + "\n");
			            System.out.print(cellValue3 + "\t");
			            System.out.print(cellValue4 + "\n");
			            if(hm.get(cellValue).equalsIgnoreCase(hm1.get(cellValue)))
			            {
			            	System.out.println("For Coverage:"+cellValue+"::The Premium value in DB:"+hm.get(cellValue)+" MAtches with Value in PDF:"+hm1.get(cellValue));
			            	row.createCell(12).setCellValue("Matches");
			            	row.createCell(13).setCellValue("For Coverage:"+cellValue+"::The Premium value in DB:"+hm.get(cellValue)+" MAtches with Value in PDF:"+hm1.get(cellValue));
			            }
			            else
			            {
			            	System.out.println("For Coverage:"+cellValue+"::The Premium value in DB:"+hm.get(cellValue)+" Not MAtches with Value in PDF:"+hm1.get(cellValue));
			            	row.createCell(12).setCellValue("NOT Matches");
			            	row.createCell(13).setCellValue("For Coverage:"+cellValue+"::The Premium value in DB:"+hm.get(cellValue)+" Not MAtches with Value in PDF:"+hm1.get(cellValue));
			            
			            }
			            
			           /* while (cellIterator.hasNext()) {
			                Cell cell = cellIterator.next();
			                String cellValue = dataFormatter.formatCellValue(cell);
			                System.out.print(cellValue + "\t");
			            }*/
			            System.out.println();
			        }
			       /* while (rowIterator.hasNext()) {
			            Row row = rowIterator.next();

			            // Now let's iterate over the columns of the current row
			            Iterator<Cell> cellIterator = row.cellIterator();
			            Cell cell = row.getCell(9);
			            String cellValue = dataFormatter.formatCellValue(cell);
			            System.out.print(cellValue + "\n");
			            while (cellIterator.hasNext()) {
			                Cell cell = cellIterator.next();
			                String cellValue = dataFormatter.formatCellValue(cell);
			                System.out.print(cellValue + "\t");
			            }
			            System.out.println();
			        }*/
			        
			        /////////////////////////////////////////////////////////*##################//////////////////////
			        XSSFSheet sheetEndors = workbook1.getSheet("EndorsmentValues");
					int rowsEn; // No of rows
				    rows = sheetEndors.getPhysicalNumberOfRows();
				    String[] cellvalueEn;
				    String[] cellvalueEn2;
				    // Create a DataFormatter to format and get each cell's value as String
			        DataFormatter dataFormatterEn = new DataFormatter();
			        //int i=0;
			        Map< String,String> hmEn = new HashMap< String,String>(); 
			        Map< String,String> hmEn1 = new HashMap< String,String>();
			        // 1. You can obtain a rowIterator and columnIterator and iterate over them
			        System.out.println("\n\nIterating over Rows and Columns using Iterator\n");
			        Iterator<Row> rowIteratorEn = sheetEndors.rowIterator();
			        while (rowIteratorEn.hasNext()) {
			            Row row = rowIteratorEn.next();
			            
			            // Now let's iterate over the columns of the current row
			            Iterator<Cell> cellIterator = row.cellIterator();
			            Cell cell = row.getCell(6);
			            Cell cell2 = row.getCell(10);
			            Cell cell3 = row.getCell(12);
			            Cell cell4 = row.getCell(13);
			            String cellValue = dataFormatter1.formatCellValue(cell);
			            String cellValue2 = dataFormatter1.formatCellValue(cell2);
			            String cellValue3 = dataFormatter1.formatCellValue(cell3);
			            String cellValue4 = dataFormatter1.formatCellValue(cell4);
			            System.out.print(cellValue + "\t");
			            System.out.print(cellValue2 + "\n");
			            
			            
			            hmEn.put(cellValue, cellValue2);
			            hmEn1.put(cellValue3, cellValue4); 
			           /* while (cellIterator.hasNext()) {
			                Cell cell = cellIterator.next();
			                String cellValue = dataFormatter.formatCellValue(cell);
			                System.out.print(cellValue + "\t");
			            }*/
			            System.out.println();
			        }
			        
			     // Returns Set view      
			        Set< Map.Entry< String,String> > stEn = hmEn.entrySet();    
			   
			        for (Map.Entry< String,String> me:stEn) 
			        { 
			            System.out.print(me.getKey()+":"); 
			            System.out.println(me.getValue()); 
			        } 
			        
			        Row rowEn2 = sheetEndors.getRow(1);
			        Iterator<Row> rowIteratorEn2 = sheetEndors.rowIterator();
			        while (rowIteratorEn2.hasNext()) {
			            Row row = rowIteratorEn2.next();
			            
			            // Now let's iterate over the columns of the current row
			            Iterator<Cell> cellIterator = row.cellIterator();
			            Cell cell = row.getCell(6);
			            Cell cell2 = row.getCell(10);
			            Cell cell3 = row.getCell(12);
			            Cell cell4 = row.getCell(13);
			            String cellValue = dataFormatter1.formatCellValue(cell);
			            String cellValue2 = dataFormatter1.formatCellValue(cell2);
			            String cellValue3 = dataFormatter1.formatCellValue(cell3);
			            String cellValue4 = dataFormatter1.formatCellValue(cell4);
			            System.out.print(cellValue + "\t");
			            System.out.print(cellValue2 + "\n");
			            System.out.print(cellValue3 + "\t");
			            System.out.print(cellValue4 + "\n");
			            if(hmEn.get(cellValue).equalsIgnoreCase(hmEn1.get(cellValue)))
			            {
			            	System.out.println("For the Form Number :"+cellValue+"::The Premium value in DB:"+hmEn.get(cellValue)+" MAtches with Value in PDF:"+hmEn1.get(cellValue));
			            	row.createCell(14).setCellValue("Matches");
			            	row.createCell(15).setCellValue("For the Form Number :"+cellValue+"::The Premium value in DB:"+hmEn.get(cellValue)+" MAtches with Value in PDF:"+hmEn1.get(cellValue));
			            }
			            else
			            {
			            	System.out.println("For the Form Number :"+cellValue+"::The Premium value in DB:"+hmEn.get(cellValue)+" Not MAtches with Value in PDF:"+hmEn1.get(cellValue));
			            	row.createCell(14).setCellValue("NOT Matches");
			            	row.createCell(15).setCellValue("For the Form Number :"+cellValue+"::The Premium value in DB:"+hmEn.get(cellValue)+" Not MAtches with Value in PDF:"+hmEn1.get(cellValue));
			            
			            }
			            
			           /* while (cellIterator.hasNext()) {
			                Cell cell = cellIterator.next();
			                String cellValue = dataFormatter.formatCellValue(cell);
			                System.out.print(cellValue + "\t");
			            }*/
			            System.out.println();
			        }
			        // 2. Or you can use a for-each loop to iterate over the rows and columns
			       /* System.out.println("\n\nIterating over Rows and Columns using for-each loop\n");
			        for (Row row: sheet) {
			            for(Cell cell: row) {
			                String cellValue = dataFormatter.formatCellValue(cell);
			                System.out.print(cellValue + "\t");
			            }
			            System.out.println();
			        }*/

			        // 3. Or you can use Java 8 forEach loop with lambda
			      /*  System.out.println("\n\nIterating over Rows and Columns using Java 8 forEach with lambda\n");
			        sheet.forEach(row -> {
			            row.forEach(cell -> {
			                String cellValue = dataFormatter.formatCellValue(cell);
			                System.out.print(cellValue + "\t");
			            });
			            System.out.println();
			        });
			        */
			        FileOutputStream outputStream1 = new FileOutputStream(DataSheetPath1);
			        workbook1.write(outputStream1);
			        workbook1.close();
			        outputStream1.close();
			        
			    
					break;
				case "CLEAR_EXCELVALUES":
					String DataSheetPath11 = DBValidationSheetName;
					FileInputStream inputStream11 = new FileInputStream(new File(DataSheetPath11));
					XSSFWorkbook workbook11 = new XSSFWorkbook(inputStream11);
					XSSFSheet sheet11 = workbook11.getSheet("CoveragValues");
					 int numberOfRows = sheet11.getPhysicalNumberOfRows();

					    if(numberOfRows > 0) {
					        for (int i11 = sheet11.getFirstRowNum(); i11 <= sheet11.getLastRowNum(); i11++) {
					            if(sheet11.getRow(i11) != null) {
					            	sheet11.removeRow( sheet11.getRow(i11));
					            } else {
					                System.out.println("Info: clean sheet='" + sheet11.getSheetName() + "' ... skip line: " + i11);
					            }
					        }               
					    } else {
					        System.out.println("Info: clean sheet='" + sheet11.getSheetName() + "' ... is empty");
					    }
					
					XSSFSheet sheet111 = workbook11.getSheet("EndorsmentValues");
					int numberOfRows1 = sheet111.getPhysicalNumberOfRows();

				    if(numberOfRows1 > 0) {
				        for (int i11 = sheet111.getFirstRowNum(); i11 <= sheet111.getLastRowNum(); i11++) {
				            if(sheet111.getRow(i11) != null) {
				            	sheet111.removeRow( sheet111.getRow(i11));
				            } else {
				                System.out.println("Info: clean sheet='" + sheet111.getSheetName() + "' ... skip line: " + i11);
				            }
				        }               
				    } else {
				        System.out.println("Info: clean sheet='" + sheet111.getSheetName() + "' ... is empty");
				    }
					inputStream11.close();

					FileOutputStream outputStream11 = new FileOutputStream(DataSheetPath11);
					workbook11.write(outputStream11);
					workbook11.close();
					outputStream11.close();
					
					break;
					
				case "CLEAR_TEXT":

					// used to clear text in Email text.
					if (li_input <= li_inputparamvalue) {
						if ((li_input == li_inputparamvalue) && (Harness.gs_Screenshot.equalsIgnoreCase("Yes"))) {
							Screenshot(scr_driver, ls_window);
						}
						for (int li_loopinputparamvalue = 0; li_loopinputparamvalue <= li_inputparamvalue; li_loopinputparamvalue++) {
							ls_Parameter = input_key_lst.get(li_loopinputparamvalue);
							ls_Objvalue = input_value_lst.get(li_loopinputparamvalue);

							if (!ls_Objvalue.equalsIgnoreCase("None"))// Added by Ambika to skip the object having None
																		// value on 13/3/2017
							{

								if (ls_windowObj.trim().equalsIgnoreCase(ls_Parameter.trim())) {
									try {
										ele_objectname = ls_obj.GET_OBJECT_IDENTIFIER(scr_driver, ls_windowObj, null,
												optional_ERR_FLAG);
									} catch (Exception e) {

										LOG.error("Unable to find the webElement in Clear text of ScreenDriver");
									}

									ls_value = ele_objectname.getAttribute("value");

									if (!ls_value.equals("")) {
										try {
											ele_objectname.clear();
										} catch (Exception e) {
											ls_Msg = "Unable to clear the Text";
											ls_status = "Fail";
										}
										break;
									}
								} // if of comparing
							} // if of None
						} // for
					} // if of input parameter
					else {
						lb_inputvaluescompleted = true;
					}
					break;
				case "STORE_RUNTIME_VALUE_1":
                    try
              {
              if (ls_cmd.equalsIgnoreCase("STORE_RUNTIME_VALUE_1")) 
                                                  {
                                                        obj_found=true;
                                                        int li_loopinputparamvalue= 0;
                                                        try
                                                  {
                                                        ls_Seq_heading = GenericLibrary.getExcelData(filepath, ls_excel_sheet, li_loopinputparamvalue, 4);
                                                        ls_window=GenericLibrary.getExcelData(filepath, ls_excel_sheet, li_loopinputparamvalue, 1);  
                                                        ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5).trim();
                                                  
                                                  }catch(Exception e)                 
                                                  {
                                                        ls_Msg="Unable to Read the Excl in Check_Property VAlue";
                                                              ls_status="Fail";
                                                        LOG.error("unable to read the Excel in Check_Property_Value ");
                                                  }
                                                  ls_errorarray = ls_TC1value.split("\\|");
                                                  int li_check = ls_errorarray.length;
                                                  ls_property = ls_errorarray[0];
                                                  String ls_FieldName = ls_errorarray[1];
                                                  String subObjecValue=ls_property.substring(0, 4);
                                                        try {
                                                              if(subObjecValue.substring(0, 4).equalsIgnoreCase("run_") && run.initilized)
                                                              {
                                                                    WebElement valueElement=ls_obj.GET_OBJECT_IDENTIFIER(scr_driver, ls_windowObj,null, optional_ERR_FLAG);
                                                                    String value=valueElement.getText();
                                                                    
                                                                          if(ls_property.contains("claim")){
                                                                                value= value.replace("Claim (","");
                                                                                value= value.replace(")","");
                                                                                run.insertValue(ls_property, value);
                                                                                System.out.println(run.getTheMap());
                                                                          }
                                                                    else{
                                                                          run.insertValue(ls_Objvalue, value);
                                                                          System.out.println(run.getTheMap());
                                                                    }
                                                                    lb_script_Continue = true;
                                                              }
                                                        } catch (Exception e1) {
                                                              // TODO Auto-generated catch block
                                                              e1.printStackTrace();
                                                              lb_script_Continue = false;
                                                        }
                                                        
                                                        Store_Property_Value storeproperty = new Store_Property_Value();
                                                        try {
                                                              storeproperty.STORE_PROPERTY_VALUE(scr_driver, ls_windowObj,  "PolicyNumber", "innertext","Y");
                                                        } catch (Exception e) {
                                                              LOG.error("EXCEPTION OF CALLING STORE PROPERTY VALUE  FUNCTION");
                                                        } // END OF CATCH
        
                                                        
                                                        
                                                        
                                                        if(!lb_script_Continue) 
                                                              {
                                                                    break;
                                                              }
                                                  }     
                           }
                         catch(Exception e)
                           {
                                 LOG.error("Exception Setproperty case statement in ScreenDriver Function");
                                 ls_Msg="Exception Setproperty case statement in ScreenDriver Function";
                                 ls_status="Fail";
                           }
          break;
              case "EXPORT_RUNTIME_VALUE_1":
                    
                    try
              {
              if (ls_cmd.equalsIgnoreCase("EXPORT_RUNTIME_VALUE_1")) 
                                                  {
                                                        obj_found=true;
                                                        int li_loopinputparamvalue= 0;
                                                        try
                                                  {
                                                        ls_Seq_heading = GenericLibrary.getExcelData(filepath, ls_excel_sheet, li_loopinputparamvalue, 4);
                                                        ls_window=GenericLibrary.getExcelData(filepath, ls_excel_sheet, li_loopinputparamvalue, 1);  
                                                        ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5).trim();
                                                  
                                                  }catch(Exception e)                 
                                                  {
                                                        ls_Msg="Unable to Read the Excl in Check_Property VAlue";
                                                              ls_status="Fail";
                                                        LOG.error("unable to read the Excel in Check_Property_Value ");
                                                  }
                                                        
                                                        ls_errorarray = ls_TC1value.split("\\|");
                                                        ls_property = ls_errorarray[0];
                                                        ls_optionflag = ls_errorarray[1];

                                                        Store_Property_Value storeproperty = new Store_Property_Value();
                                                        try {
                                                              storeproperty.STORE_PROPERTY_VALUE(scr_driver, ls_windowObj, ls_property, ls_optionflag, "Y");
                                                        } catch (Exception e) {
                                                              LOG.error("EXCEPTION OF CALLING STORE PROPERTY VALUE  FUNCTION");
                                                        } // END OF CATCH

                                                        
                                                        if(!lb_script_Continue) 
                                                              {
                                                                    break;
                                                              }
                                                  }     
                           }
                         catch(Exception e)
                           {
                                 LOG.error("Exception Setproperty case statement in ScreenDriver Function");
                                 ls_Msg="Exception Setproperty case statement in ScreenDriver Function";
                                 ls_status="Fail";
                           }

                    break;

				case "CHECK_PROPERTY_VALUE":

					if (li_output <= li_outputparamvalue) {
						li_tempoutputcount = li_outputparamvalue;

						for (int li_loopoutputparamvalue = 0; li_loopoutputparamvalue <= li_tempoutputcount; li_loopoutputparamvalue++) {
							ls_Parameter = output_key_lst.get(li_loopoutputparamvalue).trim().replaceAll("\n", "");
							ls_Objvalue = output_value_lst.get(li_loopoutputparamvalue).trim().replaceAll("\n", "");
							if (ls_windowObj.trim().replaceAll("\n", "").equalsIgnoreCase(ls_Parameter.trim())) {
								/*
								 * //Added by Ambika to get the value from Dictionary Get_Value_From_Var_Dic
								 * obj_vardic = new Get_Value_From_Var_Dic(); //Fetch value from Dictionary
								 * if(ls_Objvalue.substring(0,1).equals("*")) {
								 * ls_Objvalue=ls_Objvalue.substring(1,ls_Objvalue.length()); ls_Objvalue =
								 * obj_vardic.GET_VALUE_FROM_VAR_DIC(ls_Objvalue); } //if of ls_val
								 */

								try {

									if (ls_Objvalue.substring(0, 4).equalsIgnoreCase("run_") && run.initilized) {
										ls_Objvalue = run.getTheValue(ls_Objvalue);
									} else if (ls_Objvalue.substring(0, 4).equalsIgnoreCase("get_") && run.initilized) {
										ls_Objvalue = ls_Objvalue.substring(ls_Objvalue.indexOf("_") + 1,
												ls_Objvalue.length());
										ls_Objvalue = run.getTheValue(ls_Objvalue);
									} else {
										// ls_Objvalue=ls_Objvalue;
									}
								} catch (Exception exe) {
									System.out.println("Exception in Test data check for Run time validation");
									// ls_Objvalue=ls_Objvalue;
								}

								try {
									ls_Seq_heading = GenericLibrary.getExcelData(filepath, ls_excel_sheet,
											li_loopoutputparamvalue, 4);
									ls_window = GenericLibrary.getExcelData(filepath, ls_excel_sheet,
											li_loopoutputparamvalue, 1);
									ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5)
											.trim();

								} catch (Exception e) {
									ls_Msg = "Unable to Read the Excl in Check_Property VAlue";
									ls_status = "Fail";
									LOG.error("unable to read the Excel in Check_Property_Value ");
								}

								ls_errorarray = ls_TC1value.split("\\|");
								int li_check = ls_errorarray.length;
								ls_property = ls_errorarray[0];
								String ls_FieldName = ls_errorarray[1];

								Check_Property_Value ls_obj_check = new Check_Property_Value();
								Check_Empty_Value ls_obj_Emptycheck = new Check_Empty_Value();

								if (!ls_Objvalue.equalsIgnoreCase("None"))// Added by Ambika to skip the object having
																			// None value on 13/3/2017
								{
									if (popup_driver != null) {

										try {
											if (ls_Objvalue.equalsIgnoreCase("")) {
												// Check the parameters if it is contains empty value or not - added by
												// shan 08/06/18
												lb_script_Continue = ls_obj_Emptycheck.CHECK_EMPTY_VALUE(popup_driver,
														ls_Parameter, ls_property, ls_Objvalue, ls_FieldName,
														ls_optionflag);
											} else {
												// Check the parameters to confirm
												lb_script_Continue = ls_obj_check.CHECK_PROPERTY_VALUE(popup_driver,
														ls_Parameter, ls_property, ls_Objvalue, ls_FieldName,
														ls_optionflag);
											}
										} catch (Exception e) {
											lb_script_Continue = false;
											ls_Msg = "Unable to call the Check_Property_Value with PopUpDriver in ScreenDriver Function";
											ls_status = "Fail";
											LOG.error(ls_Msg);
										}
									} else {
										try {
											if (ls_Objvalue.equalsIgnoreCase("")) {
												// Check the parameters if it is contains empty value or not - added by
												// shan 08/06/18
												lb_script_Continue = ls_obj_Emptycheck.CHECK_EMPTY_VALUE(popup_driver,
														ls_Parameter, ls_property, ls_Objvalue, ls_FieldName,
														ls_optionflag);
											} else {
												lb_script_Continue = ls_obj_check.CHECK_PROPERTY_VALUE(scr_driver,
														ls_Parameter, ls_property, ls_Objvalue, ls_FieldName,
														ls_optionflag);// Check the parameters to confirm
											}
										} catch (Exception e) {
											lb_script_Continue = false;
											ls_Msg = "Unable to call the Check_Property_Value with Scr_driver in ScreenDriver Function";
											ls_status = "Fail";
											LOG.error(ls_Msg);
										}
									} // end of else

									if (!lb_script_Continue) {
										break;
									}
								} // if of None

								li_output = li_output + 1;
								if (li_output >= li_tempoutputcount) {
									lb_outputvaluescompleted = true;
									break;

								} // end if of li_output
							} // if of ls_Window_obj

						} // for comparing excel_object_name and ls_Parameter
						break;
					} // if input parameter and value assigned for

					// }//li_output
					else {
						lb_outputvaluescompleted = true;
					}

					break;

				case "CHECK_PROPERTY_CONTAINS":

					if (li_output <= li_outputparamvalue) {
						li_tempoutputcount = li_outputparamvalue;

						for (int li_loopoutputparamvalue = 0; li_loopoutputparamvalue <= li_tempoutputcount; li_loopoutputparamvalue++) {
							ls_Parameter = output_key_lst.get(li_loopoutputparamvalue);
							ls_Objvalue = output_value_lst.get(li_loopoutputparamvalue);
							if (ls_windowObj.trim().equalsIgnoreCase(ls_Parameter.trim())) {
								/*
								 * //Added by Ambika to get the value from Dictionary Get_Value_From_Var_Dic
								 * obj_vardic = new Get_Value_From_Var_Dic(); //Fetch value from Dictionary
								 * if(ls_Objvalue.substring(0,1).equals("*")) {
								 * ls_Objvalue=ls_Objvalue.substring(1,ls_Objvalue.length()); ls_Objvalue =
								 * obj_vardic.GET_VALUE_FROM_VAR_DIC(ls_Objvalue); } //if of ls_val
								 */
								try {
									ls_Seq_heading = GenericLibrary.getExcelData(filepath, ls_excel_sheet,
											li_loopoutputparamvalue, 4);
									ls_window = GenericLibrary.getExcelData(filepath, ls_excel_sheet,
											li_loopoutputparamvalue, 1);
									ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5)
											.trim();

								} catch (Exception e) {
									ls_Msg = "Unable to Read the Excl in Check_Property VAlue";
									ls_status = "Fail";
									LOG.error("unable to read the Excel in Check_Property_Value ");
								}

								ls_errorarray = ls_TC1value.split("\\|");
								int li_check = ls_errorarray.length;
								ls_property = ls_errorarray[0];
								String ls_FieldName = ls_errorarray[1];

								Check_Property_Value ls_obj_check = new Check_Property_Value();
								Check_Empty_Value ls_obj_Emptycheck = new Check_Empty_Value();

								if (!ls_Objvalue.equalsIgnoreCase("None"))// Added by Ambika to skip the object having
																			// None value on 13/3/2017
								{
									if (popup_driver != null) {

										try {
											if (ls_Objvalue.equalsIgnoreCase("")) {
												// Check the parameters if it is contains empty value or not - added by
												// shan 08/06/18
												lb_script_Continue = ls_obj_Emptycheck.CHECK_EMPTY_VALUE(popup_driver,
														ls_Parameter, ls_property, ls_Objvalue, ls_FieldName,
														ls_optionflag);
											} else {
												// Check the parameters to confirm
												lb_script_Continue = ls_obj_check.CHECK_PROPERTY_VALUE(popup_driver,
														ls_Parameter, ls_property, ls_Objvalue, ls_FieldName,
														ls_optionflag);
											}
										} catch (Exception e) {
											lb_script_Continue = false;
											ls_Msg = "Unable to call the Check_Property_Value with PopUpDriver in ScreenDriver Function";
											ls_status = "Fail";
											LOG.error(ls_Msg);
										}
									} else {
										try {
											if (ls_Objvalue.equalsIgnoreCase("")) {
												// Check the parameters if it is contains empty value or not - added by
												// shan 08/06/18
												lb_script_Continue = ls_obj_Emptycheck.CHECK_EMPTY_VALUE(popup_driver,
														ls_Parameter, ls_property, ls_Objvalue, ls_FieldName,
														ls_optionflag);
											} else {
												lb_script_Continue = ls_obj_check.CHECK_PROPERTY_VALUE(scr_driver,
														ls_Parameter, ls_property, ls_Objvalue, ls_FieldName,
														ls_optionflag);// Check the parameters to confirm
											}
										} catch (Exception e) {
											lb_script_Continue = false;
											ls_Msg = "Unable to call the Check_Property_Value with Scr_driver in ScreenDriver Function";
											ls_status = "Fail";
											LOG.error(ls_Msg);
										}
									} // end of else

									if (!lb_script_Continue) {
										break;
									}
								} // if of None

								li_output = li_output + 1;
								if (li_output >= li_tempoutputcount) {
									lb_outputvaluescompleted = true;
									break;

								} // end if of li_output
							} // if of ls_Window_obj

						} // for comparing excel_object_name and ls_Parameter
						break;
					} // if input parameter and value assigned for

					// }//li_output
					else {
						lb_outputvaluescompleted = true;
					}

					break;

				case "CHECK_NEGATIVE_CONDITION": // updated by shanmugakumar 30 Jan 18

					if (li_output <= li_outputparamvalue) {
						li_tempoutputcount = li_outputparamvalue;

						for (int li_loopoutputparamvalue = 0; li_loopoutputparamvalue <= li_tempoutputcount; li_loopoutputparamvalue++) {
							ls_Parameter = output_key_lst.get(li_loopoutputparamvalue);
							ls_Objvalue = output_value_lst.get(li_loopoutputparamvalue);
							if (ls_windowObj.trim().equalsIgnoreCase(ls_Parameter.trim())) {
								try {
									ls_Seq_heading = GenericLibrary.getExcelData(filepath, ls_excel_sheet,
											li_loopoutputparamvalue, 4);
									ls_window = GenericLibrary.getExcelData(filepath, ls_excel_sheet,
											li_loopoutputparamvalue, 1);
									ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5)
											.trim();

								} catch (Exception e) {
									ls_Msg = "Unable to Read the Excl in Check_Property VAlue";
									ls_status = "Fail";
									LOG.error("unable to read the Excel in Check_Property_Value ");
								}

								ls_errorarray = ls_TC1value.split("\\|");
								int li_check = ls_errorarray.length;
								ls_property = ls_errorarray[0];
								String ls_FieldName = ls_errorarray[1];
								if (!ls_Objvalue.equalsIgnoreCase("None"))// Added by Ambika to skip the object having
																			// None value on 13/3/2017
								{
									Check_Nagative_Condition ls_obj_check = new Check_Nagative_Condition();

									if (popup_driver != null) {

										try {
											ls_obj_check.CHECK_NEGATIVE_CONDITION(popup_driver, ls_Parameter,
													ls_property, ls_Objvalue, ls_FieldName, ls_optionflag);// Check the
																											// parameters
																											// to
																											// confirm
										} catch (Exception e) {
											ls_Msg = "Unable to call the Check_Property_Value with PopUpDriver in ScreenDriver Function";
											ls_status = "Fail";
											LOG.error(ls_Msg);
										}
									} else {
										try {
											ls_obj_check.CHECK_NEGATIVE_CONDITION(scr_driver, ls_Parameter, ls_property,
													ls_Objvalue, ls_FieldName, ls_optionflag);// Check the parameters to
																								// confirm
										} catch (Exception e) {
											ls_Msg = "Unable to call the Check_Property_Value with Scr_driver in ScreenDriver Function";
											ls_status = "Fail";
											LOG.error(ls_Msg);
										}
									} // end of else
								} // if of None
								li_output = li_output + 1;
								if (li_output >= li_tempoutputcount) {
									lb_outputvaluescompleted = true;
									break;

								} // end if of li_output
							} // if of ls_Window_obj

						} // for comparing excel_object_name and ls_Parameter
						break;
					} // if input parameter and value assigned for

					// }//li_output
					else {
						lb_outputvaluescompleted = true;
					}

					break;

				case "GET_POPUP_OBJECTS":

					try {
						ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5).trim();
					} catch (Exception e) {
						ls_Msg = "UNABLE TO GET THE VALUE FROM SCREEN COMPONENT EXCL IN GET POPUP OBJECTS CASE STATMENT";
						ls_status = "Fail";
						LOG.error(ls_Msg);
					}
					ls_errorarray = ls_TC1value.split("\\|");
					ls_objectname = ls_errorarray[0];
					ls_optionflag = ls_errorarray[1];

					Get_PopUp_Objects ls_pop_up = new Get_PopUp_Objects();
					try {
						popup_driver = ls_pop_up.get_PopUp_Objects(ls_objectname, ls_optionflag); // Check the
																									// parameters to
																									// confirm
					} catch (Exception e) {
						ls_Msg = "EXCEPTION OF CALLING GET POPUP OBJECTS FUNCTION";
						ls_status = "Fail";
						LOG.error(ls_Msg);
					} // END OF CATCH

					if (lb_inputvaluescompleted) {
						ls_cmd = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop + 1, 3);
//							ls_cmd = ls_cmd.trim();
						if (ls_cmd == null) {
							lb_popupcheck = true;
						}
					} // if for input value
					break;

				case "WAIT_FOR":

					try {
						ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5).trim();
					} catch (Exception e) {
						ls_Msg = "EXCEPTION TO GET THE VALUE FROM SCREEN COMPONENT EXCL IN WAIT FOR CASE STATMENT";
						ls_status = "Fail";
						LOG.error(ls_Msg);
					} // END OF CATCH

					ls_errorarray = ls_TC1value.split("\\|");
					ls_readystate = ls_errorarray[0];
					ls_optionflag = ls_errorarray[1];

					Wait_For obj_wait = new Wait_For();
					try {
						obj_wait.wait_for(ls_readystate, ls_optionflag);
					} catch (Exception e) {
						ls_Msg = "EXCEPTION OF CALLING WAIT FOR FUNCTION";
						// ls_status="Fail";
						LOG.error(ls_Msg);
					}

					break;

				case "SLEEP_FOR":

					try {
						ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5).trim();
					} catch (Exception e) {
						ls_Msg = "EXCEPTION TO GET THE VALUE FROM SCREEN COMPONENT EXCL IN SLEEP FOR CASE STATMENT";
						ls_status = "Fail";
						LOG.error(ls_Msg);
					} // END OF CATCH

					ls_errorarray = ls_TC1value.split("\\|");
					ls_readystate = ls_errorarray[0];
					ls_optionflag = ls_errorarray[1];

					Sleep_For obj_sleeep = new Sleep_For();
					try {
						obj_sleeep.wait_for(ls_readystate, ls_optionflag);
					} catch (Exception e) {
						ls_Msg = "EXCEPTION OF CALLING WAIT FOR FUNCTION";
						ls_status = "Fail";
						LOG.error(ls_Msg);
					}

					break;

				case "PDF_ON_IE_VALIDATION":

					if (li_output <= li_outputparamvalue) {
						li_tempoutputcount = li_outputparamvalue;

						for (int li_loopoutputparamvalue = 0; li_loopoutputparamvalue <= li_tempoutputcount; li_loopoutputparamvalue++) {
							ls_Parameter = output_key_lst.get(li_loopoutputparamvalue);
							ls_Objvalue = output_value_lst.get(li_loopoutputparamvalue);

							if (ls_windowObj.trim().equalsIgnoreCase(ls_Parameter.trim())) {
								try {
									ls_Seq_heading = GenericLibrary.getExcelData(filepath, ls_excel_sheet,
											li_loopoutputparamvalue, 4);
								} catch (Exception e) {
									ls_Msg = "EXCEPTION OF GETTING SEQUENCE HEADING IN TPOS PDF VALIDATION CASE STATMENT";
									ls_status = "Fail";
									LOG.error(ls_Msg);
								} // END OF CATCH
								try {
									ls_window = GenericLibrary.getExcelData(filepath, ls_excel_sheet,
											li_loopoutputparamvalue, 1);
								} catch (Exception e) {
									ls_Msg = "EXCEPTION OF GETTING SEQUENCE HEADING IN TPOS PDF VALIDATION CASE STATMENT";
									ls_status = "Fail";
									LOG.error(ls_Msg);
								} // END OF CATCH
								try {
									ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5)
											.trim();
								} catch (Exception e) {
									ls_Msg = "EXCEPTION OF GETTING TC1 VALUE  IN TPOS PDF VALIDATION CASE STATMENT";
									ls_status = "Fail";
									LOG.error(ls_Msg);
								} // END OF CATCH

								ls_errorarray = ls_TC1value.split("\\|");

								ls_property = ls_errorarray[0];
								ls_value = ls_errorarray[1];

								if (!ls_Objvalue.equalsIgnoreCase("None"))// Added by Ambika to skip the object having
																			// None value on 13/3/2017
								{

									PDF_ON_IE_VALIDATION obj_pdf = new PDF_ON_IE_VALIDATION();
									Get_PopUp_Objects obj_popup = new Get_PopUp_Objects();
									WebDriver driver_popup = ScreenDriver.popup_driver;
									try {
										obj_pdf.PDF_ON_IE_VALIDATION(popup_driver, ls_Objvalue, ls_optionflag);// Check
																												// the
																												// parameters
																												// to
																												// confirm
									} catch (Exception e) {
										ls_Msg = "EXCEPTION OF CALLING TPOS PDF VALIDATION";
										ls_status = "Fail";
										LOG.error(ls_Msg);

									} // END OF CATCH
								} // if of None
								li_output = li_output + 1;

								if (li_output >= li_tempoutputcount)
									lb_outputvaluescompleted = true;
								break;

							} // if of ls_windowObj

						} // for of input parameter and value assigned for
					} else
						lb_outputvaluescompleted = true;
					break;
				case "EXPORT_RUNTIME_VALUE":
					if (ls_windowObj.equalsIgnoreCase("GWCCHiMarley_Chat_Window_Body_Label")) {
						System.out.println(ls_windowObj);
					}
					LOG.info("Command  =  " + ls_cmd);
					//
					if (li_input <= li_inputparamvalue) {
						try {
							for (int li_loopinputparamvalue = 0; li_loopinputparamvalue <= li_inputparamvalue; li_loopinputparamvalue++) {

								ls_Parameter = input_key_lst.get(li_loopinputparamvalue);
								ls_Objvalue = input_value_lst.get(li_loopinputparamvalue);

								if (ls_windowObj.trim().equalsIgnoreCase(ls_Parameter.trim())) {

									try {
										ls_TC1value = GenericLibrary
												.getExcelData(filepath, ls_excel_sheet, excel_loop, 5).trim();
									} catch (Exception e) {
										LOG.error("EXCEPTION OF GETTING TC1 IN STORE PROPERTY VALUE  CASE STATMENT");
									}

									ls_errorarray = ls_TC1value.split("\\|");
									ls_property = ls_errorarray[0];
									ls_optionflag = ls_errorarray[1];

									Store_Property_Value storeproperty = new Store_Property_Value();
									try {
										storeproperty.STORE_PROPERTY_VALUE(scr_driver, ls_windowObj, ls_property,
												ls_optionflag, "test", "test");
									} catch (Exception e) {
										LOG.error("EXCEPTION OF CALLING STORE PROPERTY VALUE  FUNCTION");
									} // END OF CATCH

									li_input = li_input + 1;
									if (li_input > li_inputparamvalue) {
										lb_inputvaluescompleted = true;

										ls_cmd = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop + 1,
												3);
										if (ls_cmd == null)
											lb_popupcheck = true;
									}
								}
							}
						} catch (Exception e) {
							LOG.error("Exception ExportRuntime case statement in ScreenDriver Function");
						}
					}

					break;

				case "STORE_PROPERTY_VALUE":

					for (int li_loopoutputparamvalue = 0; li_loopoutputparamvalue <= li_tempoutputcount; li_loopoutputparamvalue++) {
						if (ls_cmd.equalsIgnoreCase("STORE_PROPERTY_VALUE")) {

							try {
								ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5)
										.trim();
							} catch (Exception e) {
								ls_Msg = "EXCEPTION OF GETTING TC1 IN STORE PROPERTY VALUE  CASE STATMENT";
								// ls_status="Fail";
								LOG.error(ls_Msg);
							} // END OF CATCH

						} else

							break;
					} // for loop

					String ls_variablestore = null;
					try {
						ls_errorarray = ls_TC1value.split("\\|");
						ls_property = ls_errorarray[0];
						ls_var = ls_errorarray[1];
						ls_optionflag = ls_errorarray[2];

						ls_variablestore = ls_errorarray[3];
					} catch (ArrayIndexOutOfBoundsException e) {

					}

					Store_Property_Value obj_storeproperty = new Store_Property_Value();

					try {
						lb_script_Continue = obj_storeproperty.STORE_PROPERTY_VALUE(scr_driver, ls_windowObj,
								ls_property, ls_var, ls_optionflag, ls_variablestore);
					} catch (Exception e) {
						lb_script_Continue = false;
					} // end of catch statment

					// added by shan
					if (!lb_script_Continue) {
						break;
					}
					break;

				case "CHECK_OBJECT_EXIST":

					boolean lb_Exist = false;

					if (li_output <= li_outputparamvalue) {
						li_tempoutputcount = li_outputparamvalue;

						for (int li_loopoutputparamvalue = 0; li_loopoutputparamvalue <= li_tempoutputcount; li_loopoutputparamvalue++) {
							ls_Parameter = output_key_lst.get(li_loopoutputparamvalue);
							ls_Objvalue = output_value_lst.get(li_loopoutputparamvalue);

							if (ls_windowObj.trim().equalsIgnoreCase(ls_Parameter.trim())) {
								if (!ls_Objvalue.equalsIgnoreCase("None"))// Added by Ambika to skip the object having
																			// None value on 13/3/2017
								{
									try {
										ls_TC1value = GenericLibrary
												.getExcelData(filepath, ls_excel_sheet, excel_loop, 5).trim();
									} catch (Exception e) {
										ls_Msg = "EXCEPTION OF GETTING TC1 IN CHECK OBJECT EXIST CASE STATMENT";
										ls_status = "Fail";
										LOG.error(ls_Msg);
									} // END OF CATCH

									ls_errorarray = ls_TC1value.split("\\|");
									String Condition = ls_errorarray[0];
									ls_optionflag = ls_errorarray[1];

									Check_Object_Exist check_obj_exist = new Check_Object_Exist();// Creating object to
																									// call
																									// Check_Object_Exist
																									// method
									try {
										lb_Exist = check_obj_exist.CHECK_OBJECT_EXIST(ls_windowObj, Condition);
									} catch (Exception e) {
										ls_Msg = "EXCEPTION OF CALLING CHECK OBJECT EXIST FUNCTION";
										ls_status = "Fail";
										LOG.error(ls_Msg);
									} // END OF CATCH

									// VALIDATION
									// Assert.assertTrue(lb_Exist, "THE OBJECT DOES NOT EXIST ");

									LOG.info("The object " + "'" + ls_objectname + "'"
											+ "exist in the GUI objects dictionary.");
								} // if of None
								li_output = li_output + 1;

								if (li_output >= li_tempoutputcount)
									lb_outputvaluescompleted = true;
								break;

							} // if of ls_windowObj
						} // for ofli_loopoutputparamvalue
					} else
						lb_outputvaluescompleted = true;
					break;

				/*
				 * case "WAITFOR_PROPERTY_VALUE": try { ls_TC1value =
				 * GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5).trim();
				 * }catch(Exception e) {
				 * LOG.error("EXCEPTION OF GETTING TC1 IN WAITFOR PROPERTY VALUE  CASE STATMENT"
				 * ); }//END OF CATCH
				 * 
				 * ls_errorarray = ls_TC1value.split("\\|"); ls_readystate = ls_errorarray[0];
				 * ls_Complete = ls_errorarray[1]; // li_seconds = ls_errorarray[2]; ls_TRUE
				 * =ls_errorarray[3]; ls_optionflag =ls_errorarray[4];
				 * 
				 * // Call WAITFOR_PROPERTY_VALUE(ls_readystate,ls_Complete,li_seconds,ls_TRUE,
				 * ls_optionflag) break;
				 */
				case "SELECT_DATE_FROM_PICKER":

					Calender obj_calender = new Calender();
					try {
						obj_calender.DATE_PICKER();
					} catch (Exception e) {
						ls_Msg = "EXCEPTION OF CALLING CALENDER FUNCTION";
						ls_status = "Fail";
						LOG.error(ls_Msg);
					}
					break;

				case "CHECK_APP_MESSAGE":

					try {
						ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5);
					} catch (Exception e) {
						ls_Msg = "EXCEPTION OF GETTING TC1 VALUE IN CHECK APP MESSAGE  CASE STATMENT";
						ls_status = "Fail";
						LOG.error(ls_Msg);
					} // END OF CATCH
					ls_errorarray = ls_TC1value.split("\\|");
					ls_errorcode = ls_errorarray[0];
					ls_errbutton = ls_errorarray[1];
					ls_optionflag = ls_errorarray[2];

					Check_App_Message obj_appmessage = new Check_App_Message();
					try {

						obj_appmessage.CHECK_APP_MESSAGE(ls_errorcode, ls_errbutton, ls_optionflag);
					} catch (Exception e) {
						ls_Msg = "EXCEPTION OF CALLING CHECK APP MESSAGE";
						ls_status = "Fail";
						LOG.error(ls_Msg);
					} // END OF CATCH
					if (lb_inputvaluescompleted) {

						try {
							ls_cmd = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop + 1, 3);
						} catch (Exception e) {

							ls_Msg = "EXCEPTION OF GETTING COMMAND IN CHECK APP MESSAGE";
							ls_status = "Fail";
							LOG.error(ls_Msg);
						} // END OF CATCH

						// ls_cmd = ls_cmd.trim();
						if (ls_cmd == null) {
							lb_popupcheck = true;
						}
					} // if for input value
					break;

				case "CHECK_TABLE_VALUE":

					if (li_output <= li_outputparamvalue) {
						li_tempoutputcount = li_outputparamvalue;

						for (int li_loopoutputparamvalue = 0; li_loopoutputparamvalue <= li_tempoutputcount; li_loopoutputparamvalue++) {
							ls_Parameter = output_key_lst.get(li_loopoutputparamvalue);
							ls_Objvalue = output_value_lst.get(li_loopoutputparamvalue);
							// ls_strtocheck= ls_Objvalue;
							if (ls_windowObj.equalsIgnoreCase(ls_Parameter)) {

								try {
									ls_window = GenericLibrary.getExcelData(filepath, ls_excel_sheet,
											li_loopoutputparamvalue, 1);
								} catch (Exception e) {
									ls_Msg = "EXCEPTION OF GETTING WINDOW IN  CHECK TABLE VALUE  CASE STATMENT";
									ls_status = "Fail";
									LOG.error(ls_Msg);
								} // END OF CATCH

								ls_Parameter1 = ls_Parameter.substring(0, ls_Parameter.length() - 2);
								try {
									ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5);
								} catch (Exception e) {
									ls_Msg = "EXCEPTION OF GETTING TC1 VALUE  IN CHECK TABLE VALUE  CASE STATMENT";
									ls_status = "Fail";
									LOG.error(ls_Msg);
								} // END OF CATCH

								ls_Valuesarray = ls_TC1value.split("\\|");
								li_row = ls_Valuesarray[0];
								li_col = ls_Valuesarray[1];
								ls_strtocheck = ls_Valuesarray[2];
								ls_optionflag = ls_Valuesarray[3];
								li_tagName = ls_optionflag; // 08 Feb 18 - Shan
								if (!ls_Objvalue.equalsIgnoreCase("None"))// Added by Ambika to skip the object having
																			// None value on 13/3/2017
								{
									CHECK_TABLE_VALUE obj_check_talble_value = new CHECK_TABLE_VALUE();
									try {
										obj_check_talble_value.check_Table_Value(ls_window, ls_Parameter, li_row,
												li_col, ls_Objvalue, ls_strtocheck, ls_optionflag);// Check the
																									// parameters to
																									// confirm

									} catch (Exception e) {
										ls_Msg = "EXCEPTION OF CALLING CHECK TABLE VALUE  CASE STATMENT";
										// ls_status="Fail";
										LOG.error(ls_Msg);
									} // END OF CATCH

								} // if of None
								li_output = li_output + 1;

								if (li_output >= li_tempoutputcount) {
									lb_outputvaluescompleted = true;
									break;

								} // end if of li_output
							} // if of ls_Window_obj

						} // for comparing excel_object_name and ls_Parameter
						break;
					} // if input parameter and value assigned for

					// }//li_output
					else {
						lb_outputvaluescompleted = true;
					}

					break;

				case "CHECK_MULTIPLE_OBJECTS":

					if (li_output <= li_outputparamvalue) {
						li_tempoutputcount = li_outputparamvalue;

						for (int li_loopoutputparamvalue = 0; li_loopoutputparamvalue <= li_tempoutputcount; li_loopoutputparamvalue++) {
							ls_Parameter = input_key_lst.get(li_loopoutputparamvalue);
							ls_Objvalue = input_value_lst.get(li_loopoutputparamvalue);

							if (!ls_Objvalue.equalsIgnoreCase("None"))// Added by Ambika to skip the object having None
																		// value on 13/3/2017
							{
								try {
									ls_Seq_heading = GenericLibrary.getExcelData(filepath, ls_excel_sheet,
											li_loopoutputparamvalue, 4);
								} catch (Exception e) {
									ls_Msg = "EXCEPTION OF GETTING SEQUENCE HEADING IN CHECK MULTIPLE OBJECTS  CASE STATMENT";
									ls_status = "Fail";
									LOG.error(ls_Msg);
								} // END OF CATCH
								try {
									ls_window = GenericLibrary.getExcelData(filepath, ls_excel_sheet,
											li_loopoutputparamvalue, 1);
								} catch (Exception e) {
									ls_Msg = "EXCEPTION OF GETTING WINDOW IN CHECK MULTIPLE OBJECTS CASE STATMENT";
									ls_status = "Fail";
									LOG.error(ls_Msg);
								} // END OF CATCH

								// splitting the input value
								ls_arrObjvalue = ls_Objvalue.split("\\|");

								// get the table object

								ele_objectname = ls_obj.GET_OBJECT_IDENTIFIER(scr_driver, ls_windowObj, ls_Objvalue,
										optional_ERR_FLAG);
								Assert.assertNotNull(ele_objectname, "The webelement is null");

								// Check that row and column coords exist
								for (int li_loop = 0; li_loop <= ls_arrObjvalue.length; li_loop++) {
									List<WebElement> columns_table = new ArrayList<WebElement>();
									columns_table = ele_objectname.findElements(By.tagName("td"));
									ls_SelectedColumn = columns_table.get(li_loop).getText();

									if (ls_SelectedColumn.length() != -1)
										LOG.info(ls_arrObjvalue[li_loop] + "Record available in the web table ");
									else
										LOG.info(ls_arrObjvalue[li_loop] + "Record is not available in the web table ");
								} // for of li_loop

							} // if of None
							li_output = li_output + 1;

							if (li_output >= li_tempoutputcount)
								lb_outputvaluescompleted = true;
							break;
						} // input parameter and value assigned for
					} else
						lb_outputvaluescompleted = true;
					break;

				case "SET_MULTIPLE_OBJECTS":

					if (li_input <= li_inputparamvalue) {
						if ((li_input == li_inputparamvalue) && (Harness.gs_Screenshot.equalsIgnoreCase("Yes"))) {
							Screenshot(scr_driver, ls_window);
						}
						for (int li_loopinputparamvalue = 0; li_loopinputparamvalue <= li_inputparamvalue; li_loopinputparamvalue++) {
							ls_Parameter = input_key_lst.get(li_loopinputparamvalue);
							ls_Objvalue = input_value_lst.get(li_loopinputparamvalue);

							if (ls_windowObj.trim().equalsIgnoreCase(ls_Parameter.trim())) {
								if (!ls_Objvalue.equalsIgnoreCase("None"))// Added by Ambika to skip the object having
																			// None value on 13/3/2017
								{
									// to include column index to select the risk type
									if ((ls_Parameter.equals("cChangeNewClaimPolicySelection_Select_RiskType"))
											|| (ls_Parameter
													.equals("cChangeNewClaimPolicySelection_Select_RiskTypeForMVA")))
										li_columntocheck = 5;
									else
										li_columntocheck = 1;
									try {
										ls_Seq_heading = GenericLibrary.getExcelData(filepath, ls_excel_sheet,
												li_loopinputparamvalue, 4);
									} catch (Exception e) {
										ls_Msg = "EXCEPTION OF GETTING SEQUENCE HEADING IN SET MULTIPLE OBJECT  CASE STATMENT";
										ls_status = "Fail";
										LOG.error(ls_Msg);
									} // END OF CATCH

									try {
										ls_window = GenericLibrary.getExcelData(filepath, ls_excel_sheet,
												li_loopinputparamvalue, 1);
									} catch (Exception e) {
										ls_Msg = "EXCEPTION OF GETTING WINDOW IN SET MULTIPLE OBJECT CASE STATMENT";
										ls_status = "Fail";
										LOG.error(ls_Msg);
									} // END OF CATCH

									// splitting the input value
									ls_arrObjvalue = ls_Objvalue.split("\\|");

									// get the table object
									try {
										ele_objectname = ls_obj.GET_OBJECT_IDENTIFIER(scr_driver, ls_windowObj,
												ls_Objvalue, optional_ERR_FLAG);
									} catch (Exception e) {
										ls_Msg = "EXCEPTION OF GET OBJECT IDENTIFIER IN SET MULTIPLE OBJECT";
										ls_status = "Fail";
										LOG.error(ls_Msg);
									} // END OF CATCH

								} // if of None

								li_input = li_input + 1;

								if (li_input > li_inputparamvalue) {

									lb_inputvaluescompleted = true;
									try {
										ls_cmd = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop + 1,
												3);
									} catch (Exception e) {
										ls_Msg = "EXCEPTION OF GETTING COMMAND IN SET MULTIPLE OBJECT  CASE STATMENT";
										ls_status = "Fail";
										LOG.error(ls_Msg);
									} // END OF CATCH
										// ls_cmd = ls_cmd.trim();

									if (ls_cmd == null)
										lb_popupcheck = true;
								} // if for lb_inputvaluescompleted

								break; // for input parameter exhaustion

							} // if for compare ls_windowObj and ls_Parameter

						} // for of input parameter

					} // if of li_input
					else {
						lb_inputvaluescompleted = true;
					}

					break;

				case "STORE_TABLE_VALUE":
					try {
						ls_windowObj = ls_windowObj.substring(0, ls_windowObj.length() - 2);
					} catch (Exception e) {
						ls_Msg = "EXCEPTION OF GETTING WINDOW IN STORE TABLE VALUE  CASE STATMENT";
						ls_status = "Fail";
						LOG.error(ls_Msg);
					} // END OF CATCH

					try {
						ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5).trim();
					} catch (Exception e) {
						ls_Msg = "EXCEPTION OF GETTING TC1 VALUE IN STORE TABLE VALUE  CASE STATMENT";
						ls_status = "Fail";
						LOG.error(ls_Msg);
						LOG.error("");
					} // END OF CATCH

					ls_array = ls_TC1value.split("\\|");
					ls_row = ls_array[0];
					ls_col = ls_array[1];
					ls_var = ls_array[2];
					ls_optionflag = ls_array[3];

					// Call
					// STORE_TABLE_VALUE(ls_window,ls_windowObj1,ls_row,ls_col,ls_var,ls_optionflag)
					break;

				case "VERIFY_FILTERS_DATA":

					// This function will take input as 2 paramter, 1) column no 2) Data to verify
					// in the Test Case Detail.
					if (li_output <= li_outputparamvalue) {
						li_tempoutputcount = li_outputparamvalue;

						for (int li_loopoutputparamvalue = 0; li_loopoutputparamvalue <= li_tempoutputcount; li_loopoutputparamvalue++) {
							ls_Parameter = input_key_lst.get(li_loopoutputparamvalue);
							ls_Objvalue = input_value_lst.get(li_loopoutputparamvalue);
							if (!ls_Objvalue.equalsIgnoreCase("None"))// Added by Ambika to skip the object having None
																		// value on 13/3/2017
							{
								try {
									ls_Seq_heading = GenericLibrary.getExcelData(filepath, ls_excel_sheet,
											li_loopoutputparamvalue, 4);
								} catch (Exception e) {
									ls_Msg = "EXCEPTION OF GETTING SEQUENCE HEADING IN VERIFIES FILTER DATA  CASE STATMENT";
									ls_status = "Fail";
									LOG.error(ls_Msg);
								} // END OF CATCH

								try {
									ls_window = GenericLibrary.getExcelData(filepath, ls_excel_sheet,
											li_loopoutputparamvalue, 1);
								} catch (Exception e) {
									ls_Msg = "EXCEPTION OF GETTING WINDOW IN VERIFIES FILTER DATA  CASE STATMENT";
									ls_status = "Fail";
									LOG.error(ls_Msg);
								} // END OF CATCH

								// splitting the input value
								ls_arrObjvalue = ls_Objvalue.split("\\|");

								try {
									// get the table object
									ele_objectname = ls_obj.GET_OBJECT_IDENTIFIER(scr_driver, ls_windowObj, ls_Objvalue,
											optional_ERR_FLAG);
								} catch (Exception e) {
									ls_Msg = "EXCEPTION OF GETTING TABLE WEB ELEMENT IN VERIFIES FILTER DATA";
									ls_status = "Fail";
									LOG.error(ls_Msg);
								} // END OF CATCH

								// VALIDATION
								Assert.assertNotNull(ele_objectname, "THW WEB ELEMENT IS NULL");

								// If the table does not exist report error
								List<WebElement> rows_table = new ArrayList<WebElement>();
								List<WebElement> columns_table = new ArrayList<WebElement>();
								try {
									rows_table = ele_objectname.findElements(By.tagName("tr"));
								} catch (Exception e) {
									ls_Msg = "UNABLE TO GET THE ROW FROM THE TABLE";
									ls_status = "Fail";
									LOG.error(ls_Msg);
								} // END OF CATCH
								ls_rowcount = rows_table.size();

								// Check that row and column coords exist
								for (int li_loop = 2; li_loop <= ls_rowcount; li_loop++) {

									try {
										columns_table = ele_objectname.findElements(By.tagName("td"));
									} catch (Exception e) {
										ls_Msg = "UNABLE TO  GET THE COLUMN FROM THE TABLE";
										ls_status = "Fail";
										LOG.error(ls_Msg);
									} // END OF CATCH

									int li_arrObjvalue = Integer.parseInt(ls_arrObjvalue[0]);
									try {
										ls_SelectedColumn = columns_table.get(li_arrObjvalue).getText();
									} catch (Exception e) {
										ls_Msg = "UNABLE TO GET THE VALUE FROM THE TABLE";
										ls_status = "Fail";
										LOG.error(ls_Msg);
									} // END OF CATCH

									// VALIDATION
									Assert.assertNotNull(ls_SelectedColumn, "THE VALUE FROM THE TABLE IS NULL");

									if (ls_arrObjvalue[1].substring(0).equals("!")) {
										ls_ExpectedValue = ls_arrObjvalue[1].substring(2);

										if (ls_SelectedColumn.contains(ls_ExpectedValue))
											LOG.info(ls_SelectedColumn + "No Reponse message available in the Table");
										else
											LOG.info(ls_SelectedColumn
													+ "No Reponse message Not available in the Table");

									} else if (ls_SelectedColumn.toLowerCase().trim()
											.equals(ls_arrObjvalue[1].toLowerCase().trim()))
										LOG.info(ls_SelectedColumn + "Record available in the web table ");
									else
										LOG.info(ls_SelectedColumn + "Record is not available in the web table ");

								} // for of li_loop

							} // if of None
							li_output = li_output + 1;
							if (li_output >= li_tempoutputcount)
								lb_outputvaluescompleted = true;
							break;

						} // input parameter and value assigned for
					} else
						lb_outputvaluescompleted = true;

					break;

				case "SEARCH_ELEMENT":
					System.out.print("Seach element");

					// the inner text of the object and class name of the object has to be passed
					// from the input in the test case for the webTable

					if (li_input <= li_inputparamvalue) {
						if ((li_input == li_inputparamvalue) && (Harness.gs_Screenshot.equalsIgnoreCase("Yes"))) {
							Screenshot(scr_driver, ls_window);
						}
						for (int li_loopinputparamvalue = 0; li_loopinputparamvalue <= li_inputparamvalue; li_loopinputparamvalue++) {
							ls_Parameter = input_key_lst.get(li_loopinputparamvalue);
							ls_Objvalue = input_value_lst.get(li_loopinputparamvalue);

							if (ls_windowObj.toUpperCase().trim().equals(ls_Parameter.toUpperCase())) {
								if (!ls_Objvalue.equalsIgnoreCase("None"))// Added by Ambika to skip the object having
																			// None value on 13/3/2017
								{
									ls_Seq_heading = GenericLibrary.getExcelData(filepath, ls_excel_sheet,
											li_loopinputparamvalue, 4);
									ls_window = GenericLibrary.getExcelData(filepath, ls_excel_sheet,
											li_loopinputparamvalue, 1);

									ls_arrObjvalue = ls_Objvalue.split("\\|");
									ls_value = ls_arrObjvalue[0];
									ls_ObjectClassname = ls_arrObjvalue[1];
									ls_select = ls_arrObjvalue[2];
									if (ls_value.substring(0).equals("*")) {
										Get_Value_From_Var_Dic obj_var_dic = new Get_Value_From_Var_Dic();
										ls_value = obj_var_dic.GET_VALUE_FROM_VAR_DIC(ls_value);
									} // if of ls_value
									if (ls_select.substring(0).equals("*")) {
										Get_Value_From_Var_Dic obj_var_dic = new Get_Value_From_Var_Dic();
										ls_select = obj_var_dic.GET_VALUE_FROM_VAR_DIC(ls_select);
									} // if
										// get the table object
									ele_objectname = ls_obj.GET_OBJECT_IDENTIFIER(scr_driver, ls_windowObj, null,
											optional_ERR_FLAG);

									try {
										tableRows = ele_objectname.findElements(By.tagName("tr"));
										rowsize = tableRows.size();
										for (WebElement row : tableRows) {
											tablecolumns = row.findElements(By.tagName("td"));
											// tablecolumns=ele_objectname.findElements(By.xpath("\\tr["+rowno+"]\td"));
											rowno++;
											columnsize = tablecolumns.size();
											// 'Check that row and column records exist
											// System.out.println("li_loop"+li_loop);
											for (WebElement column : tablecolumns) {
												ls_SelectedColumn = column.getText();
												if (ls_SelectedColumn.trim().equalsIgnoreCase(ls_value)) {
													switch (ls_ObjectClassname) {
													case "Link":
														scr_driver.findElement(By.xpath("//tr[" + rowno + "]/td[1]"))
																.click();
														break;

													case "WebElement":
														scr_driver.findElement(By.xpath("//tr[" + rowno + "]/td[1]"))
																.click();
														break;

													case "WebList":
														System.out.println("WebList");
														if ((ls_windowObj.equals("GEWorkWithCoverages_Coverage_Table")
																|| ls_windowObj.equals("GEWorkWithPolicy_Policy_Table")
																|| ls_windowObj
																		.equals("GEWorkWithSections_Sections_Table"))
																&& (rowno > 4)) {
															rowno = rowno - 3;
														}
														WebElement list = scr_driver.findElement(
																By.xpath("//tr[" + rowno + "]/td[1]/select"));
														if (list != null) {
															Set_Property obj_setproperty = new Set_Property();
															System.out.println("ls_select" + ls_select);
															// obj_setproperty.selectDDlByVisibleText(list,ls_select,);
														} else {
															System.out.println("List is null");
														}
														scr_driver.manage().timeouts().implicitlyWait(10,
																TimeUnit.SECONDS);
														break;

													case "WebEdit":
														scr_driver.findElement(By.xpath("//tr[" + rowno + "]/td[1]"))
																.sendKeys(ls_select);
														break;

													}// switch
													break;

												} // if of ls_selectedcoulumn
												columnNo++;
											} // for of column
										} // for of row
									} catch (Exception e) {
										ls_Msg = "EXCEPTION IN SEARCH ELEMNET CASE STATMENT IN SCREENDRIVER FUNCTION";
										ls_status = "Fail";
										LOG.error(ls_Msg);
									}
								} // if of None

								li_input = li_input + 1;

								if (li_input > li_inputparamvalue) {
									lb_inputvaluescompleted = true;
									ls_cmd = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop + 1, 3);
									if (ls_cmd == null)
										lb_popupcheck = true;
								} // if for lb_inputvaluescompleted
								break; // for input parameter exhaustion

							} // if for compare ls_windowObj and ls_Parameter

						} // for of input parameter
					} // if of li_input
					else {
						lb_inputvaluescompleted = true;
					}
					break;
				case "BROWSER_INVOKEURL":

					try {
						ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5).trim();
					} catch (Exception e) {
						ls_Msg = "UNABLE TO GET THE TC1 VALUE IN BROWSER INVOKE URL";
						ls_status = "Fail";
						LOG.error(ls_Msg);
					} // END OF CATCH

					ls_array = ls_TC1value.split("\\|");
					ls_applnid = ls_array[0];
					ls_optionflag = ls_array[1];
					Browser_Close obj_browserclose = new Browser_Close();

					switch (ls_applnid) {

					case "ODM":
						try {
							//Muthu-Thread.sleep(500);
							scr_driver.navigate().to(Harness.gs_ODM_Url);
						} catch (Exception e) {
							ls_Msg = "Unable To Navigate to ODM";
							ls_status = "Fail";
							LOG.error(ls_Msg);
						}
						break;
					case "SYMBILITY":
						try {
							//Muthu-Thread.sleep(700);
							scr_driver.navigate().to(Harness.SYMBILITY_URL);
						} catch (Exception e) {
							ls_Msg = "Unable To Navigate to SYMBILITY_URL";
							ls_status = "Fail";
							LOG.error(ls_Msg);
						}
						break;
					case "HIMARLEY_BACKUP":
						try {
							//Muthu-Thread.sleep(700);
							scr_driver.navigate().to(Harness.HIMARLEY_URL);
						} catch (Exception e) {
							ls_Msg = "Unable To Navigate to SYMBILITY_URL";
							ls_status = "Fail";
							LOG.error(ls_Msg);
						}
						break;
					case "HIMARLEY":

						String chrome_filepath = currDir + "\\src\\driverFactory\\" + "chromedriver.exe";

						System.setProperty("webdriver.chrome.driver", chrome_filepath);
						ChromeOptions options = new ChromeOptions();
						options.setExperimentalOption("useAutomationExtension", false);
						options.addArguments("start-maximized"); // added by moorthy(13/11/2018) to start the browser
																	// maximized

						try {
							if (driverCache.isDriverClosed(scr_driver)) {
								driverCache.setDriver(new ChromeDriver(options));
								scr_driver = driverCache.getDriver();
								scr_driver.manage().timeouts().implicitlyWait(defs.implicitwait, TimeUnit.SECONDS);

								scr_driver.navigate().to(Harness.HIMARLEY_URL);
							}

						} catch (Exception e) {
							ls_Msg = "Unable To Navigate to SYMBILITY_URL";
							ls_status = "Fail";
							LOG.error(ls_Msg + "");
						}
						break;
					case "LMS_IA_URL":   //added by puru for IA and LMS
						try {
						String chrome_filepath1 = currDir + "\\src\\driverFactory\\" + "chromedriver.exe";

						System.setProperty("webdriver.chrome.driver", chrome_filepath1);
						ChromeOptions options1 = new ChromeOptions();
						options1.setExperimentalOption("useAutomationExtension", false);
						options1.addArguments("start-maximized"); // added by moorthy(13/11/2018) to start the browser
																	// maximized

						
							if (driverCache.isDriverClosed(scr_driver)) {
								driverCache.setDriver(new ChromeDriver(options1));
								scr_driver = driverCache.getDriver();
								scr_driver.manage().timeouts().implicitlyWait(defs.implicitwait, TimeUnit.SECONDS);
						

							/*
							 * scr_driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"t");
							 * ArrayList<String> tabs = new ArrayList<String>
							 * (scr_driver.getWindowHandles()); scr_driver.switchTo().window(tabs.get(0));
							 * 
							 */
								
	 						         scr_driver.navigate().to(Harness.LMS_URL);
	 						        ls_status = "Pass";
	 						        lb_script_Continue = true;
							}
						} catch (Exception e) {
							ls_Msg = "Unable To Navigate to LMSand IA URL";
							ls_status = "Fail";
							LOG.error(ls_Msg + "");
							lb_script_Continue = true;
						}
						li_input = li_input + 1;
						break;
					case "CLAIM_LMS_URL":   //added by puru for IA and LMS
						try {
							
							
							String IE_filepath1 = currDir + "\\src\\driverFactory\\" + "IEDriverServer.exe";

							System.setProperty("webdriver.ie.driver", IE_filepath1);
							DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
							capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
							capabilities.setCapability("requireWindowFocus", true);
							capabilities.setCapability("nativeEvents", true);
							//capabilities.setCapability("unexpectedAlertBehaviour", false);
						
													   //Navigating to the application URL
							//driver.get(gs_url);						   //Navigating to the application URL
							
							ls_Msg="THE IE BROWSER IS SUCCESSFULLY INVOKED";
							ls_status="Pass";
							
							LOG.info("THE IE BROWSER IS SUCCESSFULLY INVOKED");

							if (driverCache.isDriverClosed(scr_driver)) {
								
								driverCache.setDriver(new InternetExplorerDriver(capabilities));     //TO Launch IE browser
//								driver = new InternetExplorerDriver();
								getDriver().manage().window().maximize();
								getDriver().manage().timeouts().implicitlyWait(defs.implicitwait, TimeUnit.SECONDS);//maximize browser window
								
								
								scr_driver = driverCache.getDriver();
								scr_driver.manage().window().maximize();
								scr_driver.manage().timeouts().implicitlyWait(defs.implicitwait, TimeUnit.SECONDS);
								scr_driver.manage().timeouts().pageLoadTimeout(defs.pageLoadTimeout, TimeUnit.SECONDS);
							/*
							 * scr_driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"t");
							 * ArrayList<String> tabs = new ArrayList<String>
							 * (scr_driver.getWindowHandles()); scr_driver.switchTo().window(tabs.get(0));
							 * 
							 */
								
	 						        scr_driver.navigate().to(defs.WTM_APP_URL);
	 						        ls_status = "Pass";
	 						        lb_script_Continue = true;
							}
						} catch (Exception e) {
							ls_Msg = "Unable To Navigate to Claim center URL";
							ls_status = "Fail";
							LOG.error(ls_Msg + "");
							lb_script_Continue = true;
						}
						li_input = li_input + 1;
						break;
					case "Pega":
						try {
							scr_driver.navigate().to(Harness.gs_url);
						} catch (Exception e) {
							ls_Msg = "Unable To Navigate to CMS";
							ls_status = "Fail";
							LOG.error(ls_Msg);
						}

					case "KCenter": // added by shan
						try {
							scr_driver.navigate().to(Harness.gs_KCenter_url);
						} catch (Exception e) {
							ls_Msg = "Unable To Navigate to KCenter";
							ls_status = "Fail";
							LOG.error(ls_Msg);
						}
						break;

					case "CMS":
						try {
							scr_driver.navigate().to(Harness.gs_url);
						} catch (Exception e) {
							ls_Msg = "Unable To Navigate to CMS";
							ls_status = "Fail";
							LOG.error(ls_Msg);
						}
						break;

					case "IportalGenius":
						try {
							scr_driver.navigate().to(Harness.gs_iPortalGenius_Url);
						} catch (Exception e) {
							ls_Msg = "Unable To Navigate to IportalGenius";
							ls_status = "Fail";
							LOG.error(ls_Msg);
						}
						break;

					case "CTP":
						try {
							obj_browser.BROWSER_INVOKEURL("FireFox", gs_url);
						} catch (Exception e) {
							ls_Msg = "Unable To Navigate to CTP";
							ls_status = "Fail";
							LOG.error(ls_Msg);
						} // END OF CATCH
						break;

					case "cChange":

						// Call gfn_BROWSER_INVOKEURL("IE", Environment.Value("gs_cC_url"),gs_bin_path)
						break;

					case "Tposmasterwitheffectivedate":
						try {
							// obj_browserclose.BROWSER_CLOSE("");
						} catch (Exception e) {
							ls_Msg = "Unable To Close the browser in Tposmasterwitheffectivedate";
							ls_status = "Fail";
							LOG.error(ls_Msg);
						} // END OF CATCH

						try {
							obj_browser.BROWSER_INVOKEURL("FireFox", gs_url);
						} catch (Exception e) {
							ls_Msg = "Unable To Navigate to Tposmasterwitheffectivedate";
							ls_status = "Fail";
							LOG.error(ls_Msg);
						} // END OF CATCH
						break;

					case "Tposmaster":

						// scr_driver= obj_browserclose.BROWSER_CLOSE("");

						if (scr_driver == null) {
							ScreenDriver.popup_driver = null;
							obj_browser.BROWSER_INVOKEURL("FireFox", "https://ptm.tpos.qbe.com/qbe/QBETravel");
							// scr_driver = Browser_Invoke_Url.getDriver();

						} else {
							scr_driver = null;
							obj_browser.BROWSER_INVOKEURL("FireFox", "https://ptm.tpos.qbe.com/qbe/QBETravel");
							// scr_driver = Browser_Invoke_Url.getDriver();
						}

						break;

					default:

						System.out.print("Default");
						break;
					}// switch

					break;

				case "COMPLETE_BTN": // added by MANI RAVI
					Check_Object_Enabled lss_check = new Check_Object_Enabled();
					boolean completeBtnDisplayed = false;
					try {
						if (li_input <= li_inputparamvalue) {
							if ((li_input == li_inputparamvalue) && (Harness.gs_Screenshot.equalsIgnoreCase("Yes"))) {
								Screenshot(scr_driver, componentname);
							}

							for (int li_loopinputparamvalue = 0; li_loopinputparamvalue <= li_inputparamvalue; li_loopinputparamvalue++) {

								ls_Parameter = input_key_lst.get(li_loopinputparamvalue);// Test case steps - Object
																							// name
								ls_Objvalue = input_value_lst.get(li_loopinputparamvalue);// Test case steps - value
																							// list

								if (ls_windowObj.trim().equalsIgnoreCase(ls_Parameter.trim())) {
									if (!ls_Objvalue.equalsIgnoreCase(defs.noActionvalue)) {
										obj_found = true;

										String disableCheckFlag="";
										WebElement completeBtn=null;
										
										ls_Seq_heading = GenericLibrary.getExcelData(filepath, ls_excel_sheet,excel_loop, 4);
										ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop,5); // Component TC1 valeu column
										
										try {
											boolean enable = false;
											//clicking the Header Check box
											scr_driver.findElement(By.xpath("//input[contains(@name,'ClaimWorkplan-ClaimWorkplanScreen-WorkplanLV-_Checkbox')]")).click();
											List<WebElement> li = scr_driver.findElements(By.xpath(
													"//div[contains(@id,'ClaimWorkplan-ClaimWorkplanScreen-WorkplanLV')]//input[@type='checkbox']"));

											System.out.println("Check Table check boxes:" + (li.size() - 1));
											
											for (int i11 = 1; i11 <= li.size() - 1; i11++) 
											{
												li.get(i11).click();
												//Muthu-Thread.sleep(defs.beforeObjectLoadTime);
												try {
													
													//div[contains(@class,'toolbarContents')]//a[@id='ClaimWorkplan:ClaimWorkplanScreen:ClaimWorkplan_CompleteButton']
													
													completeBtn = scr_driver.findElement(By.xpath(
														"(//div[contains(@id,\"ClaimWorkplan-ClaimWorkplanScreen-ClaimWorkplan_CompleteButton\")]/div)[1]"));
													disableCheckFlag=completeBtn.getAttribute("class"); //button_disabled or button
												} catch (Exception e) {
													// TODO Auto-generated catch block
													disableCheckFlag = "disabled";
												}
												if (disableCheckFlag.contains("disabled")) {
													li.get(i11).click();
												}
											}
											completeBtn.click();
										}

										catch (Exception e) {
											System.out.println(e);
											lb_script_Continue = false;
										} // end of catch statment

									} else if (ls_Objvalue.equalsIgnoreCase(defs.noActionvalue)) {
										li_input = li_input + 1;
										break;
									}
								}

								if (!lb_script_Continue) {
									break;
								}
							} // if of None

							// for input parameter exhaustion

							li_input = li_input + 1;
							if (li_input > li_inputparamvalue) {
								lb_inputvaluescompleted = true;

								ls_cmd = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop + 1, 3);
								if (ls_cmd == null)
									lb_popupcheck = true;
							} // if for lb_inputvaluescompleted
							break;
						} else {
							lb_inputvaluescompleted = true;
						}
					} catch (Exception e) {
						LOG.error("Exception Setproperty case statement in ScreenDriver Function - Complete Button");
						ls_Msg = "Exception Setproperty case statement in ScreenDriver Function - Complete Button";
						ls_status = "Fail";
					}
					break;

				case "Popup_Browser_Close":

					Pop_Up_Close obj_popupclose = new Pop_Up_Close();
					try {
						obj_popupclose.POPUP_CLOSE("");
						ScreenDriver.popup_driver = null;// Added by ambika on 11/2/2018
					} catch (Exception e) {
						ls_Msg = "EXCEPTION IN BROWSER CLOSE IN POPUP BROWSER CLOSE CASE STATMENT";
						ls_status = "Fail";
						LOG.error(ls_Msg);
					} // END OF CATCH

					if (li_input > li_inputparamvalue) {

						lb_inputvaluescompleted = true;
						try {
							ls_cmd = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop + 1, 3);
						} catch (Exception e) {
							ls_Msg = "EXCEPTION OF GETTING COMMAND IN POPUP BROWSER CLOSE CASE STATMENT";
							ls_status = "Fail";
							LOG.error(ls_Msg);
						} // END OF CATCH

						if (ls_cmd == null)
							lb_popupcheck = true;

					} // if for li_input
					break;

				case "TPOS_PDF_VALIDATION":

					if (li_output <= li_outputparamvalue) {
						li_tempoutputcount = li_outputparamvalue;

						for (int li_loopoutputparamvalue = 0; li_loopoutputparamvalue <= li_tempoutputcount; li_loopoutputparamvalue++) {
							ls_Parameter = input_key_lst.get(li_loopoutputparamvalue);
							ls_Objvalue = input_value_lst.get(li_loopoutputparamvalue);

							if (ls_windowObj.trim().equalsIgnoreCase(ls_Parameter.trim())) {
								try {
									ls_Seq_heading = GenericLibrary.getExcelData(filepath, ls_excel_sheet,
											li_loopoutputparamvalue, 4);
								} catch (Exception e) {
									ls_Msg = "EXCEPTION OF GETTING SEQUENCE HEADING IN TPOS PDF VALIDATION CASE STATMENT";
									ls_status = "Fail";
									LOG.error(ls_Msg);
								} // END OF CATCH
								try {
									ls_window = GenericLibrary.getExcelData(filepath, ls_excel_sheet,
											li_loopoutputparamvalue, 1);
								} catch (Exception e) {
									ls_Msg = "EXCEPTION OF GETTING WINDOW IN TPOS PDF VALIDATION CASE STATMENT";
									ls_status = "Fail";
									LOG.error(ls_Msg);
								} // END OF CATCH

								try {
									ls_TC1value = GenericLibrary.getExcelData(filepath, ls_excel_sheet, excel_loop, 5)
											.trim();
								} catch (Exception e) {
									ls_Msg = "EXCEPTION OF GETTING TC1 VALUE IN TPOS PDF VALIDATION  CASE STATMENT";
									ls_status = "Fail";
									LOG.error(ls_Msg);
								} // END OF CATCH

								ls_errorarray = ls_TC1value.split("\\|");
								ls_property = ls_errorarray[0];
								ls_value = ls_errorarray[1];

								// Call TPOS_PDF_VALIDATION(ls_window,ls_Objvalue,ls_optionflag)'// Check the
								// parameters to confirm

								li_output = li_output + 1;

								if (li_output >= li_tempoutputcount)
									lb_outputvaluescompleted = true;
								break;
							} // ls_windowobj

						} // input parameter and value assigned for

					} else
						lb_outputvaluescompleted = true;
					break;

				case "SELECTPRODUCTFORQF":

					obj_harness.gs_product = "FQ International comprehensive to maximum age 69";

					switch (obj_harness.gs_product) {

					case "New International comprehensive to maximum age 69":
						url = "https://ptm.tpos.qbe.com/qbe/QBETravel?genform=true&page=1&quotetype=2&productid=40496";
						break;

					case "New Australian comprehensive to maximum age 69":
						url = "https://ptm.tpos.qbe.com/qbe/QBETravel?genform=true&page=1&quotetype=2&productid=40295";
						break;

					case "New Annual multi trip to maximum age 69":
						url = "https://ptm.tpos.qbe.com/qbe/QBETravel?genform=true&page=1&quotetype=2&productid=40297";
						break;

					case "New Inbound":
						url = "https://ptm.tpos.qbe.com/qbe/QBETravel?genform=true&page=1&quotetype=2&productid=40304";
						break;

					case "FQ International comprehensive to maximum age 69":
						url = "https://ptm.tpos.qbe.com/qbe/QBETravel?genform=true&page=1&quotetype=1&productid=40496";
						break;

					case "FQ Australian comprehensive to maximum age 69":
						url = "https://ptm.tpos.qbe.com/qbe/QBETravel?genform=true&page=1&quotetype=1&productid=40295";
						break;

					case "FQ Annual multi trip to maximum age 69":
						url = "https://ptm.tpos.qbe.com/qbe/QBETravel?genform=true&page=1&quotetype=1&productid=40297";
						break;

					case "FQ Inbound":
						url = "https://ptm.tpos.qbe.com/qbe/QBETravel?genform=true&page=1&quotetype=1&productid=40304";
						break;

					default:
						break;

					}// end of switch-gs_product
					try {
						scr_driver.get(url);
					} catch (Exception e) {
						ls_Msg = "EXCEPTION OF GETTING URL IN SELECTPRODUCT CASE STATMENT";
						ls_status = "Fail";
						LOG.error(ls_Msg);
					} // END OF CATCH
					break;

				default:
					ls_Msg = "DEFAULT OF CASE STATMENT";
					ls_status = "Fail";
					LOG.error(ls_Msg);
					break;

				}// switch for commands (ls_cmd) read from screen

				/*
				 * if(!obj_found) { System.out.println("Obj not Found "+ls_window);
				 * ls_Msg=ls_windowObj+"is not found in Screen component"; ls_status="Fail";
				 * break; } else { ls_status="pass"; }
				 */
				if ((lb_outputvaluescompleted == true) && (lb_inputvaluescompleted == true)
						&& (lb_popupcheck == true)) {

					ls_time_out = "30";
					if (lb_nextscreen_index != -1) {
						ls_nextwindow = output_value_lst.get(lb_nextscreen_index);
						// LOG.info("ls_nextwindow"+ls_nextwindow);
						Next_Window obj_nextwindow = new Next_Window();

						// lb_status = obj_nextwindow.NEXT_WINDOW(lsKANCHSWelcome1_nextwindow+"#",
						// ls_time_out);
						try {

							lb_status = obj_nextwindow.NEXT_WINDOW(ls_nextwindow, ls_time_out, applicationName);
							if (lb_status) {
								ls_statusMsg = "The Next Window found Successfully";
								ls_status1 = "Pass";
							} else {
								lb_script_Continue = false;
								ls_statusMsg = "The Next Window does not found ";
								ls_status1 = "Fail";
							}
						} catch (Exception e) {
							LOG.error("EXCEPTION OF CALLING NEXT WINDOW");
						} // END OF CATCH

					} // if of lb_next_screen_index !=1
					break;
				} // if of lb_outputvaluescompleted

			} // For number of rows in the screen component file

			// to make the input and output list(Testcase 1st Row - object and value) empty
			// for next iteration
			input_key_lst = null;
			input_value_lst = null;
			output_key_lst = null;
			output_value_lst = null;
			tableRows = null;
			tablecolumns = null;

		} catch (EncryptedDocumentException e1) {
			ls_Msg = "EncryptedDocumentException of WorkbookFactory in Get_Object_Identifier";
			ls_status = "Fail";
			LOG.error(ls_Msg);
		} catch (InvalidFormatException e1) {
			ls_Msg = "InvalidFormatException  of WorkbookFactory in Get_Object_Identifier";
			ls_status = "Fail";
			LOG.error(ls_Msg);
		} catch (IOException e1) {
			ls_Msg = "IOException of WorkbookFactory in Get_Object_Identifier";
			ls_status = "Fail";
			LOG.error(ls_Msg);

		} finally {
			if (open_excel_file != null)
				try {
					open_excel_file.close();

					// timestamp.close();
				} catch (IOException e) {
					System.out.println(e);
					LOG.error("IOException of closing File in Screen Driver Function");
				} // closing the excel file
		}
		/*
		 * if((report_type.equals("DETAIL"))&&(ls_status.equals("Fail"))) { //for Excl
		 * DETAIL reporting report_data.add(ls_Functionname);
		 * report_data.add(ls_windowObj); report_data.add(""); report_data.add("");
		 * report_data.add(ls_Msg); report_data.add(ls_status);
		 * GenericLibrary.Report(report_file,report_data ); Assert.assertTrue(obj_found,
		 * ls_windowObj+"is not found in Screen component"); }//if of report
		 */
		// VALIDATION
		System.out.println(lb_status);
//	   Assert.assertTrue(lb_status, "THE NEXT WINDOW IS NOT AVAILABLE");

		return lb_status;
	}// method

	public void Screenshot(WebDriver driver, String ls_window) {
		File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

		DateFormat Date_Time = new SimpleDateFormat("dd-MM-YYYY HH-mm-ss");
		Date date1 = new Date();
		String date_time = Date_Time.format(date1);
		date_time = date_time.replaceAll("/", "");
		//File ss = new File(file + "/resultFolder/ScreenShot/" + Harness.ls_Testcaseid + "_" + date + "/" + ls_window + date_time);

		BaseTest bt=new BaseTest();
		ExtentTest er=bt.getLogger();
		try {
			// now copy the screenshot to desired location using copyFile //method

			//String file = Harness.gs_root_path;
			//String snnapshotPathname=screenShot + "/" + ls_window + "_" + date_time + ".png";
			//FileUtils.copyFile(src, new File(snnapshotPathname));
			String snnapshotPathname1="";
			String screenShotFailurePath1="";
			if(!ls_window.contains("Failure"))
			{
				snnapshotPathname1=screenShot1 + "/" + ls_window + "_" + date_time + ".png";
				FileUtils.copyFile(src, new File(snnapshotPathname1));
			}
			else
			{
				screenShotFailurePath1=screenShotFailure1 + "/" + "Failed_Step" + "_" + date_time + ".png";
				FileUtils.copyFile(src, new File(screenShotFailurePath1));
				//snnapshotPathname1=screenShot1 + "/" + ls_window + "_" + date_time + ".png";
				//FileUtils.copyFile(src, new File(snnapshotPathname1));
				
				er.log(Status.FAIL, MarkupHelper.createLabel("Failed Test step", ExtentColor.RED));
				//er.log(Status.FAIL, MarkupHelper.createLabel("Failed Test step", ExtentColor.RED));
				er.addScreenCaptureFromPath(screenShotFailurePath1);
			}
			// ru.yandex.qatools.ashot.Screenshot fpScreenshot = new
			// AShot().shootingStrategy(ShootingStrategies.viewportPasting(10000)).takeScreenshot(driver);
			/*
			 * //String ss =
			 * file+"ScreenShot/"+Harness.ls_Testcaseid+"_"+date+"/"+ls_window+"_"+date_time
			 * +"/"; ImageIO.write(fpScreenshot.getImage(), "PNG", new File(ss+"/img.png"));
			 */

		}

		catch (IOException e) {
			/*
			 * methodreport_data=null; LOG.error(e.getMessage());
			 * if(report_type.equals("DETAIL")) { //for Excl DETAIL reporting
			 * methodreport_data.add("SETPROPERTY"); methodreport_data.add("ScreenShot");
			 * methodreport_data.add(""); methodreport_data.add("");
			 * methodreport_data.add("Unable to take the screen shot");
			 * methodreport_data.add("Fail");
			 * obj_Generic.Report(report_file,methodreport_data ); }//if of report
			 */

		}
	}
	
	public static String getScreenhot(WebDriver driver, String screenshotName) throws Exception {
		String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		TakesScreenshot ts = (TakesScreenshot) driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
                //after execution, you could see a folder "FailedTestsScreenshots" under src folder
		String destination = System.getProperty("user.dir") + "/FailedTestsScreenshots/"+screenshotName+dateName+".png";
		File finalDestination = new File(destination);
		FileUtils.copyFile(source, finalDestination);
		return destination;
	}
	public RemoteWebDriver getDriver() {
		return Browser_Invoke_Url.driver;
	}

	public static void setDriver(RemoteWebDriver driver) {
		Browser_Invoke_Url.driver = driver;
	}
	
	public boolean isDriverClosed(WebDriver scr_driver) {
		boolean IEDriverClosed=false;
		try
		{
			scr_driver.close();
			scr_driver.quit();
			IEDriverClosed=true;
		}catch(Exception E)
		{
			System.out.println("Exception has been occured while replacing the Driver");
			IEDriverClosed=false;
		}
		return IEDriverClosed;
				
	}
}// class