package Core_Lib;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class GeniusSelectionMenu
{
	public static void GeniusSelection() throws NoSuchElementException
	{
		//LOGGER
		Logger LOG = Logger.getLogger(ScreenDriver.class.getName());
		GenericLibrary obj_Generic = new GenericLibrary();
		 String report_file = Harness.report_testcase;
		 List<String> report_data = new ArrayList<String>();
		  String report_type=Harness.ls_ReportingType;
		 String ls_Functionname="SET_PROPERTY";
		 String ls_Msg=null;
		 String ls_status=null;

		
		WebElement enter_btn=null;
		WebDriver driver = ScreenDriver.scr_driver;
		String selection_option = Harness.genius_selection_option;
		WebElement option_text = null;
	try
	{
		if(Harness.selection_menu)
		{
			option_text = driver.findElement(By.xpath("//input[@name='_F1527']"));
			option_text.sendKeys(selection_option);
			enter_btn = driver.findElement(By.xpath("//input[@value='Enter']"));
			enter_btn.click();
			Harness.selection_menu=false;
			ls_Msg="The Option Text has entered successfully";
			ls_status="Pass";
		}//if of selection menu
		}catch(Exception e)
		{
			ls_Msg="EXCEPTION IN GENIUS SELECTION FUNCTION";
			ls_status="Fail";
			LOG.info("EXCEPTION IN GENIUS SELECTION FUNCTION");	
		}
		if(report_type.equals("DETAIL"))
		{
			//for Excl DETAIL reporting
			report_data.add(ls_Functionname);
			report_data.add("");
			report_data.add("");
			report_data.add("");
			report_data.add(ls_Msg);
			report_data.add(ls_status);
			obj_Generic.Report(report_file,report_data );
		}//if of report
		}//fn end
			
		
	}//end of class

			
				
	/*	if(option_text!=null ) 
		{
			try
			{
				table  = driver.findElement(By.xpath("//table[@class='TOptions2']"));
			}catch(Exception e)
			{
				ls_Msg="EXCEPTION OF FINDING THE TABLE IN GENIUS SELECTION ";
				ls_status="Fail";
				LOG.info("EXCEPTION OF FINDING THE TABLE IN GENIUS SELECTION ");	
			}
			if(table!=null)
			{
				try
				{
				 option_text = driver.findElement(By.xpath("//input[@name='_F1527']"));
				 
				}catch(Exception e)
				{
					ls_Msg="EXCEPTION OF FINDING OPTION TEXT BOX IN GENIUS SELECTION FUNCTION";
					ls_status="Fail";
					LOG.error("EXCEPTION OF FINDING OPTION TEXT BOX IN GENIUS SELECTION FUNCTION");
				}//CATCH
				
			}//if of table
			
			

		}//if of option_text	
*/	