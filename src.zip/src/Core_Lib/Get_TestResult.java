package Core_Lib;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Get_TestResult 
{
       
	public void gfn_Override_TestResult(String filePath, String fileName) throws IOException   
	{
		String ls_TestResultPath = filePath+"/"+fileName+".xlsx";
		File file = new File(ls_TestResultPath);
		
		if(file.exists()) 
		{
	
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");

			String lastmodifiedDateFile = sdf.format(file.lastModified());
			
			lastmodifiedDateFile = lastmodifiedDateFile.replace("/", "-");
			lastmodifiedDateFile = lastmodifiedDateFile.replace(":", "-");
			
			System.out.println(lastmodifiedDateFile);
				
			
			String newFilepath =  filePath+"/"+fileName+"_"+lastmodifiedDateFile+".xlsx";
//			System.out.println(newFilepath);
			
			File newFile = new File(newFilepath);
			file.renameTo(newFile);
		}
	} // method close
	
	public void gfn_Get_TestResult(String filePath, String fileName) throws IOException   
	{
		String ls_TestResultPath = filePath+"/"+fileName+".xlsx";
		File file = new File(ls_TestResultPath);
		
		if(file.exists()) 
		{
	
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
			
//			System.out.println("After Format : " + sdf.format(file.lastModified()));
			
			String lastmodifiedDateFile = sdf.format(file.lastModified());
			
			lastmodifiedDateFile = lastmodifiedDateFile.replace("/", "-");
			lastmodifiedDateFile = lastmodifiedDateFile.replace(":", "-");
			
			System.out.println(lastmodifiedDateFile);
				
			String newFilepath =  filePath+"/"+fileName+"_"+lastmodifiedDateFile+".xlsx";
//			System.out.println(newFilepath);
			
			File newFile = new File(newFilepath);
			file.renameTo(newFile);
		}
//		return newFilepath;
	} // method close

	//Main function is calling readExcel function to read data from excel file
	public static void main(String[] args) throws IOException
	{
		String filePath = "C:/BAU_SELENIUM_AUTOMATION/Automation_Project/src/ODM/Report";
				
		Get_TestResult obj = new Get_TestResult();
		obj.gfn_Get_TestResult(filePath, "TC002_NB_For_BritishMarineHull");
	}
}