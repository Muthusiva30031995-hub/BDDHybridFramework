package Core_Lib;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import Core_Lib.Harness;

public class ReadFromXLSX {
   public  void readFromExcel(ArrayList<String> arr_list, int arr_size,ArrayList<String> Form_Prem) throws Exception {

	   int form_i = 0;
      //Create blank workbook
	   
	   String CasePath = Harness.gs_case_path;
	   String tetcaseName = Harness.report_testcase;
		String DBValidationSheetName = CasePath+"\\"+tetcaseName+"_DB.xlsx";
	   String DataSheetPath = DBValidationSheetName;
	   String policynumbertxt;
		FileInputStream inputStream = new FileInputStream(new File(DataSheetPath));
		XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
      
      
      //Create a blank sheet
      XSSFSheet spreadsheet = workbook.getSheet( "EndorsmentValues");

      //Create row object
      
      int rowid = 1;
      int row_id2 = 1;
      XSSFRow row;
	//This data needs to be written (Object[])
      /*Map < String, ArrayList > forminfo = new TreeMap < String, ArrayList >();
      for(form_i = 0;form_i<=arr_size;form_i++)
      {
    	 
		String form_j = String.valueOf(form_i);
    	  forminfo.put(form_j, (ArrayList) arr_list.get(form_i));
      }*/
      
      ArrayList<String> al= new ArrayList<String>();
      al.addAll(arr_list);
      al.addAll(Form_Prem);
      //////////////////////ARUN Premium Compare Code//////////////////////////////////////
      Map< String,String> hm = new HashMap< String,String>();
      Map< String,String> hm1 = new HashMap< String,String>();
      int i=0;
      for(String abc : arr_list)
      {
    	  
    	  hm1.put(abc, Form_Prem.get(i));
    	  i++;
      }
      ArrayList<String> FormNumberDB=new ArrayList<String>();
      ArrayList<String> FormPremiumDB=new ArrayList<String>();
      Iterator<Row> rowIterator = spreadsheet.rowIterator();
      DataFormatter dataFormatter = new DataFormatter();
      int ii=0;
      while (rowIterator.hasNext()) {
          Row row1 = rowIterator.next();
          if(i!=0)
          {
          // Now let's iterate over the columns of the current row
          Iterator<Cell> cellIterator = row1.cellIterator();
          Cell cell = row1.getCell(6);
          Cell cell2 = row1.getCell(10);
          
          String cellValue = dataFormatter.formatCellValue(cell);
          String cellValue2 = dataFormatter.formatCellValue(cell2);
          
          System.out.print(cellValue + "\t");
          System.out.print(cellValue2 + "\n");
          if(cellValue!="")
        	  FormNumberDB.add(cellValue);
          if(cellValue2!="")
        	  FormPremiumDB.add(cellValue2);
      	}
         i++;
      }
      int row_num1=1;
      int row_count1 = spreadsheet.getPhysicalNumberOfRows();
      for(int a=1;a<FormNumberDB.size();a++)
	  {
    	  String PremPDF = hm1.get(FormNumberDB.get(a));
    	  /*if()*/
    	  String FormNumPDF = FormNumberDB.get(a);
    	  
          row = spreadsheet.getRow(row_num1++);
          
          if(row_num1==0)
          {
          /*XSSFRow row2 = spreadsheet.createRow(0);*/
          Cell cell_static= row.createCell(12);
          cell_static.setCellValue("Form Number");
          Cell cell_static1= row.createCell(13);
          cell_static1.setCellValue("Premium Value");
          }
          else
          {
        	  Cell cell_static= row.createCell(12);
              cell_static.setCellValue(FormNumPDF);
              Cell cell_static1= row.createCell(13);
              
	          if(PremPDF.equals(""))
	          {
	        	  cell_static1.setCellValue("INCL");
	          }
	          else if(PremPDF.contains("$"))
	          {
	        	  
	        	  PremPDF = PremPDF.replace("$","");
	        	  PremPDF = PremPDF.replace(",","");
	        	  PremPDF = PremPDF.trim();
		    	  if(PremPDF.contains("."))
		    	  {
		    	  
		    		  cell_static1.setCellValue(PremPDF);
		    	  }
		    	  else
		    	  {
		    		  PremPDF = PremPDF+".00";
		    		  cell_static1.setCellValue(PremPDF);
		    	  }
		    	  }
	          else
	        	  cell_static1.setCellValue(PremPDF);
	          
              
          }
    	  
	  }
	     
      /////////////////////////////ARUN COMPARE CODE END////////////////////////
      /*int Size_of_Form = arr_list.size();
      System.out.println(al.size());
      int loop_i = 1;
      
      int row_num=0;
      row = spreadsheet.getRow(row_num++);
      int row_count = spreadsheet.getPhysicalNumberOfRows();
      System.out.println(row_count);
      XSSFRow row2 = spreadsheet.createRow(0);
      Cell cell_static= row.createCell(12);
      cell_static.setCellValue("Form Number");
      Cell cell_static1= row.createCell(13);
      cell_static1.setCellValue("Premium Value");
      //System.out.println(al.get(23));
      for(String abc : al)
      {
    	  if(loop_i<=Size_of_Form)
    	  {
    		  loop_i++;
    		  if(row_count>loop_i)
    		  {
    			  row = spreadsheet.getRow(row_num++);
    		  }
    		  else
    		  {
    			  row = spreadsheet.createRow(row_num++);
    		  }
	          int cellid = 0;
	          Cell cell = row.createCell(12);
	          cell.setCellValue(abc);
	          System.out.println(abc);
	          int cellid1 = 1;
	          Cell cell1 = row.createCell(13);
	          String prem = al.get(Size_of_Form+(loop_i-2));
	          if(prem.equals(""))
	          {
	        	  cell1.setCellValue("INCL");
	          }
	          else if(prem.contains("$"))
	          {
	        	  
	        	  prem = prem.replace("$","");
	        	  prem = prem.replace(",","");
	        	  prem = prem.trim();
		    	  if(prem.contains("."))
		    	  {
		    	  
		    		  cell1.setCellValue(prem);
		    	  }
		    	  else
		    	  {
		    		  prem = prem+".00";
		    		  cell1.setCellValue(prem);
		    	  }
		    	  }
	          else
	          cell1.setCellValue(al.get(Size_of_Form+(loop_i-2)));
	          
	          System.out.println(al.get(Size_of_Form+(loop_i-2)));
          
    	  }
    	  
    	  else
    	  {
    		  break;
    	  }
      }
      */
      

           //Write the workbook in file system
      FileOutputStream out = new FileOutputStream(new File(DBValidationSheetName));
      
      workbook.write(out);
      out.close();
      System.out.println("Writesheet.xlsx written successfully");
   }
}