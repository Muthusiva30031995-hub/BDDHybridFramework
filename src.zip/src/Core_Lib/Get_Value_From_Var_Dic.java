package Core_Lib;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.testng.Assert;


//This function retrieves a stored value from Dictonary.
public class Get_Value_From_Var_Dic
{
	Map<String, String> variable_values = new LinkedHashMap<String, String>();//This map is used to store values from text file
	public static String value;
	
        public  String GET_VALUE_FROM_VAR_DIC ( String ls_Dictionary) 
        {
        	//LOGGER
    		Logger LOG = Logger.getLogger(Get_Value_From_Var_Dic.class.getName());
    		
    		//Detail Reporting
   		 GenericLibrary obj_Generic = new GenericLibrary();
   		 String report_file = Harness.report_testcase;
   		 List<String> report_data = new ArrayList<String>();
   		 String report_type=Harness.ls_ReportingType;
   		 String ls_Functionname="GET_VALUE_FROM_VAR_DIC";
   		 String ls_Msg=null;
   		 String ls_status=null;
    		
    	   String ls_Value;
    	   String line;
    	   boolean fileExists=false;
    	   
    	  // ls_Value = ls_Dictionary;
    	  // ls_Dictionary =ls_Value.substring(1, ls_Value.length());
    	   	    	   	
    	   //'Check for the Variable existence in Dictionary -  Stored Nums	
    	   File_Exists obj_FileExists = new File_Exists();
    	   String data_path=  Harness.gs_data_path;	//This vaiable halds the path of Data_Lib
    	   String filename =data_path + "/StoredNums.txt";
    	   
    	  //Calling File_Exists Fuction
    		fileExists=obj_FileExists.FILE_EXISTS(filename);
    	  
    	   //Validation
    	   Assert.assertTrue(fileExists, "The StoredNum File is not Found in Get valueFrom Var Dic Function");
    	   
    	   BufferedReader br = null;
    	   try 
    	   {
    		   br = new BufferedReader(
			        new InputStreamReader(new FileInputStream(filename)));
    	   
				while ((line = br.readLine()) != null)
				{
					String[] ls_line = line.split(",");//After readin from text file spiliting usinf , and storing in an array
	     
					for (int j = 0; j < ls_line.length; j++)
					{
						// put the key and value in map
						variable_values.put(ls_line[0], ls_line[1]);//the array values are convert into key & values and stored in map

					}// for of map
						
				}//END OF WHILE
					
  		 		for (String key : variable_values.keySet()) 
  		 		{
  		 			if(key.equals(ls_Dictionary))
  		 			{
  		 				LOG.info("The Item "+ ls_Dictionary + " Exists in VariableValues Dictionary");
  		 				value = variable_values.get(key);
  		 					
  		 			}else
  		 			 {
  		 				//Reporting 
  		 				LOG.error("The Item  "+ ls_Dictionary+ " does not Exists in VariableValues Dictionary.");
  		 				break;
  		 			 }//else of key
  		 			
  		 		
  		 		}// for of key
  		} catch (IOException e)
			{
				LOG.error("Exception in Reading the Storednum file of GetValueFromVarDic Function");
			
  		 	}finally
  		 	 {
  		   
				try {
					br.close();
				} catch (IOException e)
					{
						LOG.error("Exception in Closing the StoredNum file in  GetValueFromVarDic Function");

					}//END OF CATCH
			
  		 	 }//finally 
    	   if(value!=null)
    	   {
    		   ls_Msg="The Value is available in the Dictionary";
    		   ls_status="Pass";
    	   }
    	   else
    	   {
    		   ls_Msg="The  variable value  is null in Get Value From VAr Dic Function";
    		   ls_status="Fail";
    		   // updated by shanmugakumar N
    		   if(report_type.equals("DETAIL")) 
    	   		{
    	   			//for Excl DETAIL reporting
    	   			report_data.add(ls_Functionname);
    	   			report_data.add("");
    	   			report_data.add("");
    	   			report_data.add(value);
    	   			report_data.add(ls_Msg);
    	   			report_data.add(ls_status);
    	   			obj_Generic.Report(report_file,report_data );
    	   		}//if of report
    	   }
 
    	   //VALIDATION
	 		Assert.assertNotNull(value, "The  variable value  is null in Get Value From VAr Dic Function");
	 		
           // Assigning value to function
    	   return value;
    	
     }// GET_VALUE_FROM_VAR_DIC
        
        
	public Map<String, String> get_dic_map()
	{
			return variable_values;
	}
	
}//end class
