package Core_Lib;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.BufferedInputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Timestamp;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Row;
import org.apache.log4j.Logger;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.*;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
//import org.apache.poi.ss.examples.CellStyleDetails;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import tests.BaseTest;

//This class has  the methods used in selenium Library
public class GenericLibrary
{	
	static //LOGGER
	Logger LOG = Logger.getLogger(GenericLibrary.class.getName());
	ReportingDataBase ReportDB = new ReportingDataBase();
	//Excl Reporting
		public  static Workbook workbook=new XSSFWorkbook();
		public static String ls_statusdata = "Pass";
		public  static Sheet sheet = null;
		public static Set<String> handles = null;
		public static String handle = null;
		//Excl Reporting
		//public static Sheet sheet =workbook.createSheet("Sheet1");
		public int  rowNum ;
		Random obj_Rnd = new Random(); 
		public static String pdf_filename;
		public  static int lirow;
		
						
	//This method is used to shift the contorl from parent window to child window
	public static void shiftContrlToChildWindow(WebDriver driver) 
	{
		 String pdf_filename;
		// Child Window
		 Set<String> handles = null;
		 String handle = null;
		 WebDriver popup=null;
		
		try
		{
			handle = driver.getWindowHandle();	//Getting the Parent window handle
		}catch(Exception e)
		{
			LOG.error("Not able to get the handle of the window in Generic library function");		
		}//END OF CATCH STMT
		
		try
		{
			handles = driver.getWindowHandles();// To get both parent and child window handle
		}catch(Exception e)
		{
			LOG.error("Not able to get the multiple  window Handle in Generic library function");		
		}//END OF CATCH
		
		Iterator<String> windowIterator = handles.iterator();
		
		 while(windowIterator.hasNext()) 
		 { 
		    String windowHandle = windowIterator.next(); 
		    		   
		    if (!windowHandle.equals(handle))
		    {
		    	try
		    	{
		    		ScreenDriver.popup_driver = driver.switchTo().window(windowHandle);
		    	}catch(Exception e)
		    	{
		    		LOG.error("UNABLE TO SHIFT THE CONTROL CHILD WINDOW IN GENERIC LIBRARY FUNCTION");
		    	}
				 break;
		    }//IF OF WINDOW HANDLE
		  
		  }//WHILE STMT
			
	}//METHOD END
	
	
	//Added by Yathish to switch to a specific window - 11/22/2017
		public static void shiftContrlToChildWindow(WebDriver driver, String pattern) 
		{
			
			// Child Window
			 Set<String> handles = null;
			 String handle = null;
			 WebDriver popup=null;
			
			 
			try
			{
				//Muthu-Thread.sleep(4000);
	 			handle = driver.getWindowHandle();	//Getting the window handles
			}catch(Exception e)
			{
				LOG.error("Not able to get the handle of the window in Generic library function");		
			}//END OF CATCH STMT
			
			try
			{
				handles = driver.getWindowHandles();
			}catch(Exception e)
			{
				LOG.error("Not able to get the multiple  window Handle in Generic library function");		
			}//END OF CATCH
			
			Iterator<String> windowIterator = handles.iterator();
			
			 while(windowIterator.hasNext()) 
			 {
			
			/*for(String win : handles){*/
			  String windowHandle = windowIterator.next();
				//String windowHandle = win;
			    		   
			 if (!windowHandle.equals(handle))
			    {
			    	try
			    	{
			    		
			    		driver.switchTo().window(windowHandle);
			    		
			    		try 
	    		 		{ 
					    	Alert ls_alert = driver.switchTo().alert();
					    	ls_alert.accept();
					    //	driver.switchTo().window(windowHandle);
					    }   // try 
					    catch (NoAlertPresentException Ex) 
					    { 
					    	
					    	Ex.getMessage();
					        System.out.println("No Alert");
					    }   // catch
			    		
			    		driver.manage().window().maximize();
			    		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			    		String pagesource = driver.getPageSource().toString();
			    		if(pagesource.contains(pattern))
			    		{
			    			LOG.info("The control moved to window with pattern "+pattern);
			    			break;
			    		}
			    	}catch(Exception e)
			    	{
			    		LOG.error("UNABLE TO SHIFT THE CONTROL CHILD WINDOW IN GENERIC LIBRARY FUNCTION");
			    		
			    	}
			//		 break;
			 }//IF OF WINDOW HANDLE
			  
			  }//WHILE STMT
				
		}//METHOD END
		
		
		public static void shiftContrlToParentWindow(WebDriver driver, String pattern)
		{ 
			Set<String> handles = null;
			 String handle = null;
			 WebDriver popup=null;
			
			
			try
			{
				handles = driver.getWindowHandles();
			}catch(Exception e)
			{
				LOG.error("Not able to get the multiple  window Handle in Generic library function");		
			}//END OF CATCH
			
			Iterator<String> windowIterator = handles.iterator();
			
			 while(windowIterator.hasNext()) 
			 { 
			    String windowHandle = windowIterator.next(); 
			    
			    	try
			    	{
			    		
			    		driver.switchTo().window(windowHandle);
			    		driver.manage().window().maximize();
			    		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			    		String pagesource = driver.getPageSource().toString();
			    		if(pagesource.contains(pattern))
			    		{
			    			LOG.info("The control moved to window with patter"+pattern);
			    			break;
			    		}
			    	}catch(Exception e)
			    	{
			    		LOG.error("UNABLE TO SHIFT THE CONTROL PARENT WINDOE IN GENERIC LIBRARY FUNCTION");
			    		
			    	}
					 break;
			    
			  
			  }//WHILE STMT
							  
		}//METHOD END
		
		
	
	// PDF FUNCTIONS
	
	public static void shiftContrlToPdfWindow(WebDriver driver, String pattern) 
	{
		
		// Child Window
		 Set<String> handles = null;
		 String handle = null;
		 WebDriver popup=null;
		
		try
		{
			handle = driver.getWindowHandle();	//Getting the window handles
		}catch(Exception e)
		{
			LOG.error("Not able to get the handle of the window in Generic library function");		
		}//END OF CATCH STMT
		
		try
		{
			handles = driver.getWindowHandles();
		}catch(Exception e)
		{
			LOG.error("Not able to get the multiple  window Handle in Generic library function");		
		}//END OF CATCH
		
		Iterator<String> windowIterator = handles.iterator();
		
		 while(windowIterator.hasNext()) 
		 {
		
		/*for(String win : handles){*/
		  String windowHandle = windowIterator.next();
			//String windowHandle = win;
		    		   
		 if (!windowHandle.equals(handle))
		    {
		    	try
		    	{
		    		
		    		driver.switchTo().window(windowHandle);
		    		
		    		driver.manage().window().maximize();
		    		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		    		//Muthu-Thread.sleep(3000);
		    		String Current_url = driver.getCurrentUrl();
		    		System.out.println(Current_url);
		    		boolean url_validate = Current_url.contains("pdf");
		    		
		    			Assert.assertTrue(url_validate, "URL contains pdf");
		    		
		    			
		    		URL TestURL = new URL(Current_url);  
		    		//Muthu-Thread.sleep(4000);
		    		BufferedInputStream TestFile = new BufferedInputStream(TestURL.openStream());
		    		PDFParser TestPDF = new PDFParser(TestFile);
		    		//Muthu-Thread.sleep(2000);
		    		TestPDF.parse();
		    		//Muthu-Thread.sleep(8000);
					String TestText = new PDFTextStripper().getText(TestPDF.getPDDocument());
					//Muthu-Thread.sleep(12000);
					System.out.println(TestText);
		    		if(TestText.toLowerCase().contains(pattern.toLowerCase()))
		    		{
		    			LOG.info("pdf validation matched"+pattern);
		    		}
		    		else
		    		{
		    			LOG.error("PDF Valition didnot matched, text was not found");
		    			System.out.println("PDF validation not present");
		    		}
					
		    		
		    	}catch(Exception e)
		    	{
		    		LOG.error("UNABLE TO SHIFT THE CONTROL CHILD WINDOW IN GENERIC LIBRARY FUNCTION");
		    		
		    	}
		//		 break;
		 }//IF OF WINDOW HANDLE
		  
		  }//WHILE STMT
			
	}//METHOD END
	
	public static void savePdfWindow(WebDriver driver, String pattern) 
	{
		 
		
		// Child Window
		 Set<String> handles = null;
		 String handle = null;
		 WebDriver popup=null;
		 
		try
		{
			handle = driver.getWindowHandle();	//Getting the window handles
			
		}catch(Exception e)
		{
			LOG.error("Not able to get the handle of the window in Generic library function");		
		}//END OF CATCH STMT
		
		try
		{
			handles = driver.getWindowHandles();
		}catch(Exception e)
		{
			LOG.error("Not able to get the multiple  window Handle in Generic library function");		
		}//END OF CATCH
		
		Iterator<String> windowIterator = handles.iterator();
		
		 while(windowIterator.hasNext()) 
		 {
		
		for(String win : handles){
		  String windowHandle = windowIterator.next();
			String windowHandle1 = win;
		    	   
		 if (!windowHandle1.equals(handle))
		    {
			 	driver.switchTo().window(windowHandle1);
			 	String win_tile = driver.getTitle();
		    	if(win_tile.contains(pattern))
			
			 try
		    	{
		    		
		    		
		    		
		    		driver.manage().window().maximize();

		    		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		    		//Muthu-Thread.sleep(3000);
		    		String Current_url = driver.getCurrentUrl();
		    		String current_title = driver.getTitle();
		    		System.out.println(Current_url);
		    		
		    		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
	            	System.out.println(timestamp);
	            	Date date = new Date();
	            	String Time_Stamp = Long.toString(timestamp.getTime());
	            	
		    		pdf_filename = Harness.ls_Testcaseid+Time_Stamp;
		    		
		    		StringSelection stringSelection = new StringSelection(pdf_filename);
		            Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		            clipboard.setContents(stringSelection, stringSelection);
		            
		            
		          //  String finalPDFPath= defaultPath + "/GetPayment.pdf";
		            try {
		            	
		            	
		            	//Muthu-Thread.sleep(4000);
		                Robot r = new Robot();

		                // Open the Pop Up
		                r.keyPress(KeyEvent.VK_CONTROL);
		                r.keyPress(KeyEvent.VK_SHIFT);
		                r.keyPress(KeyEvent.VK_S);
		                r.keyRelease(KeyEvent.VK_S);
		                r.keyRelease(KeyEvent.VK_SHIFT);
		                
		                r.keyRelease(KeyEvent.VK_CONTROL);
		                //Muthu-Thread.sleep(4000);
		                
		                r.keyPress(KeyEvent.VK_CONTROL);
		                r.keyPress(KeyEvent.VK_V);
		                r.keyRelease(KeyEvent.VK_V);
		                r.keyRelease(KeyEvent.VK_CONTROL);
		                //Muthu-Thread.sleep(2000);
		                String defaultPath = System.getProperty("user.dir")+"/QBE_NA_XM Regression Test Automation/Data_Lib";
			    		StringSelection stringSelection1 = new StringSelection(defaultPath);
			            Clipboard clipboard1 = Toolkit.getDefaultToolkit().getSystemClipboard();
			            clipboard1.setContents(stringSelection1, stringSelection1);
			            //Muthu-Thread.sleep(2000);
		                // Reach to the URL bar
		                for (int i = 0; i < 5; i++) {
		                    r.keyPress(KeyEvent.VK_TAB);
		                    r.keyRelease(KeyEvent.VK_TAB);
		                }
		                // Paste the copied default ULR
		                r.keyPress(KeyEvent.VK_ENTER);
		                //Muthu-Thread.sleep(4000);
		                r.keyPress(KeyEvent.VK_CONTROL);
		                r.keyPress(KeyEvent.VK_V);
		                r.keyRelease(KeyEvent.VK_V);
		                r.keyRelease(KeyEvent.VK_CONTROL);
		                // Save the file
		                for (int i = 0; i < 5; i++) {
		                    //Muthu-Thread.sleep(2000);
		                    r.keyPress(KeyEvent.VK_ENTER);
		                }

		            } catch (AWTException e) {
		                // TODO Auto-generated catch block
		                e.printStackTrace();
		            } catch (Exception e) {
		                // TODO Auto-generated catch block
		                e.printStackTrace();
		            }
		        
		    }
		    			
		    		
		    		
		    	catch(Exception e)
		    	{
		    		LOG.error("UNABLE TO SHIFT THE CONTROL CHILD WINDOW IN GENERIC LIBRARY FUNCTION");
		    		
		    	}
		//		 break;
		 }//IF OF WINDOW HANDLE
		  
		  }
		 }//WHILE STMT
			
	}//METHOD END
	
	public static void shiftContrlToPdfCurrentWindow(WebDriver driver, String pattern) 
	{
		
		// Child Window
		 Set<String> handles = null;
		 String handle = null;
		 WebDriver popup=null;
		
		try
		{
			handle = driver.getWindowHandle();	//Getting the window handles
		}catch(Exception e)
		{
			LOG.error("Not able to get the handle of the window in Generic library function");		
		}//END OF CATCH STMT
		
		try
		{
			handles = driver.getWindowHandles();
		}catch(Exception e)
		{
			LOG.error("Not able to get the multiple  window Handle in Generic library function");		
		}//END OF CATCH
		
		
		    	try
		    	{
		    		driver.manage().window().maximize();
		    		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		    		//Muthu-Thread.sleep(3000);
		    		String Current_url = driver.getCurrentUrl();
		    		System.out.println(Current_url);
		    		boolean url_validate = Current_url.contains("pdf");
		    		
		    			Assert.assertTrue(url_validate, "URL contains pdf");
		    		
		    		URL TestURL = new URL(Current_url);  
		    		//Muthu-Thread.sleep(4000);
		    		BufferedInputStream TestFile = new BufferedInputStream(TestURL.openStream());
		    		PDFParser TestPDF = new PDFParser(TestFile);
		    		//Muthu-Thread.sleep(2000);
		    		TestPDF.parse();
		    		//Muthu-Thread.sleep(8000);
					String TestText = new PDFTextStripper().getText(TestPDF.getPDDocument());
					//Muthu-Thread.sleep(12000);
					System.out.println(TestText);
		    		if(TestText.toLowerCase().contains(pattern.toLowerCase()))
		    		{
		    			LOG.info("pdf validation matched"+pattern);
		    		}
		    		else
		    		{
		    			LOG.error("PDF Valition didnot matched, text was not found");
		    			System.out.println("PDF validation not present");
		    		}
					
		    		
		    	}catch(Exception e)
		    	{
		    		LOG.error("UNABLE TO SHIFT THE CONTROL CHILD WINDOW IN GENERIC LIBRARY FUNCTION");
		    		
		    	}
		//		 break;
		
		  
		  
			
	}//METHOD END
	
	//This method is used to shift the contorl from child window to parent window
	public static void shiftContrlToParentWindow(WebDriver driver)
	{ 
		
		try
		{
			
			driver = ScreenDriver.popup_driver.switchTo().window(handle);
		}catch(Exception e)
		{
			LOG.error("UNABLE TO SHIFT THE CONTROL PARENT WINDOE IN GENERIC LIBRARY FUNCTION");
		}
		  
	}//METHOD END

	// This method will return the data from Excel
	public static String getExcelData(String filepath, Sheet ls_excel_sheet, int rowindex, int cellindex) 
	{
		String data = null;
		
		try 
		{
			
			//Identifying the particular Row in the Sheet of Excel
			Row ls_row = ls_excel_sheet.getRow(rowindex);
			
			//Identifying the particular cell in the row
			Cell ls_cell = ls_row.getCell(cellindex);
			
			//Reading and Storing the value of particular cell in the variable
			data = ls_cell.getStringCellValue();
			

		} catch (Exception e)
		{
			//LOG.error("EXCEPTION IN READING EXCEL FILE OF GENERIC LIBRARY FUNCTION");	
		}//catch statment
		return data;
		
	}//ENF OF METHOD

	// This method wrirte the data into an Excel
	public static void writeDataTOExcel(String filepath, String sheetname, int rowindex, int cellindex, String data) 
	{
		//Creating the file
		File ls_excel_file = new File(filepath);
		FileInputStream ls_open_file=null;
		FileOutputStream ls_write_file=null;
		try 
		{
			
			//opening the file 
		    ls_open_file = new FileInputStream(ls_excel_file);
		   
			//Opening the particular book in the file			//
			Workbook ls_excel_book = WorkbookFactory.create(ls_open_file);
			
			//Opening the Sheet in the book of Excel
			Sheet ls_excel_sheet = ls_excel_book.getSheet(sheetname);
			
			//Identifying the particular Row in the Sheet of Excel
			Row ls_row = ls_excel_sheet.getRow(rowindex);

			//Identifying the particular cell in the row
			Cell ls_cell = ls_row.createCell(cellindex);
			
			//writting the data in the cell
			ls_cell.setCellValue(data);

			ls_write_file = new FileOutputStream(ls_excel_file);
			ls_excel_book.write(ls_write_file);

		} catch (Exception e)
		{
			LOG.error("EXCEPTION OF WRITTING DATA in  EXCEL FILE IN GENERICLIBRARY FUNCTION");
		}//END OF CATCH
		finally
		{
			try {
				ls_open_file.close();
			} catch (IOException e) {
				LOG.error("EXCEPTION OF closing FILE IN Write Excl data method of GENERICLIBRARY FUNCTION");
			}
		}
		
	}//END OF METHOD
	
	@SuppressWarnings("deprecation")
	public void Report(String filepath, List<String> data) 
	{
		// ****************************************************************
		//to update in Execution Sheet -- Need changes
		FileInputStream data_file;
		Workbook data_wb = null;
		int length= data.size();
		Cell cell = null;
		String data_filepath = Harness.gs_data_path+"/ExecutionSheet.xlsx";//need to be update in application .jave file
		
		if(Harness.gs_ExecutionSheet.equalsIgnoreCase("Yes")) // condition added for to run group of testcases
		{
			try {
					data_file = new FileInputStream(data_filepath);
					 data_wb = WorkbookFactory.create(data_file);
			} catch ( EncryptedDocumentException | InvalidFormatException | IOException e1) {
				
				e1.printStackTrace();
			}//try of workbook
		}
		// ****************************************************************
		
		StringBuilder sb = new StringBuilder(); 
		  
        // Appends characters one by one 
        for (String  str: data) { 
            sb.append(str);
            sb.append(","); 
        } 
  
        // convert in string 
        String combinded = sb.toString(); 
        
		String collexted_report=combinded;
		BaseTest bt=new BaseTest();
		
		String testCaseName=TestController.raw_testcaseName;
		String stepStatus = "";
		String stepValue = combinded;
				//ReportingDataBase
		int rownumber;
		
		
		//Creating style for the report Excel
		Font font= workbook.createFont();
		font.setBold(true);
		
		CellStyle style = workbook.createCellStyle();
		style.setFillForegroundColor(IndexedColors.AQUA.getIndex());
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		style.setFont(font);
		
		CellStyle style3 = workbook.createCellStyle();
		style3.setFillForegroundColor(IndexedColors.LIGHT_ORANGE.getIndex());
		style3.setFillPattern(CellStyle.SOLID_FOREGROUND);
		style3.setFont(font);
	
		CellStyle style1 = workbook.createCellStyle();
		style1.setFillForegroundColor(IndexedColors.LIGHT_GREEN.getIndex());
		style1.setFillPattern(CellStyle.SOLID_FOREGROUND);
		style.setFont(font);

		
		CellStyle style2 = workbook.createCellStyle();
		style2.setFillForegroundColor(IndexedColors.RED.getIndex());
		style2.setFillPattern(CellStyle.SOLID_FOREGROUND);
		style.setFont(font);
		
		try
		{
			//to create new sheet for each TC at the first time
			if(!Harness.lb_file)
			{
				if(Harness.gs_ExecutionSheet.equalsIgnoreCase("Yes"))
				{

					//calling Random number function to get random number for unique Sheet name
					String li_Rnd = obj_Rnd.generate_RandomNo(3);
					
					//Appending the random number with the Sheet name
					int iTC_Name_len = Harness.sheetname.length();
					String TC_Name;
					
					// below condition added by shan - to accommodate test case name less than 25 characters
					if(iTC_Name_len >= 25)
					{
						 TC_Name = Harness.sheetname.substring(0, 25)+li_Rnd;
					}
					else
					{
						 TC_Name = Harness.sheetname+li_Rnd;
					}
					
					//Creating sheet 
					sheet=workbook.createSheet(TC_Name);
				}
				else
				{
					sheet =workbook.createSheet("Sheet1");
				}
				
				//creating Row
				Row row = sheet.createRow(0);
			
				//Setting the Heading for the sheet
				cell = row.createCell(0);
				cell.setCellValue("Summary Report");
				cell.setCellStyle(style);
				
				cell = row.createCell(1);
				cell.setCellValue("Status");
				cell.setCellStyle(style);
				
				Harness.lb_file=true;
			}//Harness.lb_file
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}//catch of Harness.lb_file
	
		
		//increasing the row value by 1 to move to next row
		int li_row=Harness.rowindex1;
		Row row = sheet.createRow(li_row);
		
		//Fetching the rowcount of the particular sheet
		int row_count = sheet.getLastRowNum();
		
		//to update the overall status
		if(Harness.lb_status)
		{
			
			//Loop for iterating row of the report excl to update of the execution
			for(lirow=1;lirow<row_count;lirow++)
			{
				Row ls_row = sheet.getRow(lirow);
				//Identifying the particular cell in the row
				Cell ls_cell;
				String ls_tcname = null;
				
				//Reading and Storing the value of particular cell in the variable
				try
				{
					ls_cell = ls_row.getCell(0);//to Get the Test case name under Summary column
					ls_tcname = ls_cell.getStringCellValue();
					
				
					if(ls_tcname.equalsIgnoreCase(Harness.ls_Testcaseid))
					{
						cell = ls_row.createCell(1);
						
						//increasing  2 rows to reach Particular testcase name where its starting reporting 
						//for ex first time it wii be 4 th row which has test case name
						for(lirow=lirow+2;lirow<row_count;lirow++)
						{
							String ls_firstcolvalue = null;
							Row ls_statusrow = sheet.getRow(lirow);
							ls_cell = ls_statusrow.getCell(0);
							try
							{
								ls_firstcolvalue = ls_cell.getStringCellValue();
							}catch(NullPointerException n)
							{
							}//catch of ls_firstcolvalue
							
							try
							{
								if(!ls_firstcolvalue.equalsIgnoreCase(null))
								{
									if(ls_firstcolvalue.equalsIgnoreCase(Harness.ls_Testcaseid))
									{	
										//System.out.println("Row_Count ="+row_count);
										//to read the status column of each row
										for(lirow=lirow+1;lirow<row_count;lirow++)
										{
											Row ls_statusrow1 = sheet.getRow(lirow);
											//reading the value of status column
											ls_cell = ls_statusrow1.getCell(5);
											ls_statusdata=ls_cell.getStringCellValue();
											System.out.println("ls_statusdata ="+ls_statusdata);
											
											//updated by Ambika on 23/08/2018 to update the status when its fail or empty value
											if(ls_statusdata.equalsIgnoreCase("Fail"))
											{
												ls_statusdata="Fail";
												break;
											}//end of if
											else
											{
												//no action for //Pass or Warning or blank
											}
												
										}//for of lirow
										break;
									}//if ls_firstcolvalue
								}//null
							}
							catch(NullPointerException n)
							{
								ls_statusdata = "Fail";
							}//catch
					
					}//for of lirow1
					
					//this will update the overall status 
					cell.setCellValue(ls_statusdata);
					if(ls_statusdata.equalsIgnoreCase("Pass"))
					{
						cell.setCellStyle(style1);
					}else if(ls_statusdata.equalsIgnoreCase("Fail"))
					{
						cell.setCellStyle(style2);
					}
					
					//to update the status in Execution Sheet
					if(Harness.gs_ExecutionSheet.equalsIgnoreCase("Yes"))
					{
						try 
						{
							Sheet data_sheet = data_wb.getSheet("Input");
							int datarow_count = data_sheet.getLastRowNum();
							System.out.println(datarow_count);
							int i=0;
							for (String key : DataSheet_TCName.TC_Row.keySet()) 
					 		{
					 			if(key.equals(Harness.sheetname))
					 			{
					 				List<Integer> rowno = DataSheet_TCName.TC_Row.get(key);
					 				
					 				int li_rowno =(rowno.get(i));
					 				Row data_row = data_sheet.getRow(li_rowno);
					 				System.out.println(li_rowno);
					 				Cell data_cell = data_row.createCell(2);
									data_cell.setCellValue(ls_statusdata);
									data_cell = data_row.createCell(3);
									data_cell.setCellValue(Harness.time);
								
									DataSheet_TCName.TC_Row.remove(key,rowno.get(i));
									System.out.println(DataSheet_TCName.TC_Row);
					 				i++;
					 				 break;
					 			}else
					 			{
					 				
					 			}
					 				
					 		}// for of key
							
						} catch (EncryptedDocumentException e) 
						{
							
						} 
					}// End if(gs_ExecutionSheet = "Yes")
					break;
				}//if of tc_name
				
				}catch(NullPointerException n)
				{
					
				}//catch
				
			}//for loop of row iteration
						
		Harness.lb_status=false;
		}else
		{
			//to insert the Testcase name for summery report
			String insert_data=data.get(0);
			
			if(insert_data.equalsIgnoreCase("Insert"))
			{
				String tc_name=data.get(1);
				Row insert_row;
				
				sheet.shiftRows(Harness.li_insertrow,row_count,1,false, false);   
				insert_row=sheet.createRow(Harness.li_insertrow);
				cell = insert_row.createCell(0);
				System.out.println("tc_name ="+tc_name);
				cell.setCellValue(tc_name);
				Harness.li_insertrow++;
				insert_row=sheet.createRow(Harness.li_insertrow);
			}else
			{
				//To get the data from the report list and write in the report
				for(int li_cell=0;li_cell<length;li_cell++)
				{
					try 
					{
						String ls_data=data.get(li_cell);
					    cell = row.createCell(li_cell);
						cell.setCellValue(ls_data);
						sheet.autoSizeColumn(li_cell);
						
						//To format the Sheet
						if(ls_data.equalsIgnoreCase("Function Name")||ls_data.equalsIgnoreCase("Field-Name")||ls_data.equalsIgnoreCase("Details")||ls_data.equalsIgnoreCase("Field-Name/Window Name/Automation Files")||ls_data.equalsIgnoreCase("Expected-Value")||ls_data.equalsIgnoreCase("Actual-Value")||ls_data.equalsIgnoreCase("Status"))
						{
							cell.setCellStyle(style3);
							bt.getLogger().log(Status.PASS, MarkupHelper.createLabel(collexted_report, ExtentColor.GREEN));
							//bt.getLogger().log(Status.PASS, MarkupHelper.createLabel(collexted_report, ExtentColor.GREEN));
							

							testCaseName=TestController.raw_testcaseName;
							stepStatus = "Pass";
							stepValue = combinded;
									//ReportingDataBase
							rownumber=li_row;
							
							
						}else if(ls_data.equalsIgnoreCase("Pass"))
						{
							cell.setCellStyle(style1);
							bt.getLogger().log(Status.PASS, MarkupHelper.createLabel(collexted_report, ExtentColor.GREEN));
						}else if(ls_data.equalsIgnoreCase("Fail"))
						{
							cell.setCellStyle(style2);
							bt.getLogger().log(Status.FAIL, MarkupHelper.createLabel(collexted_report, ExtentColor.RED));
						}
					
				} catch (Exception e)
				{
					LOG.error("EXCEPTION OF WRITTING DATA in  EXCEL FILE IN GENERICLIBRARY FUNCTION");
				}//END OF CATCH
				
			}//for of array
			}//else of insert
		}
		 
		//need to update to close end of the execution
		FileOutputStream out;
		 FileOutputStream out_data;
			try {
				out = new FileOutputStream(filepath);
				workbook.write(out);
				out.close();
				if(Harness.gs_ExecutionSheet.equalsIgnoreCase("Yes"))
				{
					//to close datasheet file
					out_data = new FileOutputStream(data_filepath);
					data_wb.write(out_data);
					out_data.close();
				}
			} catch (IOException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		Harness.rowindex1++;
	
	}//END OF METHOD
	
	
	public static int getRowCount(String filepath, String sheetname) 
	{
		//Creating the file
		File ls_excel_file = new File(filepath);

		//opening the file 
		FileInputStream ls_open_file = null;
		
		try 
		{
			ls_open_file = new FileInputStream(ls_excel_file);
		} catch (FileNotFoundException e) 
		{
			LOG.error("EXCEPTION OF FILE INPUT STREAM IN OF GET ROW COUNT METHOD IN GENERICLIBRARY FUNCTION ");
		}

		//Opening the particular book in the file			
		Workbook ls_excel_book = null;
		try 
		{
			ls_excel_book = WorkbookFactory.create(ls_open_file);
		} catch (EncryptedDocumentException e) 
		 {
			LOG.error("EncryptedDocumentException of creating workbookfactory in GenericLibrary Function");
		 } catch (InvalidFormatException e) 
		   {
			 LOG.error("InvalidFormatException of creating workbookfactory in GenericLibrary Function");
			} catch (IOException e) 
		   	{
				LOG.error("IOException of creating workbookfactory in GenericLibrary Function");
			}//END OF CATCH STMT
		
			//Opening the Sheet in the book of Excel
			Sheet ls_excel_sheet = ls_excel_book.getSheet(sheetname);
			int rowcount = ls_excel_sheet.getLastRowNum();
			
			try {
				ls_open_file.close();
			} catch (IOException e) {
				LOG.error("EXCEPTION OF closing FILE IN Write Excl data method of GENERICLIBRARY FUNCTION");
			}
			return rowcount;
	}//end of method
	
	}//end of class


