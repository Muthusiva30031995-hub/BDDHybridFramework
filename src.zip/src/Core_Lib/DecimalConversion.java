package Core_Lib;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

//This function used to remove comma in the cell value and expected value in the web table if the value is numeric
//This function used for "dot" or "dot followed by some digits"  followed by all zeros gets replaced by nothing if actual or expected value are decimal number

public class DecimalConversion 
	{	
		public static String lfn_Conversion(String ls_Value )
		{
			 
			 String ls_Val = null;
			 int iPos = 0,iPos1 = 0;
			 iPos = ls_Value.indexOf(","); // used to find the position for comma
			 if (iPos > 0)
			 {
				ls_Val = ls_Value.replace(",","");	 
				iPos1 = ls_Val.indexOf(".");// used to find the position for dot
				if (iPos1 > 0)
				{
					ls_Val = ls_Val.replace(".","");
				}
			}
			
			else
			{
				iPos = ls_Value.indexOf(".");	
				if (iPos > 0)
				{
					ls_Val = ls_Value.replace(".","");
				}
			}
			
			if (iPos > 0)
			{
				//Below statements used to check the string is numeric or not
				Pattern pattern = Pattern.compile("[0-9]+"); 
				Matcher matcher = pattern.matcher(ls_Val);
					
					if (matcher.matches())
					{
						iPos = ls_Value.indexOf(",");
						if (iPos > 0)
						{
							ls_Val = ls_Value.replace(",","");// 1000.000
							ls_Value = ls_Val;
						}
						
						iPos = ls_Value.indexOf(".");
						if (iPos > 0)
						{
							// if the value "dot" or "dot followed by some digits" followed by some zeros, the zeros get discarded
							ls_Value = ls_Value.indexOf(".") < 0 ? ls_Value :ls_Value.replaceAll("0*$", "").replaceAll("\\.$", "");
						}
					}
			}
			return ls_Value;
		}	
	}
