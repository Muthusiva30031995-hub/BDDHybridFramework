package Core_Lib;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import Core_Lib.GenericLibrary;

public class Validate 
{
	public boolean gfn_validate(String ls_patrn)
	{
		//LOGGER
		Logger LOG = Logger.getLogger(Validate.class.getName());
		
		Harness obj_harness  =  new Harness();						// This object is used to check the global variable of pop up browser
		WebDriver val_driver = null;
	
		String ls_title = null;				//This variable is used to store the title of the current page
		String ls_pagesource = null;	//This variable is used to store the source of the page 
		Set<String> handles = null;
	
		boolean retval = false;		//This variable is used to store the return value
		int  numberofhandles;	//To store the no of handles
	
		ls_patrn = ls_patrn.replace("*","").trim(); //removing the star in the ls_pattern
		if(ScreenDriver.popup_driver!=null)
		{
			val_driver=ScreenDriver.popup_driver;
		}else
		{
			val_driver=ScreenDriver.scr_driver;
		}
		
		try
		{
			ls_title =val_driver.getTitle();//Get the title of the current webpage
		}catch(Exception e)
		{
			LOG.error("Unable to get the title in Validate Function");
		}//end of catch stmt
	
		//val_driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		retval = ls_title.contains(ls_patrn);//check the title contains the ls_pattern
	
		if(!retval)
		{
			try
			{
				//Muthu-Thread.sleep(1000);
				ls_pagesource= val_driver.getPageSource();
				retval = ls_pagesource.contains(ls_patrn);
			}catch(Exception e)
			{
				handles  = val_driver.getWindowHandles(); // to handle pop browser as next window
				numberofhandles = handles.size();
		        
				
				for(int li_loop = 0;li_loop<= numberofhandles - 1;li_loop++)
				{	
					ls_title = val_driver.getTitle();
	          
					if(ls_title.contains(ls_patrn))     // Execute the search test.
						retval=true;
					else
					{
						ls_pagesource= val_driver.getPageSource();
						if(ls_pagesource.contains(ls_patrn)) 
							retval=true;
					}//else of ls_title 
					   
				}//for of NumberOfLists
			
			
				LOG.error("Unable to get the pagesource in Validate Function");
			}//CATCH
			
			
			
			
		
		
		if (ls_pagesource==null)      // to ensure default browser can work 
		{
			if (obj_harness.gb_browserpopup_exists=true)
			{
				// to handle pop browser as next window
				try
				{
					GenericLibrary.shiftContrlToChildWindow(val_driver);
				}catch(Exception e)
				{
					LOG.error("Unable to shift the control to child window in Validate function");
				}//end of catch stmt
        	
				try
				{
					handles  = val_driver.getWindowHandles(); // to handle pop browser as next window
				}catch(Exception e)
				{
					LOG.error("Unable to get the window handles in validate function");

				}//end of catch stmt
        	
			} else 
				try
    			{
					handles  = val_driver.getWindowHandles(); // to handle pop browser as next window
    			}catch(Exception e)
    			{
    				LOG.error("Unable to get the window handles in validate function");

    			}//end of catch stmt
        
        
			numberofhandles = handles.size();
        
		
			for(int li_loop = 0;li_loop<= numberofhandles - 1;li_loop++)
			{	
				ls_title = val_driver.getTitle();
          
				if(ls_title.contains(ls_patrn))     // Execute the search test.
					retval=true;
				else
				{
					ls_pagesource= val_driver.getPageSource();
					if(ls_pagesource.contains(ls_patrn)) 
						retval=true;
				}//else of ls_title 
				   
			}//for of NumberOfLists
		
		} //If innertext was ""
		}//else of retval
		//VALIDATION
		//Assert.assertTrue(retval, ls_patrn+ " does not exists in Validate Function");
		if (retval) // for pop browser ' to handle for pop up broser pattern 03/02/15
		{
			obj_harness.gb_browserpopup_exists=false;
		}

		return retval;
	}	//END OF METHOD
}//CLASS
