
package Core_Lib;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.testng.Assert;

/*This class ensures that the specified  file exists */
public class File_Exists 
{
	
	public boolean FILE_EXISTS(String ls_FileName)  
	{
		//LOGGER
		Logger LOG = Logger.getLogger(File_Exists.class.getName());
		//Detail Reporting
		 GenericLibrary obj_Generic = new GenericLibrary();
		 String report_file = Harness.report_testcase;
		 List<String> report_data = new ArrayList<String>();
		 String report_type=Harness.ls_ReportingType;
		 String ls_Functionname="FILE_EXISTS";
		 String ls_Msg=null;
		 String ls_status=null;
		
		boolean exists = false; 
		File ls_file = new File(ls_FileName); // create file object
		
		try
		{
			// check if file exists
			exists = ls_file.exists(); 
			if (!exists) 
			  {
				ls_Msg="THE FILE DOES NOT EXISTS ";
				ls_status="Fail";
				//LOG.error("THE FILE DOES NOT EXISTS" +ls_FileName);
				
				
			  } // if end
			else
			{
				//System.out.println("THE FILE DOES  EXISTS "+ls_FileName);
			}
			
		}catch(Exception e)
		{
			ls_Msg="File not found exception";
			ls_status="Fail";
			LOG.error("File not found excepton in File Exist class");
			
		}//END OF CATCH
		
		if (!exists) 
		{
			// check file existence
			if(report_type.equals("DETAIL"))
			{
				//for Excl DETAIL reporting
				report_data.add(ls_Functionname);
				report_data.add("");
				report_data.add("");
				report_data.add(ls_FileName);
				report_data.add(ls_Msg);
				report_data.add(ls_status);
				obj_Generic.Report(report_file,report_data );
				
			}//if of report
		}//if of exists
		
		//To update the status in Excl Report
		Assert.assertTrue(exists, "THE FILE DOES NOT EXISTS" +ls_FileName);
		return exists;
	}// method end

}// class end