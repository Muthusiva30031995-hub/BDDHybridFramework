package Core_Lib;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.Assert;

import config.defs;
//import listener.EventHandler;
import tests.BaseTest;


public class Browser_Invoke_Url extends BaseTest 
{
	
	public static RemoteWebDriver driver=null;
	EventFiringWebDriver eventDriver = null;
	String ls_Status="";
		
	public void BROWSER_INVOKEURL(String browser,String gs_url) 
	{
		//LOGGER
		Logger LOG = Logger.getLogger(Browser_Invoke_Url.class.getName());
		
		//Detail Reporting
		 GenericLibrary obj_Generic = new GenericLibrary();
		 String report_file = Harness.report_testcase;
		 List<String> report_data = new ArrayList<String>();
		 String report_type=Harness.ls_ReportingType;
		 String ls_Functionname="BROWSER_INVOKEURL";
		 String ls_Msg=null;
		 String ls_status=null;
		
		String gs_current_url;
		Harness obj_Harness = new Harness();
		String ls_browserPath = obj_Harness.gs_browser_path;
		String ls_IEDriverPath = ls_browserPath+"/IEDriverServer.exe";
		String ls_ChromePath=ls_browserPath+"/chromedriver.exe";
		String ls_PhanthomjsPath=ls_browserPath+"/phantomjs.exe";
		String grid_url="http://10.201.65.233:4444/wd/hub";
		String application_url=defs.url_test;
		
		try {
			String environment=System.getProperty("regressionnenv");
			if(environment.equalsIgnoreCase("TEST"))
				application_url=defs.url_test;
			else if(environment.equalsIgnoreCase("MODL"))
				application_url=defs.url_modl;
			else if(environment.equalsIgnoreCase("AGILE"))
				application_url=defs.url_agile;
			
			gs_url=application_url;
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		//need to write a code for choice the browser    //IE,CHROME OR FIREBOX
		
				//need to write a code for environem and it's URL selection from defs      //test,Modl,agile
				
				
				//run it in local or cloud flagging
				
				
				//Check the free node availablility and Select the NODE URL to initiate the browser
				
				
				//
				
				//Plan for selenium grid extra
				
				// Code and Initiate the Master and node from Jenkins or Batch files 
				//Grid node and hub initiated as  service
				
				//SQL server, table creation for hub, node url, status maintainence
				//SQL server, table creation for reporting
				
				
				
				//executionType code from Arun system to merge this
				
				
				
				//Code to 
				
				
				
				//check for the browser whether IE,CHROME OR FIREBOX
		
		//check for the browser whether IE,CHROME OR FIREBOX
		try 
		{
			
			if(browser.equals("IE"))
			{
				
				System.setProperty("webdriver.ie.driver",ls_IEDriverPath);
				DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
				capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
				capabilities.setCapability("requireWindowFocus", true);
				capabilities.setCapability("nativeEvents", true);
				//capabilities.setCapability("unexpectedAlertBehaviour", false);
			
				setDriver(new InternetExplorerDriver(capabilities));     //TO Launch IE browser
//				driver = new InternetExplorerDriver();
				getDriver().manage().window().maximize();
				getDriver().manage().timeouts().implicitlyWait(defs.implicitwait, TimeUnit.SECONDS);//maximize browser window
				getDriver().manage().timeouts().pageLoadTimeout(defs.pageLoadTimeout, TimeUnit.SECONDS);
				getDriver().navigate().to(gs_url);						   //Navigating to the application URL
				//driver.get(gs_url);						   //Navigating to the application URL
				
				ls_Msg="THE IE BROWSER IS SUCCESSFULLY INVOKED";
				ls_status="Pass";
				
				LOG.info("THE IE BROWSER IS SUCCESSFULLY INVOKED");

			}
			
			else if(browser.equals("Chrome1"))
			{
				
	           System.setProperty("phantomjs.binary.path",ls_PhanthomjsPath);
            ArrayList<String> cliArgsCap = new ArrayList<>();
            DesiredCapabilities capabilities1 = DesiredCapabilities.phantomjs();
            capabilities1.setCapability(PhantomJSDriverService.PHANTOMJS_CLI_ARGS,cliArgsCap);
            capabilities1.setJavascriptEnabled(true);
            //capabilities.setCapability("requireWindowFocus", true);
			//capabilities.setCapability("nativeEvents", true);
            //PhantomJSDriver phantomJSDriver = null;
            try {
                  //phantomJSDriver = new PhantomJSDriver(capabilities);
            	 setDriver(new PhantomJSDriver(capabilities1));
            } catch (Exception e) {
                 
            }
           
            getDriver().manage().window().maximize();
			getDriver().manage().timeouts().implicitlyWait(defs.implicitwait, TimeUnit.SECONDS);//maximize browser window
			getDriver().manage().timeouts().pageLoadTimeout(defs.pageLoadTimeout, TimeUnit.SECONDS);
			getDriver().navigate().to(gs_url);
				
				ls_Msg="THE IE BROWSER IS SUCCESSFULLY INVOKED";
				ls_status="Pass";
				
				LOG.info("THE IE BROWSER IS SUCCESSFULLY INVOKED");

			}
			else if(browser.equals("Chrome"))
			 {
				//Setting Property for Chrome
				System.setProperty("webdriver.chrome.driver",ls_ChromePath );
				/*ChromeOptions chromeOptions = new ChromeOptions();
				chromeOptions.addArguments("--start-maximized");
				
				//TO Launch CHROME  browser
				//driver = new ChromeDriver(chromeOptions);
				driver = new ChromeDriver();*/
				
				/*ChromeOptions options = new ChromeOptions(); options.addArguments("no-sandbox"); 
				options.addArguments("disable-extensions"); 
				driver = new ChromeDriver(options);*/
								
				//Updated by Ambika on 16-05-2018
				
				ChromeOptions options = new ChromeOptions();
			    	options.setExperimentalOption("useAutomationExtension", false);
			    	options.addArguments("disable-infobars");
			    	options.addArguments("--start-maximized");
			    	options.addArguments("Zoom 75%");
				//options.addArguments("start-maximized"); //added by moorthy(13/11/2018) to start the browser maximized
				/*
				 * options.addArguments("test-type"); options.addArguments("start-maximized");
				 * options.addArguments("--window-size=1920,1080");
				 * options.addArguments("--enable-precise-memory-info");
				 * options.addArguments("--disable-popup-blocking");
				 * options.addArguments("--disable-default-apps");
				 * options.addArguments("test-type=browser");
				 */
			   	setDriver(new ChromeDriver(options));
	
			   	     //TO Launch IE browser
//				driver = new InternetExplorerDriver();
				//getDriver().manage().window().maximize();
				getDriver().manage().timeouts().implicitlyWait(defs.implicitwait, TimeUnit.SECONDS);//maximize browser window
				getDriver().manage().timeouts().pageLoadTimeout(defs.pageLoadTimeout, TimeUnit.SECONDS);
				getDriver().navigate().to(gs_url);
			   	
				//Navigating to the application URL
				//driver.get(gs_url);	
				 
				 //driver.manage().window().maximize();	 //maximize browser window
				//Wait Stmt
				//driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);

				LOG.info("THE CHROME  BROWSER IS SUCCESSFULLY INVOKED");
				ls_Msg="THE CHROME BROWSER IS SUCCESSFULLY INVOKED";
				ls_status="Pass";

				// Validation
				//gs_current_url=driver.getCurrentUrl();
				
				//Assert.assertEquals(gs_url, gs_current_url, "url is mismatched in browser invoking");
				
				//maximize browser window
				//driver.manage().window().maximize(); 		
				getDriver().manage().timeouts().implicitlyWait(defs.implicitwait, TimeUnit.SECONDS);
						
			 }else if(browser.equals("FireFox"))
			  {
				 
				LOG.info("Invoking the FireFox Browser");

				//navigating to application
				FirefoxProfile fxProfile = new FirefoxProfile();

				
				fxProfile.setPreference("browser.download.folderList",2);
				fxProfile.setPreference("browser.download.manager.showWhenStarting",false);
				fxProfile.setPreference("browser.download.dir","c:\\mydownloads");
				fxProfile.setPreference("browser.helperApps.neverAsk.saveToDisk","text/csv");
				
				 setDriver(new FirefoxDriver(fxProfile));
				 LOG.info("THE FIREFOX  BROWSER IS SUCCESSFULLY INVOKED");
				 ls_Msg="THE FIREFOX BROWSER IS SUCCESSFULLY INVOKED";
					ls_status="Pass";
				 
				//Navigating to the application URL
				 getDriver().get(gs_url); 						
				 getDriver().manage().timeouts().implicitlyWait(defs.implicitwait, TimeUnit.SECONDS);
				 
				/*// Validation
				gs_current_url=driver.getCurrentUrl();
				Assert.assertEquals(gs_url, gs_current_url, "url is mismatched in browser invoking");*/
				
				//maximize browser window
				 getDriver().manage().window().maximize(); 		
				 getDriver().manage().timeouts().implicitlyWait(defs.implicitwait, TimeUnit.SECONDS);
				 
				}//else of Firefox
			
	} catch (Exception e)
	   {
			LOG.info("Exception in Browser invoke function");
			ls_Msg="Exception in Browser invoke function";
			ls_status="Fail";
		}
				
		 if(report_type.equals("DETAIL"))
			{
				//for Excl DETAIL reporting
				report_data.add(ls_Functionname);
				report_data.add("");
				report_data.add(gs_url);
				report_data.add("");
				report_data.add(ls_Msg);
				report_data.add(ls_status);
				obj_Generic.Report(report_file,report_data );
			}//if of report
	 }//method end

	public RemoteWebDriver getDriver() {
		return driver;
	}

	public static void setDriver(RemoteWebDriver driver) {
		Browser_Invoke_Url.driver = driver;
	}
	
	public boolean isDriverClosed(WebDriver scr_driver) {
		boolean IEDriverClosed=false;
		try
		{
			scr_driver.close();
			scr_driver.quit();
			IEDriverClosed=true;
		}catch(Exception E)
		{
			System.out.println("Exception has been occured while replacing the Driver");
			IEDriverClosed=false;
		}
		return IEDriverClosed;
				
	}


}//class end 
