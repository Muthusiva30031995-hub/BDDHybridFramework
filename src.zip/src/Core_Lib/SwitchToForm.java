package Core_Lib;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SwitchToForm {

	public void SwitchForm(WebDriver scr_driver, String ls_value) throws Exception {

		//Muthu-Thread.sleep(2000);
		Logger LOG = Logger.getLogger(Set_Property.class.getName());

		/*
		 * WebElement ele = win_object;
		 * 
		 * Actions act = new Actions(scr_driver);
		 * 
		 * act.doubleClick(ele).build().perform();
		 */
		switch (ls_value) {

		case "Login":

			scr_driver.switchTo().defaultContent();
			WebElement ele = scr_driver.findElement(By.id("top_frame"));
			scr_driver.switchTo().frame(ele);

			break;

		case "HomeForm":

			scr_driver.switchTo().defaultContent();
			WebElement ele1 = scr_driver.findElement(By.id("top_frame"));
			scr_driver.switchTo().frame(ele1);

			break;

		default:
			System.out.println("Case not found");
			LOG.error(ls_value + " not visible");
			break;
		}

	}
}
