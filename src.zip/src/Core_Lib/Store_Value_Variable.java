package Core_Lib;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.testng.Assert;


public class Store_Value_Variable 
{
	public String STORE_VALUE_VARIABLE(String ls_ObjectName,String GetPropValue,String ls_Var)
	{
		//LOGGER
		Logger LOG = Logger.getLogger(Store_Value_Variable.class.getName());
		
		//Reporting
		GenericLibrary obj_Generic = new GenericLibrary();
		String report_file = Harness.report_testcase;
		List<String> report_data = new ArrayList<String>();
		String report_type=Harness.ls_ReportingType;
				
		String ls_Msg = null,ls_FunctionName="STORE_VALUE_VARIABLE",ls_Status = null;	
		
		String gs_data_path;  				// holds the data path
		String ls_Variable; 
		String ListFile;
		boolean lb_file=false;
		
		File_Exists obj_file = new File_Exists();
		
		gs_data_path=Harness.gs_data_path;
		ListFile =gs_data_path+ "/StoredNums.txt";
		
		ls_Variable=ls_Var + "," + GetPropValue;
		
		//Create file object
		File filename = new File(ListFile);
		
		lb_file=obj_file.FILE_EXISTS(ListFile);
			
		if(lb_file)
		{
		    try
			{
				FileOutputStream fos_file = new FileOutputStream(filename);
				
				//Verifying the file exists
			    if (fos_file!=null)
			    {
					BufferedWriter file_writer= new BufferedWriter(new OutputStreamWriter(fos_file));//Its used to write the Whole line at a time	
					file_writer.write(ls_Variable);//Writing the values in the dictionary
					file_writer.flush();
//					ls_Msg = ls_Variable + "write the value in Stored Num Text file in STORE VALUE VARIABLE Function";
					ls_Msg = "The Key " + ls_Var + " with the value "  + GetPropValue + " is added in Stored Num Text file ";
					ls_Status = "Pass";
			    }//IF  
			 }
		    catch(Exception e)
			{
		    	//VALIDATION
				ls_Msg = "Unable to write the value in Stored Num Text file in STORE VALUE VARIABLE Function";
	    		LOG.error(ls_Msg);
	    		ls_Status = "Fail";
			}//catch
		    
		    if(report_type.equals("DETAIL"))
     		{
     			//for Excel detail reporting
     			report_data.add(ls_FunctionName);//Function Name
     			report_data.add(ls_ObjectName);//object name
     			report_data.add(GetPropValue);//Expected
     			report_data.add("");//Actual
     			report_data.add(ls_Msg);//Detail
     			report_data.add(ls_Status);//Status
     			obj_Generic.Report(report_file,report_data );
     		}
		}  
		 //Assigning value to function 
		 return ls_Variable;
		
	}//method end

}//class end 
