package Core_Lib;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

//This function gets the cell data for the Row and Columns specified for a Web Table.
//This function also calls the GET_OBJECT_IDENTIFIER function in order to create the object on the fly.

public class Get_Table_Cell_Data
{
	 
	 
	public String  GET_TABLE_CELL_DATA(String myContext, String ls_ObjectName,String RowNo,String ColNo,String optional_ERR_FLAG)
	{
		
		//LOGGER
		Logger LOG = Logger.getLogger(Get_Table_Cell_Data.class.getName());
		
	    String Table_Value = null;
	    WebElement ls_element = null;
	     
	 	WebElement WebTable = null;
	    List<WebElement> rows_table = new ArrayList<WebElement>();
	    List<WebElement> columns_table = new ArrayList<WebElement>();
	    String Locator_Value = Get_Object_Identifier.locator_value;
	   
	     WebDriver driver =ScreenDriver.scr_driver;  
	     
	    //get the table object
	    Get_Object_Identifier object_identifier = new Get_Object_Identifier();
	    
	   try 
	    {
	    	WebTable = object_identifier.GET_OBJECT_IDENTIFIER(ScreenDriver.scr_driver, ls_ObjectName,null, optional_ERR_FLAG);
	    } catch (Exception e)
        {
			LOG.error("The WebTable is not found in GetTableCellData Function");
		 }//END OF CATCH
	    	
	  //================================================
	   int ExpectedRowNo;
	   int col_num = Integer.parseInt(ColNo);
	   String tagName_value = ScreenDriver.li_tagName; // 08 Feb 18 - Shan

	   if(RowNo.equalsIgnoreCase("LastRow"))
	   {
		   //identify the table and no of row 
		   List<WebElement> rows	= WebTable.findElements(By.xpath("./tbody/tr"));
	
		   //navigate to last row
		   //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);  // added by shan 13-02-18
		   ExpectedRowNo = rows.size();
	   }
	   else
	   {
		   int row_num =Integer.parseInt(RowNo);
		   ExpectedRowNo = row_num; 
	   }
	   
	   try
		{
	   if(tagName_value != null)
	   {
			//click on the link of particular document	
			String xpath="./tr["+ExpectedRowNo+"]/td["+ColNo+"]/"+tagName_value;
			//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);  // added by shan 13-02-18
			ls_element = WebTable.findElement(By.xpath(xpath));		
	   }
	   else
	   {	//click on the link of particular document
			String xpath="./tr["+ExpectedRowNo+"]/td["+ColNo+"]";
			//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);  // added by shan 13-02-18
			ls_element = WebTable.findElement(By.xpath(xpath));		   
	   }
		}
		catch(Exception e)
		{
			String ls_Msg="Exception in GET_TABLE_CELL_DATA Function";
		}
	   //getting the value of the object
	   Table_Value =  ls_element.getAttribute("value");
	   
	   if(Table_Value == null)  
	   {
		   Table_Value =  ls_element.getText();
	   }
	   return Table_Value.trim();
			
  }// END METHOD

}//END CLASS 
