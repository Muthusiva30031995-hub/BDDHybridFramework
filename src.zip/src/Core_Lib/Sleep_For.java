package Core_Lib;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

public class Sleep_For
{
	public void wait_for(String  ls_value,String optional_error_flag )
	{
		//LOGGER
		Logger LOG = Logger.getLogger(Wait_For.class.getName());
		
		//Reporting
		GenericLibrary obj_Generic = new GenericLibrary();
		String report_file = Harness.report_testcase;
		List<String> report_data = new ArrayList<String>();
		String report_type=Harness.ls_ReportingType;
		
		String ls_Msg,ls_FunctionName = "SLEEP_FOR",ls_Status;	
			
		try
		{
			int li_value=Integer.parseInt(ls_value);
			//li_value = li_value*1000;  // time converted to milliseconds
			////Muthu-Thread.sleep(li_value);	
			
			ls_Msg = "Wait Time in Seconds";
    		LOG.info(ls_Msg);
    		ls_Status = "Done";
			
		} catch (Exception e)
		{
			ls_Msg = "EXCEPTION WAIT_FOR";
    		LOG.error(ls_Msg);
    		ls_Status = "Fail";
		}	//CATCH
		
		//Commented by Ambika on 10/01/2018 
		/*if(report_type.equals("DETAIL"))
		{
			//for Excel detail reporting
			report_data.add(ls_FunctionName);//Function Name
			report_data.add("");//object name
			report_data.add(ls_value);//Expected
			report_data.add("");//Actual
			report_data.add(ls_Msg);//Detail
			report_data.add(ls_Status);//Status
			GenericLibrary.Report(report_file,report_data );
		}*/
	}//method end
}//class end
