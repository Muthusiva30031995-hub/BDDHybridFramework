package Core_Lib;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import com.mysql.cj.jdbc.result.ResultSetMetaData;


public class ReportingDataBase {
	
	public void connectReportDB()
	{
		try{  
		      Class.forName("com.mysql.jdbc.Driver");
		      
		      //10.201.64.115
		      //usspeuftwp0057.corp.qbe.com
		      Connection con=DriverManager.getConnection("jdbc:mysql://10.201.64.115:3306/autoamtionreport","root","admin");
		      Statement stmt=con.createStatement();  
		      
		            ResultSet rs=stmt.executeQuery("select * from extentreport"); 
		            ResultSetMetaData rsmd = (ResultSetMetaData) rs.getMetaData();
		            int columnCount = rsmd.getColumnCount();
		            while(rs.next())  
		            	//System.out.println(rs.getInt(1)+rs.getString(2)+rs.getString(3));
		            {
		            	for(int i =1; i<=columnCount; i++){
			                if(!(i==columnCount)){

			                    System.out.print(rs.getString(i)+"\t");
			                }
			                else{
			                    System.out.println(rs.getString(i));
			                }

			            }
		            }
		            
		            
		            con.close();  
		      }catch(Exception e)
		      {
		            System.out.println(e);
		      
		      }  
		       
	}
		public void insert_result()
		{
			
		}
	}


