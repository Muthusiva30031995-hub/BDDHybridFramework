package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.util.SystemOutLogger;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class runtimeRepo 
{

	public static Map<String,String> variableValue=new HashMap<String,String>();
	public static boolean initilized;
	//HashMap<String, HashMap<String, Object>> mapInside = new HashMap<String, HashMap<String,Object>>();
	/*public runtimeRepo()
	{
		
	}*/
	public static File file=null;
	public static FileInputStream excelFile=null;
	public static XSSFWorkbook workbook=null;
	public static XSSFSheet datatypeSheet=null;
	public static Iterator<Row> iterator =null;
	public static Iterator<Row> iteratorpre =null;
	public static boolean repoDataFileExists=false;
	public static  FileOutputStream out=null;
	
	public runtimeRepo(String runtimeExcelPath)
	{
		file=new File(runtimeExcelPath);
		
		try {
			excelFile=new FileInputStream(file);
			//out = new FileOutputStream(file);
			
			workbook=new XSSFWorkbook(excelFile);
			datatypeSheet= workbook.getSheetAt(0);
			repoDataFileExists=true;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			repoDataFileExists=false;
			e.printStackTrace();
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	
	public runtimeRepo()
	{
		
	}
	
	public boolean initilizeMap(String key, String value)
	{
		try
		{
		insertValue(key,value);
		initilized=true;
		}
		catch(Exception e)
		{
			initilized=false;
			System.out.println("Map initilization is failed");
		}
		return initilized;
	}
	
	public Map<String,String> getTheMap()
	{
		
		return variableValue;
	}
	
	public String getTheValue(String key)
	{
		if(variableValue.containsKey(key))
		{
		return variableValue.get(key);
		}
		else
		{
			System.out.println("Key:" + key + " is exist already please use different key" );
			return "";
		}
	}
	
	public void insertValue(String key,String value)
	{
		
		if(!variableValue.containsKey(key))
		{
		variableValue.put(key, value);
		}
		else
		{
			System.out.println("Key:" + key + " is exist already please use different key, now we replacing the value" );;
			variableValue.replace(key, value);
		}	

	}
	
	public int getTheRowCount(Sheet datatypeSheet,String testcaseName)
	{
		int columnIndex=1;
        int rowValue=0;
	        for (int j = 0; j < datatypeSheet.getLastRowNum();j++) 
	        {	
	        	try{
	                String cellValue = datatypeSheet.getRow(0).getCell(columnIndex).getStringCellValue();
		                if(cellValue.equalsIgnoreCase(testcaseName))
		                {
		                	rowValue=j;
		                	break;
		                }	
	        		}
	        		catch(Exception e)
	        		{
	        			rowValue=999999;
	        		break;
	        		}
	        }

		return rowValue;
	}
	
	public boolean storeTheRunTimeValue(String sheetName,Map<String,String> mapStore)
	{
		
		
		return true;
	}
	
	public boolean closeTheExcel()
	{
		
		
		
		
		return false;
		
	}
	
	
	
	public void readExcelAndStore(String testCaseName)
	{
		boolean lastCellFlag=true;
		//int targetRow=getTheRowCount(datatypeSheet,testCaseName);
		String[] cellvalueSplit;
		int testcaseColumnIndex=1;
		int prerequsiteColumnIndex=2;
		
		testCaseName=testCaseName.substring(1, testCaseName.length());
		testCaseName=testCaseName.substring(0, testCaseName.indexOf("."));
		
	try {
        iterator = datatypeSheet.iterator();
        iteratorpre = datatypeSheet.iterator();
        
        while (iterator.hasNext()) 
        {

            Row currentRow = iterator.next();
            Cell cellTestCase =currentRow.getCell(testcaseColumnIndex);
            Cell cellPrereq=currentRow.getCell(prerequsiteColumnIndex);
            String cellPrereqValues=cellPrereq.getStringCellValue();
            
            if(cellTestCase.getStringCellValue().equalsIgnoreCase(testCaseName))
            {
            	
            	 while (iteratorpre.hasNext()) 
            	 {
            		 Row currentRow1 = iteratorpre.next();
                 	//Iterator<Cell> cellIterator1 = currentRow1.iterator();
                 	Cell cellTestCaseSecondTry =currentRow1.getCell(testcaseColumnIndex);
                 	
                 	if(cellPrereqValues.equalsIgnoreCase("NA"))
                 	{
                 		cellPrereqValues=testCaseName;	
                 	}
                 	
		            	//Re loop the pre-condition test case name in the main test case name list 
		            	if(cellTestCaseSecondTry.getStringCellValue().equalsIgnoreCase(cellPrereqValues) )
		            	{
		            		Iterator<Cell> cellIterator1 = currentRow1.iterator();
			            	while (cellIterator1.hasNext()) 
			            	{
			            		if(lastCellFlag)
			            		{
			            		        Cell currentCell = cellIterator1.next();
						                String cellValue=null;
						                //getCellTypeEnum shown as deprecated for version 3.15
						                //getCellTypeEnum ill be renamed to getCellType starting from version 4.0
							                if (currentCell.getCellTypeEnum() == CellType.STRING) {
							                	cellValue= currentCell.getStringCellValue();
							                	System.out.print(cellValue + "--");
							                } else if (currentCell.getCellTypeEnum() == CellType.NUMERIC) {
							                	cellValue= Double.toString(currentCell.getNumericCellValue());
							                    System.out.print(cellValue + "--");
							                }
							                else if (currentCell.getCellTypeEnum() == CellType.BLANK) {
							                	cellValue="";
							                	lastCellFlag=false;
							                    System.out.print("Blank Value "+ "--");
							                    break;
							                }
							                else if (currentCell.getCellTypeEnum() == CellType.ERROR) {
							                	cellValue="";
							                	lastCellFlag=false;
							                	System.out.print("Error Value "+ "--");
							                	break;
							                }
							                
								                if(!cellValue.equalsIgnoreCase("") &&  cellValue.contains("=") && !cellValue.equals(null))
								                {
									                cellvalueSplit= cellValue.split("=");
									                insertValue(cellvalueSplit[0], cellvalueSplit[1]);
								                }	
			            		}
			            			//System.out.println();
				            	}
						     }
		            	else if(cellTestCaseSecondTry.getStringCellValue().equalsIgnoreCase("NA"))
		            	{
		            	break;	
		            	}
		            	
            	 	}
            	 break;
            	}
        	}
    	} catch (Exception e) {
    		e.printStackTrace();
    		} 
    
   		cellvalueSplit=null;
	}
	
	public void storeTheRuntimeValueToExcel(String testCaseName)
	{
		boolean lastCellFlag=true;
		//int targetRow=getTheRowCount(datatypeSheet,testCaseName);
		String[] cellvalueSplit;
		int testCaseColumnIndex=1;
		int prerequsiteColumnIndex=2;
		int dataStartColumnIndex=4;
		int mapSize=0;
		
		testCaseName=testCaseName.substring(1, testCaseName.length());
		testCaseName=testCaseName.substring(0, testCaseName.indexOf("."));
		
		//
		try
		{
			if(initilized)
			{
				mapSize=variableValue.size();
				iterator = datatypeSheet.iterator();
				
		        while (iterator.hasNext()) {
		
		            Row currentRow = iterator.next();
		            Iterator<Cell> cellIterator = currentRow.iterator();
		            
		            Cell cellTestCase =currentRow.getCell(testCaseColumnIndex);
		            
		            if(cellTestCase.getStringCellValue().equalsIgnoreCase(testCaseName))
		            {
	                        int colNum = 2;
	                        for (Map.Entry<String,String> key:variableValue.entrySet()) {
	                        	Cell cell = currentRow.createCell(dataStartColumnIndex);
	                        	String field=key.toString(); // + "=" + variableValue.get(key)
	                        	
	                            if (field instanceof String) {
	                                cell.setCellValue((String) field);
	                                System.out.println("Writing to Excel - DataRepo: Key " + field);
	                            }
	                            
	                            dataStartColumnIndex++;
	                        }
	                        break;
	            		}
	            	//System.out.println();
	            	}
				
			}
			
			out = new FileOutputStream(file);
			//out = new FileOutputStream( new File("Writesheet.xlsx"));
			if(!excelFile.equals(null)&& !out.equals(null))
			{
	        workbook.write(out);
	        excelFile.close();
	        out.close();
			}	
	        System.out.println("DataRepo.xlsx written successfully" );
		}
		catch(Exception e)
		{
			System.out.println("Exception while writting" + e.toString());
	        try {
				excelFile.close();
				out.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		
		}
		cellvalueSplit=null;
	
	}
}
