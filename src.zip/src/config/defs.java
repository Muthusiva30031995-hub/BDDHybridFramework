package config;

public class defs 
{
	//Port 25 and qbe-smtp.qbeai.com.
	//Master config
	public static String browser = "IE";
	
	public static int implicitwait=180;//seconds
	public static int implicitwaitAlternate=10;//seconds
	public static int explicitWait=200;//seconds
	public static int pageLoadTimeout=2000;//seconds
	public static int dropdownlistLoadingTime=2000;//millisecond
	public static int duplicateErrorLoadTime=120;
	public static int polcysearchWaittime=600000;
	public static boolean automatedFlagCompare=false;
	public static int siteReachableTimeout=30000;
	public static int beforeObjectLoadTime=500;//500
	public static int afterObjectLoadTime=300;//500
	public static int siteReachableCount=300;
	public static int retryCountFailedTestcase=0;
	//sunimnascp006/PublicShare/
	//vdawwfs04/PublicShare //
	public static String masteresultPath="//sunimnascp006/PublicShare//QBENA - Automation Team\\Automation Execution\\GWCC_ResultFolder";
	public static String masteresultPathalterate="//vdawwfs04/PublicShare//QBENA - Automation Team\\Automation Execution\\GWCC_ResultFolder";
	public static String masteresultPathshort=masteresultPath;
	//public static String masteresultPathshort="H:\\QBENA - Automation Team\\Automation Execution\\GWCC_ResultFolder";
	public static boolean killthebrowserAtEnd=false;
	public static String WTM_ROOT="D:/SeleniumWorksapce/Automation_Project/src/";
	public static String WTM_DATA_LIB="testData";
	public static String WTM_BIN="config";
	public static String WTM_BROWSER="driverFactory";
	public static String WTM_CORE_LIB="Core_Lib";
	public static String WTM_CASE_LIB="testCases";
	public static String WTM_MAS_LIB="Mas_Lib";
	public static String WTM_UPLOADFILE="C:/DMS Upload/";
	//public static String WTM_APP_URL="http://cc-agile-test.myqbe.com/CC/ClaimCenter.do";
	public static String WTM_APP_URL="http://cc-test.myqbe.com/CC/ClaimCenter.do";
	public static String WTM_INPUT_GEN_ENVI="5";
	public static String grid_url="http://10.201.65.233:4444/wd/hub";
	
	public static String applicationName_underRun="Himarley";
	public static String noActionvalue="NoAction";
	
	public static String email_host = "qbe-smtp.qbeai.com";
	public static String email_port = "25";
	//public static String email_to = "manikandan.ravi@mphasis.com,ravi.manikandan@us.qbe.com";
	public static String email_to = "Muthusamy.Palanikumar@us.qbe.com";
	public static String email_from = "Muthusamy.Palanikumar@us.qbe.com";
	//public static String email_to = "Abhijit.Biswas@us.qbe.com"
			//+ "Yuvraj.Bhagwat@us.qbe.com,Muthusamy.Palanikumar@us.qbe.com";
	//public static String email_from = "ravi.manikandan@us.qbe.com";
	//public static String email_cc = "ravi.manikandan@us.qbe.com";
	public static String email_username = "ravi.manikandan@us.qbe.com";
	public static String email_password = "";
	
	public static String url_test="http://cc-test.myqbe.com/CC/ClaimCenter.do";	
	public static String url_agile="http://cc-agile-test.myqbe.com/CC/ClaimCenter.do";
	public static String url_modl="https://cc-modl.myqbe.com/CC/ClaimCenter.do";
	
	public static final String JIRA_URL = "https://qbe-upgrade.valiantys.net";
	public static final String JIRA_ADMIN_USERNAME = "ravi.manikandan@us.qbe.com";
	public static final String JIRA_ADMIN_PASSWORD = "Memory-001";
	
	public static void setApplicationName(String application)
	{
		defs.applicationName_underRun=application;
	}
	public static String getApplicationName()
	{
		return defs.applicationName_underRun;
	}
}
